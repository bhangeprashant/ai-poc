import sqlite3

def get_user(username):
    conn = sqlite3.connect("app.db")
    cur = conn.cursor()
    # intentionally vulnerable: string-formatted SQL
    cur.execute("SELECT * FROM users WHERE username = '%s'" % username)
    return cur.fetchone()
