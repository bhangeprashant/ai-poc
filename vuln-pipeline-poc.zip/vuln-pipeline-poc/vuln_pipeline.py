#!/usr/bin/env python3
"""
vuln_pipeline.py — Agentic vulnerability discovery, remediation & validation POC.

An eight-stage pipeline that scans a local repository with an LLM acting as a
sequence of specialist agents:

  S1 Attack surface mapping   -> what the app is, entry points, trust boundaries
  S2 Threat modeling          -> STRIDE-style threats in business context
  S3 Hunt plan                -> prioritized files/vuln-classes to investigate
  S4 Detection                -> per-file vulnerability findings (structured)
  S5 Adversarial verification -> confirm exploitability, drop false positives
  S6 Report                   -> deduped Markdown + SARIF 2.1.0 output
  S7 Remediation              -> propose a minimal patch per confirmed finding
  S8 Validation                -> adversarial panel scores each proposed patch

This runs headless from any terminal — no IDE, editor, or Copilot required.

Model backends (vendor-neutral — pick per role):
  cli     Claude Code CLI (`claude` binary), print mode. No API key needed if
          you're already logged in (`claude` then `/login`).
  sdk     Anthropic SDK, direct API key (ANTHROPIC_API_KEY / ANTHROPIC_SDK_API_KEY).
          Supports a custom base URL for private gateways (ANTHROPIC_SDK_BASE_URL).
  openai  Any OpenAI-compatible chat-completions endpoint (OPENAI_API_KEY,
          OPENAI_BASE_URL, OPENAI_MODEL).

Backend restrictions (mirrors what these providers can actually do safely):
  - Detection stages (surface/threats/plan/detect/verify) run on ANY backend.
  - Remediation (S7) can propose a patch on any backend, but a patch proposed
    by the `openai` backend is marked report-only and is never auto-applied —
    the OpenAI-compatible path has no verified file-mutation guarantee here.
  - Validation (S8) is Anthropic-only (cli or sdk). A `validate` role pointed
    at `openai` is refused at startup (exit code 2), matching upstream design:
    an adversarial check on a *security fix* shouldn't run on an unverified
    file-editing path.

Usage:
  # single backend for everything
  export ANTHROPIC_API_KEY=sk-ant-...
  python3 vuln_pipeline.py --repo /path/to/target --backend sdk

  # Claude Code CLI login instead of an API key
  claude  # then /login
  python3 vuln_pipeline.py --repo /path/to/target --backend cli

  # mixed: cheap/fast OpenAI-compatible model for detection, Anthropic for
  # remediation + validation (matches upstream's default split)
  export OPENAI_API_KEY=... OPENAI_BASE_URL=https://api.openai.com/v1
  export ANTHROPIC_API_KEY=sk-ant-...
  python3 vuln_pipeline.py --repo /path/to/target \\
      --role-backend surface=openai --role-backend threats=openai \\
      --role-backend plan=openai --role-backend detect=openai --role-backend verify=openai \\
      --role-backend remediate=sdk --role-backend validate=sdk

  # check credentials/binaries for the backends you've configured, no tokens spent
  python3 vuln_pipeline.py --repo /path/to/target --doctor

  python3 vuln_pipeline.py --repo /path/to/target --stop-after detect   # detection only
  python3 vuln_pipeline.py --repo /path/to/target --apply-fixes         # + apply validated patches

Requires: pip install anthropic   (only needed for the sdk backend)
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys
import textwrap
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".go", ".rb", ".php",
    ".cs", ".cpp", ".c", ".h", ".hpp", ".rs", ".kt", ".swift", ".scala",
    ".sql", ".yaml", ".yml", ".tf", ".json",
}
SKIP_DIRS = {
    ".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build",
    "target", ".idea", ".vscode", "vendor", "coverage", ".next", ".tox",
}
MAX_FILE_BYTES = 60_000       # skip huge generated files
MAX_FILES_DEFAULT = 40        # cap POC scope; override with --max-files
STAGES = ["surface", "threats", "plan", "detect", "verify", "report", "remediate", "validate"]
ROLES = ["surface", "threats", "plan", "detect", "verify", "remediate", "validate"]
ANTHROPIC_ONLY_ROLES = {"validate"}          # refuse openai outright
RESTRICTED_APPLY_ROLES = {"remediate"}        # openai output allowed, but apply-fixes skips it

DEFAULT_SDK_MODEL = os.environ.get("VULN_PIPELINE_SDK_MODEL", "claude-sonnet-5")
DEFAULT_CLI_MODEL = os.environ.get("VULN_PIPELINE_CLI_MODEL", "")  # empty = let `claude` CLI pick its default
DEFAULT_OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o")
DEFAULT_OPENAI_BASE_URL = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")


# --------------------------------------------------------------------------
# Backend abstraction — vendor-neutral layer
# --------------------------------------------------------------------------

class Backend(ABC):
    """Common interface every model backend implements."""
    kind: str = "abstract"

    @abstractmethod
    def ask_json(self, system: str, user: str, max_tokens: int) -> Any:
        """Return parsed JSON, or None if the call/parse failed."""

    @abstractmethod
    def doctor(self) -> tuple[bool, str]:
        """Return (ok, message) — cheap credential/binary check, no tokens spent."""


def _strip_json_fences(text: str) -> str:
    text = text.strip()
    text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    return text


class AnthropicSDKBackend(Backend):
    kind = "sdk"

    def __init__(self, model: str = DEFAULT_SDK_MODEL):
        self.model = model
        self._client = None

    def _client_or_raise(self):
        if self._client is None:
            try:
                import anthropic
            except ImportError:
                sys.exit("Backend 'sdk' needs the anthropic package: pip install anthropic")
            api_key = os.environ.get("ANTHROPIC_SDK_API_KEY") or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                sys.exit("Backend 'sdk' needs ANTHROPIC_SDK_API_KEY or ANTHROPIC_API_KEY.")
            kwargs = {"api_key": api_key}
            base_url = os.environ.get("ANTHROPIC_SDK_BASE_URL")
            if base_url:
                kwargs["base_url"] = base_url
            self._client = anthropic.Anthropic(**kwargs)
        return self._client

    def ask_json(self, system: str, user: str, max_tokens: int) -> Any:
        client = self._client_or_raise()
        for attempt in range(2):
            resp = client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system + "\n\nRespond ONLY with valid JSON. No prose, no markdown fences.",
                messages=[{"role": "user", "content": user}],
            )
            text = "".join(b.text for b in resp.content if b.type == "text")
            try:
                return json.loads(_strip_json_fences(text))
            except json.JSONDecodeError:
                if attempt == 0:
                    user += "\n\nYour last response was not valid JSON. Return ONLY valid JSON this time."
                    continue
                print("  [warn] sdk backend: could not parse JSON response, skipping.", file=sys.stderr)
                return None
        return None

    def doctor(self) -> tuple[bool, str]:
        try:
            import anthropic  # noqa: F401
        except ImportError:
            return False, "anthropic package not installed (pip install anthropic)"
        if not (os.environ.get("ANTHROPIC_SDK_API_KEY") or os.environ.get("ANTHROPIC_API_KEY")):
            return False, "ANTHROPIC_SDK_API_KEY / ANTHROPIC_API_KEY not set"
        return True, f"sdk backend ready (model={self.model})"


class ClaudeCLIBackend(Backend):
    """Uses the `claude` CLI in non-interactive print mode. Requires a prior
    `claude` -> `/login` session (or CLAUDE_CODE_OAUTH_TOKEN) — no API key."""
    kind = "cli"

    def __init__(self, model: str = DEFAULT_CLI_MODEL):
        self.model = model

    def _binary(self) -> str | None:
        return shutil.which("claude")

    def ask_json(self, system: str, user: str, max_tokens: int) -> Any:
        binary = self._binary()
        if not binary:
            sys.exit("Backend 'cli' needs the `claude` CLI on PATH. Install Claude Code first.")
        prompt = (
            system
            + "\n\nRespond ONLY with valid JSON. No prose, no markdown fences.\n\n"
            + user
        )
        cmd = [binary, "-p", prompt, "--output-format", "text"]
        if self.model:
            cmd += ["--model", self.model]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            print(f"  [warn] cli backend exited {proc.returncode}: {proc.stderr.strip()[:300]}", file=sys.stderr)
            return None
        try:
            return json.loads(_strip_json_fences(proc.stdout))
        except json.JSONDecodeError:
            print("  [warn] cli backend: could not parse JSON response, skipping.", file=sys.stderr)
            return None

    def doctor(self) -> tuple[bool, str]:
        binary = self._binary()
        if not binary:
            return False, "`claude` CLI not found on PATH"
        if os.environ.get("CLAUDE_CODE_OAUTH_TOKEN"):
            return True, f"cli backend ready via CLAUDE_CODE_OAUTH_TOKEN ({binary})"
        return True, f"cli backend found ({binary}) — ensure you've run `claude` then `/login`"


class OpenAICompatBackend(Backend):
    """Any OpenAI-compatible chat-completions endpoint. No SDK dependency —
    plain HTTP so it works against OpenAI itself or any compatible gateway
    (local model server, Azure OpenAI-compatible proxy, etc.)."""
    kind = "openai"

    def __init__(self, model: str = DEFAULT_OPENAI_MODEL, base_url: str = DEFAULT_OPENAI_BASE_URL):
        self.model = model
        self.base_url = base_url.rstrip("/")

    def ask_json(self, system: str, user: str, max_tokens: int) -> Any:
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            sys.exit("Backend 'openai' needs OPENAI_API_KEY.")
        body = json.dumps({
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system + "\n\nRespond ONLY with valid JSON. No prose, no markdown fences."},
                {"role": "user", "content": user},
            ],
            "response_format": {"type": "json_object"},
        }).encode()
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=body,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                payload = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            print(f"  [warn] openai backend HTTP {e.code}: {e.read()[:300]}", file=sys.stderr)
            return None
        except urllib.error.URLError as e:
            print(f"  [warn] openai backend connection error: {e}", file=sys.stderr)
            return None
        try:
            text = payload["choices"][0]["message"]["content"]
            return json.loads(_strip_json_fences(text))
        except (KeyError, IndexError, json.JSONDecodeError):
            print("  [warn] openai backend: could not parse response, skipping.", file=sys.stderr)
            return None

    def doctor(self) -> tuple[bool, str]:
        if not os.environ.get("OPENAI_API_KEY"):
            return False, "OPENAI_API_KEY not set"
        return True, f"openai backend ready (model={self.model}, base_url={self.base_url})"


def make_backend(kind: str) -> Backend:
    if kind == "sdk":
        return AnthropicSDKBackend()
    if kind == "cli":
        return ClaudeCLIBackend()
    if kind == "openai":
        return OpenAICompatBackend()
    raise ValueError(f"Unknown backend: {kind}")


# --------------------------------------------------------------------------
# Agent — one role + its assigned backend
# --------------------------------------------------------------------------

ROLE_SYSTEM_PROMPTS = {
    "surface": "You are an attack-surface mapping agent. Given a repository file "
               "listing and samples, identify components, entry points (HTTP routes, "
               "CLI args, message consumers, file/DB IO), and trust boundaries. Output "
               'JSON: {"components": [...], "entry_points": [...], "trust_boundaries": [...]}',
    "threats": "You are an application-security threat modeler using STRIDE and OWASP "
               "Top 10 categories. Given the attack surface, produce prioritized threats "
               'in business context. Output JSON: {"threats": [{"category": str, '
               '"description": str, "affected_components": [str], "priority": "high|medium|low"}]}',
    "plan": "You are a vulnerability research strategist. Given threats, produce a "
            "prioritized hunting plan: which files/areas to inspect and which vuln "
            'classes (CWE) to look for in each. Output JSON: {"targets": [{"path": str, '
            '"focus_cwe": [str], "rationale": str}]}',
    "detect": "You are a security code reviewer specialized in finding real, exploitable "
              "vulnerabilities (not style issues). For the given file, report only "
              "findings you are reasonably confident are genuine security flaws with a "
              "plausible exploit path. Output JSON: {\"findings\": [{"
              '"cwe": str, "title": str, "severity": "critical|high|medium|low", '
              '"line_start": int, "line_end": int, "description": str, '
              '"exploit_scenario": str, "confidence": "high|medium|low"}]}',
    "verify": "You are an adversarial verification agent. Given a candidate finding and "
              "its surrounding code, argue against it first: could this be a false "
              "positive (input already validated upstream, dead code, test fixture, "
              "framework-level mitigation)? Then decide. Output JSON: {\"verdict\": "
              '"confirmed|rejected", "reasoning": str, "attack_path": str}',
    "remediate": "You are a remediation agent. Given a confirmed finding and the file "
                 "content, produce the smallest possible fix that closes the "
                 "vulnerability without changing unrelated behavior. Output JSON: "
                 '{"summary": str, "patched_file_content": str, "risk_notes": str}. '
                 "patched_file_content must be the FULL file content after the fix.",
    "validate": "You are an adversarial patch-validation panel (security-architect + "
                "penetration-tester perspectives combined). Given the original "
                "vulnerability, the proposed patch, and the diff, decide whether the "
                "patch actually closes the attack path without introducing regressions "
                'or new issues. Output JSON: {"verdict": "validated|validation_failed|'
                'needs_review", "reasoning": str, "residual_risk": str}',
}


class Agent:
    def __init__(self, role: str, backend: Backend):
        self.role = role
        self.backend = backend
        self.system = ROLE_SYSTEM_PROMPTS[role]

    def ask_json(self, user_prompt: str, max_tokens: int = 4000) -> Any:
        return self.backend.ask_json(self.system, user_prompt, max_tokens)


def resolve_role_backends(default_backend: str, overrides: dict[str, str]) -> dict[str, Backend]:
    """Build one Backend instance per role, applying defaults + --role-backend
    overrides, and enforcing the same-provider restrictions upstream tools use."""
    resolved_kind = {role: overrides.get(role, default_backend) for role in ROLES}

    for role in ANTHROPIC_ONLY_ROLES:
        if resolved_kind[role] == "openai":
            sys.exit(
                f"Role '{role}' cannot run on backend 'openai' — validation must run on "
                f"'cli' or 'sdk'. Set --role-backend {role}=sdk (or cli)."
            )

    # cache backend instances by kind so roles sharing a provider share one client
    cache: dict[str, Backend] = {}
    backends: dict[str, Backend] = {}
    for role, kind in resolved_kind.items():
        if kind not in cache:
            cache[kind] = make_backend(kind)
        backends[role] = cache[kind]
    return backends


def make_agents(role_backends: dict[str, Backend]) -> dict[str, Agent]:
    return {role: Agent(role, backend) for role, backend in role_backends.items()}


def run_doctor(role_backends: dict[str, Backend]) -> None:
    print("Backend check (no tokens spent):\n")
    seen: dict[int, tuple[bool, str]] = {}
    all_ok = True
    for role, backend in role_backends.items():
        key = id(backend)
        if key not in seen:
            seen[key] = backend.doctor()
        ok, msg = seen[key]
        all_ok = all_ok and ok
        status = "OK  " if ok else "FAIL"
        print(f"  [{status}] {role:10s} -> {backend.kind:6s} : {msg}")
    print()
    sys.exit(0 if all_ok else 1)


# --------------------------------------------------------------------------
# Repo collection
# --------------------------------------------------------------------------

def collect_files(repo: Path, max_files: int) -> list[Path]:
    files = []
    for p in sorted(repo.rglob("*")):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        if p.suffix.lower() not in CODE_EXTENSIONS:
            continue
        try:
            if p.stat().st_size > MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        files.append(p)
        if len(files) >= max_files:
            break
    return files


def read_snippet(p: Path, max_chars: int = 8000) -> str:
    try:
        text = p.read_text(errors="replace")
    except OSError:
        return ""
    return text[:max_chars]


# --------------------------------------------------------------------------
# Pipeline stages
# --------------------------------------------------------------------------

def stage_surface(agents: dict, repo: Path, files: list[Path]) -> dict:
    print("[S1] Mapping attack surface...")
    listing = "\n".join(str(f.relative_to(repo)) for f in files)
    samples = "\n\n".join(
        f"--- {f.relative_to(repo)} ---\n{read_snippet(f, 1500)}" for f in files[:8]
    )
    prompt = f"File listing:\n{listing}\n\nSample contents:\n{samples}"
    return agents["surface"].ask_json(prompt) or {"components": [], "entry_points": [], "trust_boundaries": []}


def stage_threats(agents: dict, surface: dict) -> dict:
    print("[S2] Threat modeling...")
    prompt = f"Attack surface:\n{json.dumps(surface, indent=2)}"
    return agents["threats"].ask_json(prompt) or {"threats": []}


def stage_plan(agents: dict, repo: Path, files: list[Path], threats: dict) -> dict:
    print("[S3] Building hunting plan...")
    listing = "\n".join(str(f.relative_to(repo)) for f in files)
    prompt = f"Threats:\n{json.dumps(threats, indent=2)}\n\nAvailable files:\n{listing}"
    plan = agents["plan"].ask_json(prompt) or {"targets": []}
    valid_paths = {str(f.relative_to(repo)) for f in files}
    plan["targets"] = [t for t in plan.get("targets", []) if t.get("path") in valid_paths]
    return plan


def stage_detect(agents: dict, repo: Path, plan: dict) -> list[dict]:
    print(f"[S4] Detecting vulnerabilities across {len(plan.get('targets', []))} targeted files...")
    findings = []
    for target in plan.get("targets", []):
        path = repo / target["path"]
        content = read_snippet(path, MAX_FILE_BYTES)
        prompt = (
            f"File: {target['path']}\n"
            f"Focus CWE classes: {target.get('focus_cwe', [])}\n"
            f"Rationale: {target.get('rationale', '')}\n\n"
            f"--- content ---\n{content}"
        )
        result = agents["detect"].ask_json(prompt)
        for f in (result or {}).get("findings", []):
            f["file"] = target["path"]
            f["id"] = hashlib.sha1(f"{target['path']}{f.get('title','')}{f.get('line_start','')}".encode()).hexdigest()[:10]
            findings.append(f)
    print(f"       -> {len(findings)} candidate findings")
    return findings


def stage_verify(agents: dict, repo: Path, findings: list[dict]) -> list[dict]:
    print(f"[S5] Adversarially verifying {len(findings)} candidates...")
    confirmed = []
    for f in findings:
        content = read_snippet(repo / f["file"], MAX_FILE_BYTES)
        prompt = f"Candidate finding:\n{json.dumps(f, indent=2)}\n\n--- file content ---\n{content}"
        result = agents["verify"].ask_json(prompt)
        if result and result.get("verdict") == "confirmed":
            f["verification"] = result
            confirmed.append(f)
    print(f"       -> {len(confirmed)} confirmed after verification")
    return confirmed


def stage_report(repo: Path, out_dir: Path, confirmed: list[dict]) -> tuple[Path, Path]:
    print("[S6] Writing report (Markdown + SARIF)...")
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    md_path = out_dir / f"report_{ts}.md"
    sarif_path = out_dir / f"report_{ts}.sarif"

    lines = [f"# Vulnerability Scan Report", f"\nRepo: `{repo}`  \nGenerated: {ts}\n"]
    for f in sorted(confirmed, key=lambda x: {"critical": 0, "high": 1, "medium": 2, "low": 3}.get(x.get("severity", "low"), 4)):
        lines.append(textwrap.dedent(f"""
            ## [{f.get('severity','?').upper()}] {f.get('title','Untitled')} ({f.get('id')})
            **File:** `{f['file']}` lines {f.get('line_start','?')}-{f.get('line_end','?')}
            **CWE:** {f.get('cwe','?')}

            {f.get('description','')}

            **Exploit scenario:** {f.get('exploit_scenario','')}

            **Verification:** {f.get('verification', {}).get('reasoning', '')}
            **Attack path:** {f.get('verification', {}).get('attack_path', '')}
            """))
    md_path.write_text("\n".join(lines))

    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {"name": "vuln-pipeline-poc", "informationUri": "", "rules": []}},
            "results": [
                {
                    "ruleId": f.get("cwe", "unknown"),
                    "level": {"critical": "error", "high": "error", "medium": "warning", "low": "note"}.get(f.get("severity", "low"), "note"),
                    "message": {"text": f.get("description", "")},
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {"uri": f["file"]},
                            "region": {"startLine": f.get("line_start", 1), "endLine": f.get("line_end", f.get("line_start", 1))},
                        }
                    }],
                } for f in confirmed
            ],
        }],
    }
    sarif_path.write_text(json.dumps(sarif, indent=2))
    print(f"       -> {md_path.name}, {sarif_path.name}")
    return md_path, sarif_path


def stage_remediate(agents: dict, repo: Path, out_dir: Path, confirmed: list[dict]) -> list[dict]:
    print(f"[S7] Proposing fixes for {len(confirmed)} confirmed findings...")
    remediations = []
    patch_dir = out_dir / "patches"
    patch_dir.mkdir(exist_ok=True)
    backend_kind = agents["remediate"].backend.kind
    for f in confirmed:
        path = repo / f["file"]
        original = read_snippet(path, MAX_FILE_BYTES)
        prompt = f"Finding:\n{json.dumps(f, indent=2)}\n\n--- original file content ---\n{original}"
        result = agents["remediate"].ask_json(prompt, max_tokens=8000)
        if not result or "patched_file_content" not in result:
            continue
        patched = result["patched_file_content"]
        diff_text = unified_diff(original, patched, f["file"])
        patch_path = patch_dir / f"{f['id']}.patch"
        patch_path.write_text(diff_text)
        remediations.append({
            "finding_id": f["id"],
            "file": f["file"],
            "summary": result.get("summary", ""),
            "risk_notes": result.get("risk_notes", ""),
            "patch_path": str(patch_path),
            "patched_content": patched,
            "original_content": original,
            "proposed_by_backend": backend_kind,
            "report_only": backend_kind == "openai",  # matches upstream: openai path can't apply file edits
        })
    print(f"       -> {len(remediations)} candidate patches written to {patch_dir}"
          + (f" (backend={backend_kind}; report-only, will not be auto-applied)" if backend_kind == "openai" else ""))
    return remediations


def unified_diff(original: str, patched: str, filename: str) -> str:
    import difflib
    return "".join(difflib.unified_diff(
        original.splitlines(keepends=True),
        patched.splitlines(keepends=True),
        fromfile=f"a/{filename}", tofile=f"b/{filename}",
    ))


def stage_validate(agents: dict, confirmed: list[dict], remediations: list[dict]) -> list[dict]:
    print(f"[S8] Validating {len(remediations)} proposed patches...")
    by_id = {f["id"]: f for f in confirmed}
    verdicts = []
    for r in remediations:
        finding = by_id.get(r["finding_id"], {})
        diff_text = unified_diff(r["original_content"], r["patched_content"], r["file"])
        prompt = (
            f"Original finding:\n{json.dumps(finding, indent=2)}\n\n"
            f"Proposed fix summary: {r['summary']}\n\n"
            f"--- diff ---\n{diff_text}"
        )
        result = agents["validate"].ask_json(prompt)
        r["validation"] = result or {"verdict": "needs_review", "reasoning": "validation call failed"}
        verdicts.append(r)
        print(f"       {r['file']} [{r['finding_id']}] -> {r['validation'].get('verdict')}")
    return verdicts


def apply_validated_patches(repo: Path, remediations: list[dict]) -> None:
    applied, skipped = 0, 0
    for r in remediations:
        if r.get("report_only"):
            print(f"  [skip] {r['file']}: proposed by 'openai' backend — report-only, not applying.")
            skipped += 1
            continue
        if r.get("validation", {}).get("verdict") != "validated":
            skipped += 1
            continue
        proc = subprocess.run(
            ["git", "apply", "--check", r["patch_path"]], cwd=repo, capture_output=True, text=True
        )
        if proc.returncode != 0:
            print(f"  [skip] {r['file']}: patch does not apply cleanly ({proc.stderr.strip()[:200]})")
            skipped += 1
            continue
        subprocess.run(["git", "apply", r["patch_path"]], cwd=repo, check=True)
        applied += 1
        print(f"  [applied] {r['file']}")
    print(f"Applied {applied} patch(es), skipped {skipped} (not validated, not applicable, or report-only).")


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def parse_role_backend_overrides(pairs: list[str]) -> dict[str, str]:
    overrides = {}
    for pair in pairs or []:
        if "=" not in pair:
            sys.exit(f"--role-backend expects role=backend, got: {pair}")
        role, kind = pair.split("=", 1)
        if role not in ROLES:
            sys.exit(f"Unknown role '{role}' in --role-backend. Valid roles: {', '.join(ROLES)}")
        if kind not in ("cli", "sdk", "openai"):
            sys.exit(f"Unknown backend '{kind}' in --role-backend. Valid: cli, sdk, openai")
        overrides[role] = kind
    return overrides


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", required=True, type=Path, help="Path to local repository to scan")
    ap.add_argument("--output-dir", type=Path, default=None, help="Where to write reports (default: <repo>/security-scan)")
    ap.add_argument("--backend", choices=["cli", "sdk", "openai"], default="sdk",
                     help="Default backend for every role (default: sdk)")
    ap.add_argument("--role-backend", action="append", metavar="ROLE=BACKEND",
                     help="Override the backend for one role, e.g. --role-backend detect=openai. "
                          "Repeatable. Roles: " + ", ".join(ROLES))
    ap.add_argument("--max-files", type=int, default=MAX_FILES_DEFAULT, help="Max files to consider for the hunting plan")
    ap.add_argument("--stop-after", choices=STAGES, default="validate", help="Stop after this stage")
    ap.add_argument("--apply-fixes", action="store_true", help="Apply validated, non-report-only patches via `git apply`")
    ap.add_argument("--doctor", action="store_true", help="Check credentials/binaries for configured backends and exit")
    args = ap.parse_args()

    overrides = parse_role_backend_overrides(args.role_backend)
    role_backends = resolve_role_backends(args.backend, overrides)

    if args.doctor:
        run_doctor(role_backends)
        return

    repo = args.repo.resolve()
    if not repo.is_dir():
        sys.exit(f"Not a directory: {repo}")
    out_dir = args.output_dir or (repo / "security-scan")
    out_dir.mkdir(parents=True, exist_ok=True)

    agents = make_agents(role_backends)

    files = collect_files(repo, args.max_files)
    if not files:
        sys.exit("No matching code files found under --repo.")
    print(f"Collected {len(files)} files from {repo}")
    print("Backends: " + ", ".join(f"{role}={backend.kind}" for role, backend in role_backends.items()) + "\n")

    surface = stage_surface(agents, repo, files)
    if args.stop_after == "surface":
        return dump_and_exit(out_dir, {"surface": surface})

    threats = stage_threats(agents, surface)
    if args.stop_after == "threats":
        return dump_and_exit(out_dir, {"surface": surface, "threats": threats})

    plan = stage_plan(agents, repo, files, threats)
    if args.stop_after == "plan":
        return dump_and_exit(out_dir, {"surface": surface, "threats": threats, "plan": plan})

    findings = stage_detect(agents, repo, plan)
    if args.stop_after == "detect":
        return dump_and_exit(out_dir, {"findings": findings})

    confirmed = stage_verify(agents, repo, findings)
    if args.stop_after == "verify":
        return dump_and_exit(out_dir, {"confirmed": confirmed})

    stage_report(repo, out_dir, confirmed)
    if args.stop_after == "report" or not confirmed:
        return

    remediations = stage_remediate(agents, repo, out_dir, confirmed)
    if args.stop_after == "remediate" or not remediations:
        return dump_and_exit(out_dir, {"remediations": [strip_content(r) for r in remediations]})

    remediations = stage_validate(agents, confirmed, remediations)
    dump_and_exit(out_dir, {"remediations": [strip_content(r) for r in remediations]})

    if args.apply_fixes:
        apply_validated_patches(repo, remediations)
    else:
        validated = sum(1 for r in remediations if r.get("validation", {}).get("verdict") == "validated" and not r.get("report_only"))
        print(f"\n{validated}/{len(remediations)} patches validated and applicable. Re-run with --apply-fixes to apply them (git apply).")


def strip_content(r: dict) -> dict:
    return {k: v for k, v in r.items() if k not in ("patched_content", "original_content")}


def dump_and_exit(out_dir: Path, data: dict) -> None:
    p = out_dir / f"pipeline_state_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    p.write_text(json.dumps(data, indent=2, default=str))
    print(f"State written to {p}")


if __name__ == "__main__":
    main()
