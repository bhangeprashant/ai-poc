# vuln-pipeline-poc

Agentic vulnerability discovery, remediation & validation POC.

An 8-stage pipeline that scans a local repository with an LLM acting as a
sequence of specialist agents, running headless from any terminal (no IDE
or editor required):

1. **Attack surface mapping** — components, entry points, trust boundaries
2. **Threat modeling** — STRIDE / OWASP Top 10, prioritized
3. **Hunt plan** — which files/CWE classes to target
4. **Detection** — per-file vulnerability findings
5. **Adversarial verification** — confirms exploitability, drops false positives
6. **Report** — Markdown + SARIF 2.1.0 output
7. **Remediation** — proposes a minimal patch per confirmed finding (`.patch` files, never edits source directly)
8. **Validation** — an adversarial panel scores each proposed patch before it can be applied

## Install

```bash
pip install -r requirements.txt
```

`anthropic` is only required for the `sdk` backend — skip it if you're only
using `cli` or `openai`.

## Model backends (vendor-neutral)

| Backend  | Needs                                                   |
|----------|----------------------------------------------------------|
| `cli`    | `claude` binary on PATH, logged in (or `CLAUDE_CODE_OAUTH_TOKEN`) |
| `sdk`    | `ANTHROPIC_API_KEY` (or `ANTHROPIC_SDK_API_KEY`)         |
| `openai` | `OPENAI_API_KEY` (+ optional `OPENAI_BASE_URL`, `OPENAI_MODEL`) |

Backends can be set globally (`--backend`) or per pipeline role
(`--role-backend detect=openai`). Two restrictions are enforced:

- `validate` role refuses to run on `openai` (exit code 2 at startup) — the
  adversarial patch check is Anthropic-only (`cli` or `sdk`).
- `remediate` patches proposed via `openai` are marked report-only and are
  skipped by `--apply-fixes`.

## Usage

```bash
# credential/binary check only, no tokens spent
python3 vuln_pipeline.py --repo /path/to/target --doctor

# single backend for everything
export ANTHROPIC_API_KEY=sk-ant-...
python3 vuln_pipeline.py --repo /path/to/target --backend sdk

# detection-only, cheapest way to smoke-test
python3 vuln_pipeline.py --repo /path/to/target --stop-after detect

# mixed backends: OpenAI-compatible model for detection, Anthropic for remediation/validation
python3 vuln_pipeline.py --repo /path/to/target \
  --role-backend surface=openai --role-backend threats=openai \
  --role-backend plan=openai --role-backend detect=openai --role-backend verify=openai \
  --role-backend remediate=sdk --role-backend validate=sdk

# full pipeline, then apply only validated + Anthropic-proposed patches
python3 vuln_pipeline.py --repo /path/to/target --apply-fixes
```

## sample_repo/

A tiny fixture with a deliberate SQL-injection bug (string-formatted query in
`app/db.py`), useful for a first end-to-end smoke test:

```bash
python3 vuln_pipeline.py --repo sample_repo --stop-after detect
```

## Safety notes

- Detection, verification, and validation are always read-only.
- Remediation never edits your source tree directly — it writes `.patch`
  files under `<output-dir>/patches/`.
- `--apply-fixes` only applies patches that are both `validated` and not
  `report_only`, and runs `git apply --check` first.
- Findings and fixes are model output, not proof — review before merging.
- Only scan code you own or have permission to test.
