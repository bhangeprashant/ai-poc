"""
Sandbox pool API.

  POST /v1/sandbox/acquire      lease a browser/exec sandbox (blocks up to timeout_s)
  POST /v1/sandbox/release      free a lease
  POST /v1/sandbox/register     a newly-scaled-up pod joins the pool (called from its own startup hook)
  POST /v1/sandbox/deregister   pod is being terminated (called from preStop hook)
  GET  /v1/sandbox/status       human-readable pool state
  GET  /v1/sandbox/metrics      Prometheus text format -- point KEDA's Prometheus trigger here

Mount into the harness app, or run standalone:
    uvicorn sandbox_api:app --port 8081
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from sandbox_pool import POOL, Backpressure

app = FastAPI(title="Sandbox Pool", version="1.0")


class RegisterReq(BaseModel):
    endpoint: str
    capacity: int = 1
    kind: str = "browser"
    capabilities: Dict[str, str] = {}


class AcquireReq(BaseModel):
    session_id: str
    kind: str = "browser"
    timeout_s: Optional[float] = None
    requirements: Dict[str, str] = {}


class ReleaseReq(BaseModel):
    lease_id: str
    replica_id: str


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {"ok": True}


@app.post("/v1/sandbox/acquire")
def acquire(req: AcquireReq) -> Dict[str, Any]:
    try:
        lease = POOL.acquire(req.session_id, req.kind, req.timeout_s, req.requirements)
    except Backpressure as exc:
        # 503, not 500: this is the pool correctly refusing under load,
        # not a bug. A caller should back off and retry, not treat it as
        # a fault.
        raise HTTPException(503, str(exc))
    return {"lease_id": lease.lease_id, "replica_id": lease.replica_id,
            "endpoint": lease.endpoint, "kind": lease.kind,
            "granted_at": lease.granted_at}


@app.post("/v1/sandbox/release")
def release(req: ReleaseReq) -> Dict[str, Any]:
    from sandbox_pool import Lease
    POOL.release(Lease(lease_id=req.lease_id, replica_id=req.replica_id,
                       endpoint="", session_id="", kind=""))
    return {"released": True}


@app.post("/v1/sandbox/register")
def register(req: RegisterReq) -> Dict[str, Any]:
    """Called by a pod's own startup hook once it's ready to accept work.
    In Kubernetes: a postStart lifecycle hook or the app's first readiness
    tick POSTs here with its own pod IP as `endpoint`."""
    rid = POOL.register(req.endpoint, req.capacity, req.kind, req.capabilities)
    return {"replica_id": rid}


@app.post("/v1/sandbox/deregister/{replica_id}")
def deregister(replica_id: str) -> Dict[str, Any]:
    """Called from a preStop lifecycle hook so in-flight leases drain
    before the pod actually terminates, instead of a lease dying mid-use."""
    ok = POOL.deregister(replica_id)
    if not ok:
        raise HTTPException(404, "Replica not found")
    return {"deregistered": True}


@app.get("/v1/sandbox/status")
def status() -> Dict[str, Any]:
    return POOL.status()


@app.get("/v1/sandbox/metrics", response_class=PlainTextResponse)
def metrics() -> str:
    return POOL.metrics_prometheus()
