---
name: deploy-safety
kind: constraint
description: No deployment step proceeds without a named rollback path and a verified ticket reference.
applies_to: deploy, release, rollout, production
---
Before any deployment-affecting action:
1. A rollback path must be stated explicitly, not assumed.
2. The change must reference a tracked ticket.
3. Blast radius must be named before the step is proposed.
