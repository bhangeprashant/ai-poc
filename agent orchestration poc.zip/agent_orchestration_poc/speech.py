"""
Speech-to-text — browser-agnostic.

The Web Speech API only works in Chrome/Edge and sends audio to the browser
vendor's servers, which is a non-starter in a regulated environment. This
module takes the other approach: the browser records with MediaRecorder
(Chrome, Firefox, Safari 14.1+, Edge) and POSTs the audio here.

Backends, selected by STT_BACKEND, tried in order of preference:

  faster_whisper  Self-hosted, runs on CPU. Audio never leaves your VPC.
                  Recommended for BFSI. `pip install faster-whisper`
  transcribe      AWS Transcribe. Managed, but audio goes to AWS (usually
                  acceptable if you're already on AWS with a BAA/DPA).
  none            No backend configured -- returns a clear error the UI
                  surfaces, rather than silently failing.

Browser container formats differ: Chrome/Firefox emit audio/webm (Opus),
Safari emits audio/mp4 (AAC). faster-whisper reads both via ffmpeg, which
must be present in the image. `apt-get install ffmpeg`.

Model sizing (faster-whisper, CPU, int8):
  tiny/base   fast, weak on technical vocabulary — not recommended here
  small       good balance, ~2-3x realtime on 4 cores
  distil-large-v3  best accuracy per unit compute; the default below

Domain vocabulary matters more than model size for this use case. Speech
models mangle internal system names and acronyms, so `initial_prompt`
below seeds the decoder with your vocabulary. Extend STT_VOCABULARY with
your real service names.
"""

from __future__ import annotations

import os
import tempfile
from typing import Any, Dict, List, Optional

STT_BACKEND = os.environ.get("STT_BACKEND", "auto")
STT_MODEL = os.environ.get("STT_MODEL", "distil-large-v3")
STT_DEVICE = os.environ.get("STT_DEVICE", "cpu")
STT_COMPUTE = os.environ.get("STT_COMPUTE_TYPE", "int8")
STT_LANGUAGE = os.environ.get("STT_LANGUAGE", "en")
MAX_AUDIO_BYTES = int(os.environ.get("MAX_AUDIO_BYTES", str(25 * 1024 * 1024)))

# Seeds the decoder so technical terms survive transcription. This is the
# single highest-leverage knob for accuracy on enterprise speech.
STT_VOCABULARY: List[str] = [
    "Jira", "Confluence", "Kubernetes", "EKS", "Bedrock", "AgentCore",
    "orchestrator", "regression", "compliance", "RCA", "SLA", "pipeline",
    "deployment", "rollback", "canary", "sandbox", "webhook", "endpoint",
]


class STTUnavailable(RuntimeError):
    """No usable backend. The UI turns this into a clear message."""


_whisper_model = None


def _load_whisper():
    global _whisper_model
    if _whisper_model is None:
        from faster_whisper import WhisperModel  # type: ignore
        _whisper_model = WhisperModel(STT_MODEL, device=STT_DEVICE,
                                       compute_type=STT_COMPUTE)
    return _whisper_model


def _available_backend() -> str:
    if STT_BACKEND != "auto":
        return STT_BACKEND
    try:
        import faster_whisper  # noqa: F401
        return "faster_whisper"
    except ImportError:
        pass
    if os.environ.get("AWS_TRANSCRIBE_BUCKET"):
        return "transcribe"
    return "none"


def backend_status() -> Dict[str, Any]:
    """Reported at bootstrap so the UI can label the mic honestly."""
    backend = _available_backend()
    return {
        "backend": backend,
        "available": backend != "none",
        "model": STT_MODEL if backend == "faster_whisper" else None,
        "note": {
            "faster_whisper": "Self-hosted — audio stays on your infrastructure",
            "transcribe": "AWS Transcribe — audio is sent to AWS",
            "none": "No transcription backend configured. Install faster-whisper or set AWS_TRANSCRIBE_BUCKET.",
        }[backend],
    }


def _transcribe_faster_whisper(path: str, hint: Optional[str]) -> Dict[str, Any]:
    model = _load_whisper()
    prompt = ", ".join(STT_VOCABULARY)
    if hint:
        prompt = f"{hint}. {prompt}"

    segments, info = model.transcribe(
        path,
        language=STT_LANGUAGE,
        initial_prompt=prompt,
        vad_filter=True,                     # drops silence, big speedup
        vad_parameters={"min_silence_duration_ms": 500},
        beam_size=5,
    )
    parts, confidences = [], []
    for seg in segments:
        parts.append(seg.text.strip())
        if getattr(seg, "avg_logprob", None) is not None:
            confidences.append(seg.avg_logprob)

    text = " ".join(p for p in parts if p).strip()
    avg_logprob = sum(confidences) / len(confidences) if confidences else None
    return {
        "text": text,
        "language": getattr(info, "language", STT_LANGUAGE),
        "duration_s": round(getattr(info, "duration", 0.0), 2),
        # avg_logprob below about -0.8 usually means a noisy or unclear take
        "low_confidence": avg_logprob is not None and avg_logprob < -0.8,
    }


def _transcribe_aws(path: str, hint: Optional[str]) -> Dict[str, Any]:
    """AWS Transcribe. Requires a staging bucket; jobs are asynchronous."""
    import json
    import time
    import uuid
    import boto3  # type: ignore
    import urllib.request

    bucket = os.environ["AWS_TRANSCRIBE_BUCKET"]
    region = os.environ.get("AWS_REGION", "ap-south-1")
    s3, tr = boto3.client("s3", region_name=region), boto3.client("transcribe", region_name=region)

    job = "stt-" + uuid.uuid4().hex[:12]
    key = f"stt-input/{job}"
    s3.upload_file(path, bucket, key)

    tr.start_transcription_job(
        TranscriptionJobName=job,
        Media={"MediaFileUri": f"s3://{bucket}/{key}"},
        MediaFormat=os.environ.get("STT_MEDIA_FORMAT", "webm"),
        LanguageCode=os.environ.get("STT_AWS_LANGUAGE", "en-IN"),
    )

    deadline = time.time() + 120
    while time.time() < deadline:
        status = tr.get_transcription_job(TranscriptionJobName=job)["TranscriptionJob"]
        state = status["TranscriptionJobStatus"]
        if state == "COMPLETED":
            uri = status["Transcript"]["TranscriptFileUri"]
            with urllib.request.urlopen(uri, timeout=30) as resp:
                data = json.loads(resp.read())
            text = data["results"]["transcripts"][0]["transcript"]
            return {"text": text, "language": "en", "duration_s": None,
                    "low_confidence": False}
        if state == "FAILED":
            raise STTUnavailable(status.get("FailureReason", "Transcription job failed"))
        time.sleep(2)
    raise STTUnavailable("Transcription timed out after 120s")


def transcribe(audio_bytes: bytes, filename: str = "audio.webm",
               hint: Optional[str] = None) -> Dict[str, Any]:
    """Transcribe recorded audio. Raises STTUnavailable with a message the UI shows."""
    if not audio_bytes:
        raise STTUnavailable("No audio received")
    if len(audio_bytes) > MAX_AUDIO_BYTES:
        raise STTUnavailable(
            f"Recording is {len(audio_bytes) // (1024*1024)}MB, over the "
            f"{MAX_AUDIO_BYTES // (1024*1024)}MB limit. Record a shorter clip."
        )

    backend = _available_backend()
    if backend == "none":
        raise STTUnavailable(backend_status()["note"])

    suffix = os.path.splitext(filename)[1] or ".webm"
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name

        if backend == "faster_whisper":
            result = _transcribe_faster_whisper(tmp_path, hint)
        elif backend == "transcribe":
            result = _transcribe_aws(tmp_path, hint)
        else:
            raise STTUnavailable(f"Unknown STT backend '{backend}'")

        result["backend"] = backend
        result["bytes"] = len(audio_bytes)
        return result
    except STTUnavailable:
        raise
    except ImportError as exc:
        raise STTUnavailable(f"Backend '{backend}' is not installed: {exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise STTUnavailable(f"Transcription failed: {exc}") from exc
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
