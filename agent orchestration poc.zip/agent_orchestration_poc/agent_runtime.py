"""
Generic agent runtime — the single container image every dynamically
created agent runs.

There is deliberately no JiraAgent / ComplianceAgent image. This one
image reads AGENT_ROLE and AGENT_TOOLS from the environment (set by the
deployment manifest) or accepts them at runtime via /configure (used by
the warm-pool backend), and becomes that agent. That is what makes agent
creation seamless: no per-role image build, no registry push per run.

Endpoints:
  GET  /healthz     readiness probe target referenced by the manifest
  POST /configure   warm-pool lease: become {role, tools}
  POST /execute     run one plan step, return the synthesized result
  POST /release     warm-pool release: forget current identity

Run locally:  uvicorn agent_runtime:app --port 9000
Container:    see Dockerfile
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from models import PlanStep
from agents import ExecutorAgent

app = FastAPI(title="Agent Runtime")


class _Identity:
    def __init__(self) -> None:
        self.role: Optional[str] = os.environ.get("AGENT_ROLE") or None
        raw_tools = os.environ.get("AGENT_TOOLS", "")
        self.tools: List[str] = [t for t in raw_tools.split(",") if t]
        self.instance_id: Optional[str] = os.environ.get("AGENT_INSTANCE_ID")
        self.executor: Optional[ExecutorAgent] = None
        if self.role:
            self.executor = ExecutorAgent(role=self.role, tools=self.tools)
            if self.instance_id:
                self.executor.instance_id = self.instance_id

    def configure(self, role: str, tools: List[str], instance_id: Optional[str]) -> None:
        self.role, self.tools, self.instance_id = role, tools, instance_id
        self.executor = ExecutorAgent(role=role, tools=tools)
        if instance_id:
            self.executor.instance_id = instance_id

    def release(self) -> None:
        self.role, self.tools, self.instance_id, self.executor = None, [], None, None


IDENTITY = _Identity()


class ConfigureRequest(BaseModel):
    role: str
    tools: List[str]
    instance_id: Optional[str] = None


class ExecuteRequest(BaseModel):
    step_id: str
    instruction: str
    tools: List[str]
    depends_on: List[str] = []
    upstream_results: Dict[str, Any] = {}


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {
        "status": "ok",
        "configured": IDENTITY.role is not None,
        "role": IDENTITY.role,
        "tools": IDENTITY.tools,
    }


@app.post("/configure")
def configure(req: ConfigureRequest) -> Dict[str, Any]:
    IDENTITY.configure(req.role, req.tools, req.instance_id)
    return {"status": "configured", "role": IDENTITY.role,
            "instance_id": IDENTITY.executor.instance_id}


@app.post("/release")
def release() -> Dict[str, Any]:
    IDENTITY.release()
    return {"status": "released"}


@app.post("/execute")
def execute(req: ExecuteRequest) -> Dict[str, Any]:
    if IDENTITY.executor is None:
        raise HTTPException(status_code=409,
                            detail="runtime not configured — POST /configure first")

    step = PlanStep(
        step_id=req.step_id,
        agent_role=IDENTITY.role or "unknown",
        instruction=req.instruction,
        tools=req.tools or IDENTITY.tools,
        depends_on=req.depends_on,
    )
    trace: List[Dict[str, Any]] = []
    result = IDENTITY.executor.run_step(step, req.upstream_results, trace)
    return {"result": result, "trace": trace}
