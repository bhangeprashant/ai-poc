"""
Skills + Memory layers.

Maps to two of the four lobes in the reference diagram:

  Skills   -> operational procedure, normative constraints, decision heuristics
  Memory   -> working context, episodic experience, semantic knowledge,
              personalized memory, and compression

Skills are filesystem-discovered SKILL.md packs, loaded ON DEMAND rather
than all at once. That is the whole point: loading every skill into every
prompt is what makes long agent runs expensive and unfocused. The harness
loads a skill's full body only when the loop selects it.

Normative constraints are handled differently from the other two skill
kinds. Procedures and heuristics are advisory -- they shape how the agent
works. Constraints are enforced: they are injected into every prompt
regardless of skill selection, AND checked in code before tool dispatch.
An instruction the model can decline to follow is not a control.
"""

from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from llm_client import complete_json

SKILLS_DIR = os.environ.get("HARNESS_SKILLS_DIR", "./skills")
MAX_WORKING_CHARS = int(os.environ.get("HARNESS_MAX_WORKING_CHARS", "12000"))
COMPACT_TRIGGER_RATIO = 0.8


# ---------------------------------------------------------------- Skills ----

@dataclass
class Skill:
    name: str
    kind: str                # "procedure" | "constraint" | "heuristic"
    summary: str             # always in context -- cheap
    body: str                # loaded only when selected -- expensive
    applies_to: List[str] = field(default_factory=list)


def _parse_skill_md(path: str) -> Optional[Skill]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw = fh.read()
    except OSError:
        return None

    meta: Dict[str, str] = {}
    body = raw
    if raw.startswith("---"):
        parts = raw.split("---", 2)
        if len(parts) >= 3:
            for line in parts[1].strip().splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip()
            body = parts[2].strip()

    name = meta.get("name") or os.path.basename(os.path.dirname(path))
    return Skill(
        name=name,
        kind=meta.get("kind", "procedure"),
        summary=meta.get("description", body[:160]),
        body=body,
        applies_to=[t.strip() for t in meta.get("applies_to", "").split(",") if t.strip()],
    )


class SkillRegistry:
    def __init__(self, root: str = SKILLS_DIR):
        self.root = root
        self._skills: Dict[str, Skill] = {}
        self._lock = threading.Lock()
        self.reload()

    def reload(self) -> int:
        found: Dict[str, Skill] = {}
        if os.path.isdir(self.root):
            for entry in sorted(os.listdir(self.root)):
                p = os.path.join(self.root, entry, "SKILL.md")
                if os.path.isfile(p):
                    sk = _parse_skill_md(p)
                    if sk:
                        found[sk.name] = sk
        for sk in _BUILTIN_SKILLS:
            found.setdefault(sk.name, sk)
        with self._lock:
            self._skills = found
        return len(found)

    def all(self) -> List[Skill]:
        with self._lock:
            return list(self._skills.values())

    def get(self, name: str) -> Optional[Skill]:
        with self._lock:
            return self._skills.get(name)

    def constraints(self) -> List[Skill]:
        return [s for s in self.all() if s.kind == "constraint"]

    def catalog_for_prompt(self) -> str:
        """Names + one-liners only. The body is fetched on selection."""
        lines = []
        for s in self.all():
            if s.kind == "constraint":
                continue
            lines.append(f"- {s.name} ({s.kind}): {s.summary}")
        return "\n".join(lines) or "- (no optional skills registered)"

    def constraint_block(self) -> str:
        cs = self.constraints()
        if not cs:
            return ""
        return "Non-negotiable constraints:\n" + "\n".join(
            f"- {c.name}: {c.summary}" for c in cs)

    def select(self, goal: str, max_skills: int = 3) -> List[Skill]:
        """Pick relevant skills by lexical overlap, then load their bodies."""
        goal_terms = set(re.findall(r"[a-z]{3,}", goal.lower()))
        scored: List[Tuple[int, Skill]] = []
        for s in self.all():
            if s.kind == "constraint":
                continue
            hay = f"{s.name} {s.summary} {' '.join(s.applies_to)}".lower()
            score = sum(1 for t in goal_terms if t in hay)
            if score:
                scored.append((score, s))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in scored[:max_skills]]


_BUILTIN_SKILLS = [
    Skill(
        name="change-request-procedure", kind="procedure",
        summary="How to raise, review, and land a change in a regulated estate.",
        body=("1. Confirm the change has a tracked ticket.\n"
              "2. Identify blast radius and rollback path before proposing steps.\n"
              "3. Any production-affecting step requires an explicit approval checkpoint.\n"
              "4. Record the decision and its rationale on the ticket."),
        applies_to=["jira", "git", "deploy", "release", "change"],
    ),
    Skill(
        name="evidence-grounding", kind="constraint",
        summary="Every factual claim must trace to a tool result in this session; "
                "state gaps explicitly instead of filling them.",
        body="Do not assert system state that no tool call in this session returned.",
    ),
    Skill(
        name="no-silent-writes", kind="constraint",
        summary="No write-scoped or irreversible tool call proceeds without an "
                "approval checkpoint resolved by the caller.",
        body="Write tools must pause at a checkpoint regardless of confidence.",
    ),
    Skill(
        name="incident-triage-heuristics", kind="heuristic",
        summary="Ordering rules for narrowing an incident quickly.",
        body=("Prefer the cheapest discriminating signal first.\n"
              "Establish the time window before pulling logs.\n"
              "Correlate deploys before suspecting infrastructure.\n"
              "Stop when the evidence supports one hypothesis and contradicts the rest."),
        applies_to=["incident", "outage", "rca", "triage", "error", "failure"],
    ),
]


SKILLS = SkillRegistry()


# ---------------------------------------------------------------- Memory ----

@dataclass
class MemoryRecord:
    kind: str                # working | episodic | semantic | personalized
    content: str
    ts: float = 0.0
    tags: List[str] = field(default_factory=list)


class SessionMemory:
    """Four tiers, per the diagram. Only `working` is context-budgeted.

    working      -- this turn's observations; compacted when it grows
    episodic     -- what happened in prior turns of this session
    semantic     -- durable facts the caller supplied or a tool established
    personalized -- caller-specific preferences carried across sessions
    """

    def __init__(self) -> None:
        self.working: List[MemoryRecord] = []
        self.episodic: List[MemoryRecord] = []
        self.semantic: List[MemoryRecord] = []
        self.personalized: List[MemoryRecord] = []
        self._lock = threading.Lock()
        self.compactions = 0

    def add(self, kind: str, content: str, tags: Optional[List[str]] = None) -> None:
        import time as _t
        rec = MemoryRecord(kind=kind, content=content, ts=_t.time(), tags=tags or [])
        with self._lock:
            getattr(self, kind).append(rec)

    def working_chars(self) -> int:
        with self._lock:
            return sum(len(r.content) for r in self.working)

    def needs_compaction(self) -> bool:
        return self.working_chars() > MAX_WORKING_CHARS * COMPACT_TRIGGER_RATIO

    def compact(self) -> Dict[str, Any]:
        """Fold working context into one episodic summary.

        This is the single most important cost lever on a long run: without
        it, every step re-sends every prior observation, so token spend grows
        quadratically with step count rather than linearly.
        """
        with self._lock:
            if not self.working:
                return {"compacted": 0, "before": 0, "after": 0}
            before = sum(len(r.content) for r in self.working)
            blob = "\n".join(f"- {r.content}" for r in self.working)[:20000]
            count = len(self.working)

        def mock() -> Dict[str, Any]:
            head = [r.content[:120] for r in self.working[:4]]
            return {"summary": "Prior observations in this turn: " + " | ".join(head)
                              + (f" (+{count - 4} more)" if count > 4 else "")}

        out = complete_json(
            "Compress agent observations. Preserve every concrete finding, "
            "identifier, number, and unresolved question. Drop restatement and "
            "narration. Never invent detail not present in the input.",
            f"Observations:\n{blob}\n\nReturn JSON: {{\"summary\": str}}",
            mock,
        )
        summary = out.get("summary", "")[:MAX_WORKING_CHARS // 2]
        import time as _t
        with self._lock:
            self.episodic.append(MemoryRecord(kind="episodic", content=summary,
                                              ts=_t.time(), tags=["compaction"]))
            self.working = []
            self.compactions += 1
            after = len(summary)
        return {"compacted": count, "before": before, "after": after}

    def build_context(self, budget: int = MAX_WORKING_CHARS) -> str:
        """Assemble prompt context, newest-first, within a hard budget."""
        parts: List[str] = []
        with self._lock:
            if self.personalized:
                parts.append("Caller preferences:\n" + "\n".join(
                    f"- {r.content}" for r in self.personalized[-5:]))
            if self.semantic:
                parts.append("Established facts:\n" + "\n".join(
                    f"- {r.content}" for r in self.semantic[-10:]))
            if self.episodic:
                parts.append("Earlier in this session:\n" + "\n".join(
                    f"- {r.content}" for r in self.episodic[-5:]))
            if self.working:
                parts.append("Observations this turn:\n" + "\n".join(
                    f"- {r.content}" for r in self.working))
        text = "\n\n".join(parts)
        if len(text) > budget:
            text = text[-budget:]
            text = "[earlier context truncated]\n" + text
        return text

    def stats(self) -> Dict[str, int]:
        with self._lock:
            return {
                "working": len(self.working), "episodic": len(self.episodic),
                "semantic": len(self.semantic), "personalized": len(self.personalized),
                "working_chars": sum(len(r.content) for r in self.working),
                "compactions": self.compactions,
            }
