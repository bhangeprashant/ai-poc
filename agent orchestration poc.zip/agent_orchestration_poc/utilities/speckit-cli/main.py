"""
speckit-cli utility -- runs GitHub Spec Kit's own scaffolding scripts.

Scripts under dotspecify/scripts/bash/ are copied VERBATIM from a real
`specify init --integration generic` run. They are plain bash: branch
creation, directory scaffolding, template resolution. No model, no
network call, no agent binding of any kind.

Phase -> script mapping matches spec-kit's own layout:
  specify   -> create-new-feature.sh   (new spec.md from a feature description)
  plan      -> setup-plan.sh           (scaffold plan.md from the template)
  tasks     -> setup-tasks.sh          (scaffold tasks.md from the template)
  check     -> check-prerequisites.sh  (verify prior artifacts exist before a phase)

The phases with no deterministic script (clarify, analyze, implement,
constitution, converge, checklist) are pure reasoning over existing
files -- that's the matching speckit.<phase> SKILL.md's job, run by the
harness's own model, not this utility. This utility only ever does the
file/branch mechanics spec-kit itself defines as scriptable.
"""

import os
import subprocess

SCRIPT_MAP = {
    "specify": "create-new-feature.sh",
    "plan": "setup-plan.sh",
    "tasks": "setup-tasks.sh",
    "check": "check-prerequisites.sh",
}

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.join(HERE, "dotspecify", "scripts", "bash")


def run(params: dict) -> dict:
    phase = params.get("phase")
    args = params.get("args") or []
    repo_dir = params.get("repo_dir")

    if phase not in SCRIPT_MAP:
        return {"error": "unknown_phase",
                "detail": f"'{phase}' has no script. Known: {list(SCRIPT_MAP)}. "
                          "Other phases (clarify/analyze/implement/constitution/"
                          "converge/checklist) are pure-reasoning -- use the "
                          "matching speckit.<phase> skill instead."}

    script = os.path.join(SCRIPTS_DIR, SCRIPT_MAP[phase])
    if not os.path.isfile(script):
        return {"error": "script_missing", "detail": script}
    if not repo_dir or not os.path.isdir(repo_dir):
        return {"error": "invalid_repo_dir", "detail": repo_dir}

    try:
        proc = subprocess.run(
            ["bash", script, "--json", *args],
            cwd=repo_dir, capture_output=True, text=True, timeout=30,
        )
        return {
            "phase": phase, "script": SCRIPT_MAP[phase],
            "exit_code": proc.returncode,
            "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-2000:],
        }
    except subprocess.TimeoutExpired:
        return {"error": "timeout", "detail": f"{script} exceeded 30s"}
