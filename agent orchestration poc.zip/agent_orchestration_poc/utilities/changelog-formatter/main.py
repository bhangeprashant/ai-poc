"""Pure function, reviewed via PR -- safe to run in-process, untrusted input
never reaches exec/eval/subprocess, so trusted: true in the manifest holds."""


def run(params: dict) -> dict:
    commits = params.get("commits", [])
    groups = {"feat": [], "fix": [], "chore": [], "other": []}
    for c in commits:
        c = str(c)
        prefix = c.split(":")[0].lower().strip() if ":" in c else ""
        key = prefix if prefix in groups else "other"
        groups[key].append(c)

    lines = []
    for label, key in [("Features", "feat"), ("Fixes", "fix"),
                       ("Chores", "chore"), ("Other", "other")]:
        if groups[key]:
            lines.append(f"## {label}")
            lines.extend(f"- {c}" for c in groups[key])
    return {"changelog": "\n".join(lines), "grouped": groups}
