"""
End-to-end vulnerability remediation flow.

    python remediation_e2e.py

Eleven stages, every gate real:

   1  clone                 repo_read_tool (low, auto)
   2  fetch findings        security_scanner_tool (low, auto)
   3  prioritise            severity, then KG blast radius
   4  triage                FP rules; criticals escalate, never auto-close
   5  baseline              BEFORE any change, or regressions are unfalsifiable
   6  spec chain            per finding: specify -> plan -> tasks -> analyze
   7  validate per finding  isolate each fix; quarantine only what broke
   8  review packet         everything a human needs to say no
   9  HUMAN GATE            blocks the push, not the commit
  10  publish               repo_publish_tool (high, gated)
  11  rescan                the scanner closes the finding, not the tests
"""

from __future__ import annotations

import time
from typing import Any, Dict, List

from harness_context import SKILLS
from knowledge_graph import KG, seed_demo_estate
from vuln_remediation import RemediationPipeline, prioritise

STATE_PATH = "/tmp/remediation_state.json"


def banner(n: int, title: str, note: str = "") -> None:
    print(f"\n{'='*76}\n  STAGE {n}  {title}\n{'='*76}")
    if note:
        print(f"  {note}\n")


def blast_map(findings: List[Dict[str, Any]]) -> Dict[str, int]:
    """Blast radius per finding, from the service its file belongs to."""
    out: Dict[str, int] = {}
    for f in findings:
        svc = f["file"].split("/")[0]
        node = f"service:{svc}"
        if node in KG.nodes:
            out[f["id"]] = KG.blast_radius(node)["reached"]
    return out


def main() -> None:
    SKILLS.reload()
    seed_demo_estate(KG)
    pipe = RemediationPipeline(repo="payments-api")

    banner(1, "Clone repository", "repo_read_tool — low risk, auto-approved.")
    print("  ", pipe.stage_clone())

    banner(2, "Fetch findings — Fortify SSC + Sonatype IQ")
    findings = pipe.stage_fetch()
    for f in findings:
        print(f"   {f['id']:10} {f['severity']:8} conf={f['confidence']:6} "
              f"{f['rule']:22} {f['file'].split('/')[-1]}")

    banner(3, "Prioritise — severity, then blast radius",
           "Scanner fetch order reflects pagination, not urgency.")
    blast = blast_map(findings)
    findings = prioritise(findings, blast)
    by_id = {f["id"]: f for f in findings}
    for f in findings:
        print(f"   {f['id']:10} {f['severity']:8} blast={blast.get(f['id'], 0)}")

    banner(4, "Triage — false positives first",
           "Read-only agent. Holds no write tools, so it cannot 'fix' what it judges.")
    actionable, dismissed, escalated = pipe.stage_triage(findings)
    for v in dismissed:
        print(f"   DISMISSED  {v.finding_id:10} [{v.rule}]")
    for v in escalated:
        print(f"   ESCALATED  {v.finding_id:10} FP rule matched but severity is critical")
    for v in actionable:
        print(f"   ACTIONABLE {v.finding_id:10} {by_id[v.finding_id]['rule']}")

    banner(5, "Capture pre-fix baseline",
           "Before any change. stage_validate refuses to run without this.")
    b = pipe.stage_baseline()
    print(f"   {b['passed']}/{b['total']} passing; pre-existing failures: {b['failed'] or 'none'}")

    banner(6, "Spec-kit chain per finding",
           "specify -> plan -> tasks -> analyze, following spec-kit's own auto edges.\n"
           "  Stops before implement — spec-kit marks that edge non-automatic.")
    pipe.stage_remediate(actionable, by_id, timeout_s=15, full_chain=True)
    for v in actionable:
        rec = pipe.records[v.finding_id]
        print(f"   {v.finding_id:10} {rec.stage:12} {' -> '.join(rec.spec_phases)}")

    banner(7, "Validate each fix in isolation",
           "Batch validation lets one bad fix block every clean one.")
    reports = pipe.stage_validate_per_finding(actionable)
    for fid, r in reports.items():
        mark = "OK " if r.clean else "BAD"
        print(f"   [{mark}] {fid:10} new_failures={r.new_failures or 'none'}")

    publishable, quarantined = pipe.publishable(actionable)
    print(f"\n   PUBLISHABLE  {[v.finding_id for v in publishable]}")
    print(f"   QUARANTINED  {[v.finding_id for v in quarantined]}")

    banner(8, "Review packet")
    worst = max((reports[v.finding_id] for v in quarantined),
                key=lambda r: len(r.new_failures), default=None)
    packet = {
        "repo": pipe.repo,
        "publishable": [v.finding_id for v in publishable],
        "quarantined": [v.finding_id for v in quarantined],
        "fp_dismissed": [v.finding_id for v in dismissed],
        "fp_escalated": [v.finding_id for v in escalated],
        "blocking": bool(escalated),
    }
    for k, v in packet.items():
        print(f"   {k:20} {v}")
    if quarantined:
        print(f"\n   Quarantined fixes are NOT blocking the batch — they are held")
        print(f"   back for rework while clean fixes proceed.")

    banner(9, "Human gate",
           "Gates the push, not the commit. A commit is recoverable; a push\n"
           "  publishes the fix AND the vulnerability to everyone with read access.")
    if packet["blocking"]:
        print("   BLOCKED — unconfirmed FP dismissal on a critical finding.")
        print("   Publishing is unreachable in this state.")
        finish(pipe)
        return
    if not publishable:
        print("   Nothing publishable — every actionable fix was quarantined.")
        finish(pipe)
        return
    print(f"   Reviewer sees {len(publishable)} clean fix(es), "
          f"{len(quarantined)} held, {len(dismissed)} FP dismissals.")
    print("   Reviewer decision: APPROVED")

    banner(10, "Branch, commit, push", "repo_publish_tool — high risk, gated above.")
    pub = pipe.stage_publish(
        branch="security/remediation-batch-1",
        files=[by_id[v.finding_id]["file"] for v in publishable],
        message="fix(security): remediate validated SAST/SCA findings\n\n"
                + "\n".join(f"- {v.finding_id} {by_id[v.finding_id]['rule']}"
                            for v in publishable))
    print(f"   branch {pub['branch']['branch']} · commit {pub['commit']['sha']} "
          f"· {pub['push']['status']}")

    banner(11, "Verification rescan",
           "A fix is done when the scanner agrees, not when tests pass.")
    rescan = pipe.stage_rescan("security/remediation-batch-1",
                               [v.finding_id for v in publishable])
    print(f"   verified={rescan['verified']} still_open={rescan['still_open'] or 'none'} "
          f"new_findings={rescan['new_findings']}")

    finish(pipe)


def finish(pipe: RemediationPipeline) -> None:
    path = pipe.save_state(STATE_PATH)
    print(f"\n{'='*76}\n  AUDIT TRAIL\n{'='*76}")
    for line in pipe.audit:
        print(f"   {line}")
    print(f"\n{'='*76}\n  FINAL STATE PER FINDING\n{'='*76}")
    for fid, rec in sorted(pipe.records.items()):
        flags = []
        if rec.validated:
            flags.append("validated")
        if rec.quarantined:
            flags.append("QUARANTINED")
        print(f"   {fid:10} {rec.severity:8} {rec.stage:14} {' '.join(flags)}")
    print(f"\n   state persisted -> {path} (resumable)")
    pipe.broker.shutdown()


if __name__ == "__main__":
    main()
