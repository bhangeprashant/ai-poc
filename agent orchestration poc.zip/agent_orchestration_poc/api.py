"""
FastAPI app: the hosted agent page's backend.

Run with:  uvicorn api:app --reload --port 8080
Then open http://localhost:8080

Flow:
  POST /api/runs/plan            -> plan only; returns awaiting_approval
  GET  /api/runs/pending         -> reviewer queue
  GET  /api/runs/{run_id}        -> current state of a run
  POST /api/runs/{run_id}/decide -> approve (with optional edits) or reject
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from orchestrator_pipeline import plan_run, execute_run, get_run
from approvals import STORE, TOOL_RISK
from tool_registry import list_tools
from deployment import DEPLOY_BACKEND

app = FastAPI(title="Agent Forge - dynamic multi-agent orchestration")


class PlanRequest(BaseModel):
    agent_md: str
    query: str
    backend: Optional[str] = None


class DecisionRequest(BaseModel):
    approved: bool
    reviewer: str = "unknown"
    reason: str = ""
    removed_roles: List[str] = []
    revoked_tools: Dict[str, List[str]] = {}


@app.get("/")
def index():
    return FileResponse("static/index.html")


@app.get("/api/tools")
def get_tools():
    tools = []
    for t in list_tools():
        severity = TOOL_RISK.get(t["name"], (None, ""))[0]
        tools.append({**t, "risk": severity.value if severity else "medium"})
    return {"tools": tools, "default_backend": DEPLOY_BACKEND}


@app.post("/api/runs/plan")
def create_plan(req: PlanRequest):
    return plan_run(req.agent_md, req.query, backend=req.backend)


@app.get("/api/runs/pending")
def pending():
    return {"pending": STORE.list_pending()}


@app.get("/api/runs/{run_id}")
def run_status(run_id: str):
    return get_run(run_id)


@app.post("/api/runs/{run_id}/decide")
def decide(run_id: str, req: DecisionRequest):
    edits = None
    if req.removed_roles or req.revoked_tools:
        edits = {"removed_roles": req.removed_roles, "revoked_tools": req.revoked_tools}
    return execute_run(
        run_id,
        approved=req.approved,
        reviewer=req.reviewer,
        edits=edits,
        rejection_reason=req.reason,
    )


app.mount("/static", StaticFiles(directory="static"), name="static")
