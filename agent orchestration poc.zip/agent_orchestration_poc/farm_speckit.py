"""
Spec Kit phases as FARM AGENTS.

The thing that makes spec-kit genuinely interesting in a farm is not that
it can run there -- it's that spec-kit is ALREADY an agent graph and says
so in its own artifacts. Every generated command file carries frontmatter
like:

    handoffs:
      - label: Create Tasks
        agent: speckit.tasks      <-- spec-kit's own word, not ours
        send: true                <-- automatic edge, no human in between

Read that graph out and you get a routing table:

    constitution ──> specify ──> plan ══> tasks ══> analyze
                       │           │        │
                       └> clarify  └> checklist  └> implement

    ══>  auto_send: true   (runs without a decision)
    ──>  auto_send: false  (a human or policy decides)

Running all phases as ONE agent -- what an editor does -- collapses three
things a farm can keep separate:

1. LEAST PRIVILEGE PER PHASE. `specify` needs to read a repo and write a
   markdown file. `implement` needs to write code and run tests. An editor
   agent holds the union of every phase's permissions for the whole
   session. As separate farm agents, each phase gets only its own grants,
   so a spec-writing step physically cannot execute code.

2. INDEPENDENT REVIEW. `analyze` and `checklist` critique the artifacts
   that `specify`/`plan` produced. If the same agent with the same context
   window does both, it is reviewing its own reasoning with every prior
   justification still in context. As separate agents with separate
   sessions, the critic sees only the artifacts -- not the rationale that
   produced them.

3. FAN-OUT. One approved spec and plan can drive N repositories in
   parallel, each with its own implement agent, its own approval
   checkpoints, and its own failure surface.

This module builds that. It does not replace the harness loop -- each
phase-agent is a normal HarnessRun with a normal approval gate.
"""

from __future__ import annotations

import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from farm_core import (
    PolicyBroker, PolicyRule, FarmAgent, FarmCoordinator, aggregate,
    APPROVE, DENY,
)
from harness_context import SKILLS
from harness_core import SESSIONS, SessionState
from harness_loop import run_turn_async


# ------------------------------------------------- least-privilege profile --

# What each phase is actually allowed to touch. This is the core of the
# argument for phase-per-agent: these differ sharply, and a single agent
# running all phases would need the union of them for the whole session.
PHASE_GRANTS: Dict[str, List[str]] = {
    "speckit.constitution": ["knowledge_search_tool"],
    "speckit.specify":      ["speckit-cli", "knowledge_search_tool"],
    "speckit.clarify":      ["knowledge_search_tool"],
    "speckit.plan":         ["speckit-cli", "knowledge_search_tool"],
    "speckit.tasks":        ["speckit-cli", "knowledge_search_tool"],
    # Critics get READ ONLY -- a reviewer that can edit the artifact it is
    # reviewing is not a reviewer.
    "speckit.analyze":      ["knowledge_search_tool"],
    "speckit.checklist":    ["knowledge_search_tool"],
    # Only implement gets write + execute. This is the whole point.
    "speckit.implement":    ["git_tool", "execution_harness_tool", "jira_tool"],
    "speckit.converge":     ["knowledge_search_tool", "jira_tool"],
    "speckit.taskstoissues": ["jira_tool"],
}

PHASE_PROFILE: Dict[str, str] = {
    "speckit.constitution": "compliance",
    "speckit.specify": "engineer",
    "speckit.clarify": "engineer",
    "speckit.plan": "engineer",
    "speckit.tasks": "engineer",
    "speckit.analyze": "qa",
    "speckit.checklist": "qa",
    "speckit.implement": "engineer",
    "speckit.converge": "engineer",
    "speckit.taskstoissues": "engineer",
}


@dataclass
class HandoffEdge:
    to_agent: str
    auto_send: bool


def load_handoff_graph() -> Dict[str, List[HandoffEdge]]:
    """Read the routing table out of the speckit skills' frontmatter.

    This graph is spec-kit's, not ours -- we only transcribe it.
    """
    graph: Dict[str, List[HandoffEdge]] = {}
    for skill in SKILLS.all():
        if not skill.name.startswith("speckit"):
            continue
        path = os.path.join(SKILLS.root, skill.name, "SKILL.md")
        edges: List[HandoffEdge] = []
        if os.path.isfile(path):
            text = open(path, encoding="utf-8").read()
            m = re.match(r"^---\n(.*?)\n---", text, re.S)
            if m and "handoffs:" in m.group(1):
                block = m.group(1).split("handoffs:", 1)[1]
                for eb in re.finditer(r"-\s+agent:\s*(\S+)\s*\n\s+auto_send:\s*(\w+)", block):
                    edges.append(HandoffEdge(eb.group(1), eb.group(2).lower() == "true"))
        graph[skill.name] = edges
    return graph


def phase_agent(phase: str, suffix: str = "") -> FarmAgent:
    """One farm agent for one spec-kit phase, with only that phase's grants."""
    name = f"{phase}{('.' + suffix) if suffix else ''}"
    return FarmAgent(
        name=name,
        profile=PHASE_PROFILE.get(phase, "engineer"),
        tools=PHASE_GRANTS.get(phase, ["knowledge_search_tool"]),
        metadata={"phase": phase, "target": suffix},
    )


# ---------------------------------------------------------------- pipeline --

@dataclass
class PipelineStep:
    phase: str
    agent: str
    state: str
    verdict: str
    edge_type: str          # "auto" | "gated" | "entry"
    granted_tools: List[str] = field(default_factory=list)


class SpecKitPipeline:
    """Walks spec-kit's own handoff graph, one farm agent per phase.

    Auto-send edges advance without a decision. Non-auto edges are where
    the farm's PolicyBroker (or a human) chooses whether to continue --
    which is exactly where spec-kit intends a human to steer.
    """

    def __init__(self, broker: PolicyBroker, target: str = ""):
        self.broker = broker
        self.target = target
        self.graph = load_handoff_graph()
        self.steps: List[PipelineStep] = []

    def run_phase(self, phase: str, goal: str, edge_type: str,
                  timeout_s: float = 20.0) -> PipelineStep:
        a = phase_agent(phase, self.target)
        s = SESSIONS.create(a.name, a.profile, a.tools, a.metadata)
        self.broker.watch(s)
        run_turn_async(s, goal)

        deadline = time.time() + timeout_s
        while time.time() < deadline:
            if s.state in (SessionState.COMPLETED.value, SessionState.FAILED.value):
                break
            time.sleep(0.05)

        r = s.last_result or {}
        step = PipelineStep(
            phase=phase, agent=a.name, state=s.state,
            verdict=(r.get("evaluation") or {}).get("verdict", ""),
            edge_type=edge_type, granted_tools=a.tools,
        )
        self.steps.append(step)
        return step

    def run_from(self, start: str, goal: str, max_depth: int = 4,
                 follow_auto_only: bool = True) -> List[PipelineStep]:
        """Follow the handoff graph from `start`.

        With follow_auto_only=True (the default) the pipeline advances
        ONLY across edges spec-kit marked `send: true`, and stops at every
        gated edge. That is the safe reading of the graph: spec-kit marked
        those edges non-automatic because a human is meant to steer there.
        """
        self.run_phase(start, goal, "entry")
        current, depth = start, 0
        while depth < max_depth:
            edges = self.graph.get(current, [])
            nxt = [e for e in edges if e.auto_send] if follow_auto_only else edges
            if not nxt:
                break
            edge = nxt[0]
            self.run_phase(edge.to_agent,
                           f"Continue the spec-driven workflow for {self.target or 'this feature'}",
                           "auto")
            current = edge.to_agent
            depth += 1
        return self.steps

    def gated_edges_from(self, phase: str) -> List[str]:
        return [e.to_agent for e in self.graph.get(phase, []) if not e.auto_send]


# ------------------------------------------------------------ parallel work --

def parallel_critics(broker: PolicyBroker, target: str,
                     timeout_s: float = 20.0) -> List[PipelineStep]:
    """Run analyze + checklist as INDEPENDENT agents, concurrently.

    Both are read-only by grant. Neither can edit what it reviews, and
    neither shares a context window with the agent that produced the
    artifacts -- so the critique is of the output, not of a rationale the
    critic already agreed with.
    """
    steps: List[PipelineStep] = []
    lock = threading.Lock()

    def run(phase: str) -> None:
        p = SpecKitPipeline(broker, target)
        step = p.run_phase(
            phase, f"Review the spec, plan, and tasks for {target}", "parallel",
            timeout_s=timeout_s)
        with lock:
            steps.append(step)

    threads = [threading.Thread(target=run, args=(ph,))
               for ph in ("speckit.analyze", "speckit.checklist")]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=timeout_s + 5)
    return steps


def fan_out_implement(broker: PolicyBroker, repos: List[str],
                      timeout_s: float = 25.0) -> List[Any]:
    """One approved plan -> N repos, each with its own implement agent.

    Each gets its own session, own checkpoints, own failure surface. One
    repo stalling on an approval does not block the others.
    """
    agents = [phase_agent("speckit.implement", r) for r in repos]
    coord = FarmCoordinator(broker)
    return coord.dispatch(
        agents,
        lambda a: f"Execute the implementation tasks for {a.metadata['target']}",
        timeout_s=timeout_s)


def default_broker() -> PolicyBroker:
    """Policy tuned for a spec-kit farm.

    Note what is NOT auto-approved: `implement`'s code execution. Spec-kit
    can plan freely; changing a real system stays a decision.
    """
    return PolicyBroker(rules=[
        PolicyRule("reads", APPROVE, max_severity="low",
                   reason="Read-only phases carry no side effects."),
        PolicyRule("scaffolding", APPROVE, tools=["speckit-cli"], max_severity="medium",
                   reason="Spec scaffolding writes only into specs/ on a feature branch."),
        PolicyRule("no-auto-exec", DENY, tools=["execution_harness_tool"],
                   reason="Implementation may plan freely; executing code against a real "
                          "system is never auto-approved."),
        # git/jira writes from implement fall through to human escalation.
    ])
