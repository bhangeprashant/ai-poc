"""
Harness core — sessions, events, and the resumable event bus.

This is the substrate the orchestrator loop runs on. The design constraint
that shapes everything here: the CALLER IS ANOTHER AGENT, not a browser.

That changes three things versus a chat backend:

1. Reconnects are normal, not exceptional. A calling agent may be
   restarted, rescheduled onto another pod, or hit a proxy idle timeout
   mid-run. So every event carries a monotonic `seq`, and a caller
   reattaches with `?after=<seq>` to get everything it missed. Events are
   retained per session in a ring buffer for exactly this reason. Without
   this, a 40-second network blip silently truncates the caller's view of
   a 10-minute run and it can never tell.

2. Backpressure must not stall the run. Each subscriber gets its own
   bounded queue. If a slow caller stops draining, its queue drops the
   OLDEST events and marks a gap -- the run continues at full speed, and
   the caller can detect the gap via seq discontinuity and re-fetch from
   the ring buffer. A shared unbounded queue would let one slow consumer
   pin memory for everyone.

3. The terminal event matters more than the stream. A caller that missed
   everything still needs the result, so the final state is always
   retrievable from the session itself, not only from the stream.
"""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Deque, Dict, Iterator, List, Optional

MAX_EVENTS_RETAINED = int(os.environ.get("HARNESS_MAX_EVENTS", "2000"))
SUBSCRIBER_QUEUE_MAX = int(os.environ.get("HARNESS_SUB_QUEUE", "256"))
SESSION_IDLE_TTL_S = int(os.environ.get("HARNESS_SESSION_TTL_S", str(60 * 60)))


class EventType(str, Enum):
    # lifecycle
    SESSION_CREATED = "session.created"
    TURN_STARTED = "turn.started"
    TURN_COMPLETED = "turn.completed"
    TURN_FAILED = "turn.failed"
    # reasoning / loop
    PLAN_DRAFTED = "plan.drafted"
    STEP_STARTED = "step.started"
    STEP_COMPLETED = "step.completed"
    # tools
    TOOL_CALL_STARTED = "tool.started"
    TOOL_CALL_COMPLETED = "tool.completed"
    TOOL_CALL_FAILED = "tool.failed"
    # human / caller checkpoints
    APPROVAL_REQUESTED = "approval.requested"
    APPROVAL_RESOLVED = "approval.resolved"
    QUESTION_ASKED = "question.asked"
    QUESTION_ANSWERED = "question.answered"
    # context engineering
    SUBAGENT_SPAWNED = "subagent.spawned"
    SUBAGENT_RETURNED = "subagent.returned"
    CONTEXT_COMPACTED = "context.compacted"
    # output
    MESSAGE_DELTA = "message.delta"
    ARTIFACT_CREATED = "artifact.created"
    EVAL_SCORED = "eval.scored"
    # stream control
    STREAM_GAP = "stream.gap"
    HEARTBEAT = "heartbeat"


class SessionState(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    AWAITING_APPROVAL = "awaiting_approval"
    AWAITING_ANSWER = "awaiting_answer"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class HarnessEvent:
    seq: int
    type: str
    session_id: str
    turn_id: Optional[str]
    data: Dict[str, Any]
    ts: float = field(default_factory=time.time)

    def to_sse(self) -> str:
        """SSE frame. The id: line is what lets a caller resume precisely."""
        payload = json.dumps({
            "seq": self.seq, "type": self.type, "session_id": self.session_id,
            "turn_id": self.turn_id, "data": self.data, "ts": self.ts,
        })
        return f"id: {self.seq}\nevent: {self.type}\ndata: {payload}\n\n"


class _Subscriber:
    """One attached caller. Bounded queue; drops oldest and flags a gap."""

    def __init__(self, after_seq: int = 0):
        self.queue: Deque[HarnessEvent] = deque()
        self.cond = threading.Condition()
        self.after_seq = after_seq
        self.dropped = 0
        self.closed = False

    def push(self, ev: HarnessEvent) -> None:
        with self.cond:
            if self.closed:
                return
            if len(self.queue) >= SUBSCRIBER_QUEUE_MAX:
                self.queue.popleft()
                self.dropped += 1
            self.queue.append(ev)
            self.cond.notify()

    def close(self) -> None:
        with self.cond:
            self.closed = True
            self.cond.notify_all()


class EventBus:
    """Per-session fan-out with replay. Thread-safe."""

    def __init__(self, session_id: str):
        self.session_id = session_id
        self._lock = threading.Lock()
        self._seq = 0
        self._log: Deque[HarnessEvent] = deque(maxlen=MAX_EVENTS_RETAINED)
        self._subs: List[_Subscriber] = []
        self._terminal = False

    def emit(self, etype: EventType, data: Dict[str, Any],
             turn_id: Optional[str] = None) -> HarnessEvent:
        with self._lock:
            self._seq += 1
            ev = HarnessEvent(seq=self._seq, type=etype.value,
                              session_id=self.session_id, turn_id=turn_id,
                              data=data)
            self._log.append(ev)
            subs = list(self._subs)
        for s in subs:
            s.push(ev)
        return ev

    def replay_after(self, after_seq: int) -> List[HarnessEvent]:
        with self._lock:
            return [e for e in self._log if e.seq > after_seq]

    def oldest_retained_seq(self) -> int:
        with self._lock:
            return self._log[0].seq if self._log else 0

    def current_seq(self) -> int:
        with self._lock:
            return self._seq

    def subscribe(self, after_seq: int = 0) -> _Subscriber:
        sub = _Subscriber(after_seq)
        with self._lock:
            self._subs.append(sub)
        return sub

    def unsubscribe(self, sub: _Subscriber) -> None:
        sub.close()
        with self._lock:
            if sub in self._subs:
                self._subs.remove(sub)

    def mark_terminal(self) -> None:
        with self._lock:
            self._terminal = True
        for s in list(self._subs):
            s.push(HarnessEvent(seq=self._seq, type="__eof__",
                                session_id=self.session_id, turn_id=None, data={}))

    def stream(self, after_seq: int = 0, heartbeat_s: float = 15.0) -> Iterator[HarnessEvent]:
        """Yield replay-then-live events. Caller must consume promptly."""
        missed = self.replay_after(after_seq)
        oldest = self.oldest_retained_seq()
        if after_seq and oldest and after_seq < oldest - 1:
            # Requested resume point already aged out of the ring buffer.
            # Tell the caller explicitly rather than silently under-delivering.
            yield HarnessEvent(seq=after_seq, type=EventType.STREAM_GAP.value,
                               session_id=self.session_id, turn_id=None,
                               data={"missing_before": oldest,
                                     "detail": "Requested events aged out of retention; "
                                               "fetch full state via GET /v1/sessions/{id}."})
        for ev in missed:
            yield ev

        sub = self.subscribe(after_seq)
        last = missed[-1].seq if missed else after_seq
        try:
            while True:
                with sub.cond:
                    if not sub.queue:
                        sub.cond.wait(timeout=heartbeat_s)
                    if sub.closed and not sub.queue:
                        return
                    if not sub.queue:
                        yield HarnessEvent(seq=last, type=EventType.HEARTBEAT.value,
                                           session_id=self.session_id, turn_id=None, data={})
                        continue
                    batch = list(sub.queue)
                    sub.queue.clear()
                    dropped = sub.dropped
                    sub.dropped = 0
                if dropped:
                    yield HarnessEvent(seq=last, type=EventType.STREAM_GAP.value,
                                       session_id=self.session_id, turn_id=None,
                                       data={"dropped": dropped,
                                             "detail": "Subscriber fell behind; re-fetch via ?after="})
                for ev in batch:
                    if ev.type == "__eof__":
                        return
                    last = ev.seq
                    yield ev
        finally:
            self.unsubscribe(sub)


@dataclass
class Artifact:
    artifact_id: str
    title: str
    kind: str
    content: str
    created_at: float = field(default_factory=time.time)


@dataclass
class Checkpoint:
    """A pause point the harness cannot pass without the caller resolving it."""
    checkpoint_id: str
    kind: str                       # "approval" | "question"
    prompt: str
    payload: Dict[str, Any]
    resolved: bool = False
    approved: Optional[bool] = None
    answer: Optional[str] = None
    resolved_by: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    event = None

    def __post_init__(self):
        self._event = threading.Event()

    def wait(self, timeout: float) -> bool:
        return self._event.wait(timeout)

    def resolve(self, approved: Optional[bool] = None, answer: Optional[str] = None,
                by: str = "caller") -> None:
        self.approved = approved
        self.answer = answer
        self.resolved_by = by
        self.resolved = True
        self._event.set()


@dataclass
class Session:
    session_id: str
    caller: str                     # which agent opened this session
    agent_profile: str
    state: str = SessionState.IDLE.value
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    turns: List[Dict[str, Any]] = field(default_factory=list)
    artifacts: List[Artifact] = field(default_factory=list)
    checkpoints: Dict[str, Checkpoint] = field(default_factory=dict)
    granted_tools: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    last_result: Optional[Dict[str, Any]] = None

    def touch(self) -> None:
        self.updated_at = time.time()

    def public(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "caller": self.caller,
            "agent_profile": self.agent_profile,
            "state": self.state,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "turns": len(self.turns),
            "granted_tools": self.granted_tools,
            "artifacts": [
                {"artifact_id": a.artifact_id, "title": a.title, "kind": a.kind}
                for a in self.artifacts
            ],
            "open_checkpoints": [
                {"checkpoint_id": c.checkpoint_id, "kind": c.kind, "prompt": c.prompt,
                 "payload": c.payload}
                for c in self.checkpoints.values() if not c.resolved
            ],
            "last_result": self.last_result,
        }


class SessionStore:
    """In-memory session + bus registry. Swap for Postgres/Redis in production."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sessions: Dict[str, Session] = {}
        self._buses: Dict[str, EventBus] = {}

    def create(self, caller: str, agent_profile: str,
               granted_tools: List[str], metadata: Dict[str, Any]) -> Session:
        sid = "ses_" + uuid.uuid4().hex[:16]
        s = Session(session_id=sid, caller=caller, agent_profile=agent_profile,
                    granted_tools=granted_tools, metadata=metadata or {})
        with self._lock:
            self._sessions[sid] = s
            self._buses[sid] = EventBus(sid)
        self.bus(sid).emit(EventType.SESSION_CREATED, {
            "caller": caller, "agent_profile": agent_profile,
            "granted_tools": granted_tools,
        })
        return s

    def get(self, sid: str) -> Optional[Session]:
        with self._lock:
            return self._sessions.get(sid)

    def bus(self, sid: str) -> EventBus:
        with self._lock:
            return self._buses[sid]

    def list(self, caller: Optional[str] = None) -> List[Session]:
        with self._lock:
            vals = list(self._sessions.values())
        if caller:
            vals = [s for s in vals if s.caller == caller]
        return sorted(vals, key=lambda s: s.updated_at, reverse=True)

    def evict_idle(self) -> int:
        """Sessions are unbounded otherwise; a long-lived harness leaks without this."""
        cutoff = time.time() - SESSION_IDLE_TTL_S
        removed = 0
        with self._lock:
            for sid in [k for k, v in self._sessions.items()
                        if v.updated_at < cutoff
                        and v.state in (SessionState.COMPLETED.value,
                                        SessionState.FAILED.value,
                                        SessionState.CANCELLED.value)]:
                self._sessions.pop(sid, None)
                bus = self._buses.pop(sid, None)
                if bus:
                    bus.mark_terminal()
                removed += 1
        return removed


SESSIONS = SessionStore()
