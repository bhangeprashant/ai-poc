"""
Automated vulnerability remediation — A2A + Spec Kit on the harness.

Flow:

  clone -> fetch findings -> TRIAGE (false positives first) -> per-finding
  spec-kit loop (specify/plan/implement) -> validate -> regression gate ->
  HUMAN REVIEW -> branch + commit -> push -> verification rescan

Four decisions worth defending, because they are where this kind of
pipeline usually goes wrong:

1. TRIAGE RUNS FIRST, AND IT IS A SEPARATE READ-ONLY AGENT.
   Scanners over-report. Sending every raw finding into an implement loop
   burns the expensive stage on noise and, worse, produces "fixes" for
   things that were never broken -- which is a net negative: churn in
   security-sensitive code with no security benefit. Triage is the
   cheapest discriminating step, so it goes first, and it holds NO write
   tools so it cannot start fixing what it is supposed to be judging.

2. REGRESSION IS DIFFED AGAINST A PRE-FIX BASELINE, NOT ASSERTED.
   "No regression" is unfalsifiable without knowing what passed before.
   The pipeline captures a baseline run BEFORE touching code, then diffs.
   A test that was already failing is not a regression; a test that
   flipped pass->fail is, even if the suite still reports mostly green.

3. HUMAN REVIEW GATES THE PUSH, NOT THE COMMIT.
   Committing locally is recoverable. Pushing publishes both the fix and,
   by implication, the vulnerability -- to everyone with read access,
   before the fix is deployed. That is the irreversible step, so that is
   where the human goes.

4. A FIX IS NOT DONE WHEN TESTS PASS. IT IS DONE WHEN THE SCANNER AGREES.
   The final rescan is what closes a finding. Tests passing means nothing
   broke; only the scanner can say the vulnerability is actually gone.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from farm_core import (
    PolicyBroker, PolicyRule, FarmAgent, FarmCoordinator, APPROVE, DENY,
)
from harness_core import SESSIONS, SessionState
from harness_loop import run_turn_async
from tool_registry import run_tool

# ------------------------------------------------------------ triage rules --

# Deterministic, auditable false-positive heuristics. These run BEFORE any
# model reasoning: a rule that can be stated exactly should not be a prompt.
# Each returns (is_false_positive, rationale) and every verdict is recorded,
# because a wrongly-dismissed finding is the most expensive mistake this
# pipeline can make -- it looks like success.
FP_RULES = [
    ("test-scope-credential",
     lambda f: f["rule"] == "Hardcoded Credential" and (
         "/test/" in f["file"] or f["file"].endswith("Test.java")),
     "Hardcoded credential in test source; not a deployed secret."),
    ("dev-only-dependency",
     lambda f: f.get("scope") == "dev-only",
     "Dependency is dev-scoped and not shipped in the runtime artifact."),
]


@dataclass
class TriageVerdict:
    finding_id: str
    is_false_positive: bool
    rule: str
    rationale: str
    confidence: str
    needs_human: bool = False


def triage(findings: List[Dict[str, Any]]) -> List[TriageVerdict]:
    """Classify findings before any remediation work starts."""
    out: List[TriageVerdict] = []
    for f in findings:
        matched = None
        for name, pred, why in FP_RULES:
            try:
                if pred(f):
                    matched = (name, why)
                    break
            except Exception:  # noqa: BLE001
                continue

        if matched:
            name, why = matched
            # A deterministic FP rule firing on a CRITICAL finding is exactly
            # the case not to auto-dismiss. The rule may be right, but the
            # cost of being wrong is a shipped critical vulnerability, so it
            # goes to a human instead of being silently closed.
            needs_human = f["severity"] == "critical"
            out.append(TriageVerdict(f["id"], True, name, why,
                                     f.get("confidence", "unknown"), needs_human))
        else:
            out.append(TriageVerdict(f["id"], False, "no-fp-rule-matched",
                                     "No false-positive rule matched; treated as actionable.",
                                     f.get("confidence", "unknown")))
    return out


# -------------------------------------------------------------- regression --

@dataclass
class RegressionReport:
    baseline_failures: List[str]
    post_fix_failures: List[str]
    new_failures: List[str]
    fixed_incidentally: List[str]
    clean: bool


def compare_to_baseline(baseline: Dict[str, Any],
                        post_fix: Dict[str, Any]) -> RegressionReport:
    """Diff two runs. A pre-existing failure is not a regression."""
    b_fail = set(baseline.get("failed", []))
    p_fail = set(post_fix.get("failed", []))
    new = sorted(p_fail - b_fail)
    return RegressionReport(
        baseline_failures=sorted(b_fail), post_fix_failures=sorted(p_fail),
        new_failures=new, fixed_incidentally=sorted(b_fail - p_fail),
        clean=not new,
    )


# ---------------------------------------------------------------- pipeline --

SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


@dataclass
class RemediationRecord:
    finding_id: str
    severity: str
    stage: str = "pending"
    triage: Optional[TriageVerdict] = None
    spec_phases: List[str] = field(default_factory=list)
    validated: bool = False
    quarantined: bool = False
    blast_radius: int = 0
    notes: List[str] = field(default_factory=list)

    def to_state(self) -> Dict[str, Any]:
        return {"finding_id": self.finding_id, "severity": self.severity,
                "stage": self.stage, "validated": self.validated,
                "quarantined": self.quarantined, "blast_radius": self.blast_radius,
                "notes": self.notes}


def prioritise(findings: List[Dict[str, Any]],
               blast: Optional[Dict[str, int]] = None) -> List[Dict[str, Any]]:
    """Severity first, then blast radius, then id for determinism.

    Fetch order is whatever the scanner's API returned, which has no
    relationship to urgency -- a critical would otherwise wait behind a
    medium purely because of pagination. Blast radius breaks ties within
    a severity band: two criticals are not equally urgent if one sits in
    a service four others depend on.
    """
    blast = blast or {}
    return sorted(
        findings,
        key=lambda f: (SEVERITY_RANK.get(f.get("severity", "low"), 9),
                       -blast.get(f["id"], 0),
                       f["id"]),
    )


class RemediationPipeline:
    def __init__(self, repo: str, broker: Optional[PolicyBroker] = None):
        self.repo = repo
        self.broker = broker or self.default_broker()
        self.records: Dict[str, RemediationRecord] = {}
        self.baseline: Optional[Dict[str, Any]] = None
        self.audit: List[str] = []

    @staticmethod
    def default_broker() -> PolicyBroker:
        return PolicyBroker(rules=[
            PolicyRule("scanner-reads", APPROVE, tools=["security_scanner_tool"],
                       max_severity="low", reason="Read-only findings fetch."),
            PolicyRule("test-runs", APPROVE, tools=["test_runner_tool"],
                       max_severity="low", reason="Runs existing suite, no mutation."),
            PolicyRule("kb-reads", APPROVE, tools=["knowledge_search_tool"],
                       max_severity="low", reason="Read-only."),
            PolicyRule("repo-reads", APPROVE, tools=["repo_read_tool"],
                       max_severity="low", reason="Clone/inspect only; cannot publish."),
            PolicyRule("spec-scaffold", APPROVE, tools=["speckit-cli"],
                       max_severity="medium", reason="Writes only into specs/."),
            # repo_publish_tool (high) and execution_harness_tool (high) match
            # nothing -> escalate to a human. Deliberate: those are the steps
            # that publish or execute code.
        ])

    def log(self, msg: str) -> None:
        self.audit.append(msg)

    # ------------------------------------------------------------- stages
    def stage_clone(self) -> Dict[str, Any]:
        out = run_tool("repo_read_tool", {"action": "clone", "repo": self.repo})
        self.log(f"cloned {self.repo} @ {out.get('commit')}")
        return out

    def stage_fetch(self, scanner: Optional[str] = None) -> List[Dict[str, Any]]:
        out = run_tool("security_scanner_tool",
                       {"action": "fetch_findings", "scanner": scanner})
        findings = out["findings"]
        for f in findings:
            self.records[f["id"]] = RemediationRecord(f["id"], f["severity"])
        self.log(f"fetched {len(findings)} finding(s) from {out['scanner']}")
        return findings

    def stage_triage(self, findings: List[Dict[str, Any]]) -> Tuple[List, List, List]:
        verdicts = triage(findings)
        actionable, dismissed, escalated = [], [], []
        for v in verdicts:
            rec = self.records[v.finding_id]
            rec.triage = v
            if not v.is_false_positive:
                rec.stage = "actionable"
                actionable.append(v)
            elif v.needs_human:
                rec.stage = "fp-needs-human"
                rec.notes.append("FP rule matched but severity is critical — not auto-dismissed.")
                escalated.append(v)
            else:
                rec.stage = "dismissed-fp"
                dismissed.append(v)
        self.log(f"triage: {len(actionable)} actionable, {len(dismissed)} dismissed, "
                 f"{len(escalated)} FP-but-escalated")
        return actionable, dismissed, escalated

    def stage_baseline(self) -> Dict[str, Any]:
        """Must run BEFORE any code changes, or the diff is meaningless."""
        self.baseline = run_tool("test_runner_tool",
                                 {"suite": "all", "baseline_mode": True})
        self.log(f"baseline captured: {self.baseline['passed']}/{self.baseline['total']} "
                 f"passing, pre-existing failures={self.baseline['failed']}")
        return self.baseline

    def stage_remediate(self, verdicts: List[TriageVerdict],
                        findings_by_id: Dict[str, Dict[str, Any]],
                        timeout_s: float = 20.0,
                        full_chain: bool = True) -> List[Any]:
        """Spec-kit flow PER FINDING, as parallel farm agents.

        With full_chain=True each finding walks specify -> plan -> tasks,
        following spec-kit's own auto_send handoff edges, and STOPS before
        implement -- which spec-kit marks non-automatic precisely because a
        human should decide whether a plan becomes code. For security
        remediation that boundary is worth keeping rather than overriding:
        a plan that patches the wrong sink is cheap to discard, a pushed
        patch is not.

        Per-finding isolation matters: one finding stalling on approval or
        failing to plan must not block remediation of the others, and each
        carries its own audit trail tied to its own finding id.
        """
        agents = []
        for v in verdicts:
            f = findings_by_id[v.finding_id]
            agents.append(FarmAgent(
                name=f"remediate.{v.finding_id}",
                profile="engineer",
                tools=["speckit-cli", "knowledge_search_tool"],
                metadata={"finding": v.finding_id, "cwe": f.get("cwe"),
                          "file": f.get("file")},
            ))

        def goal_for(a: FarmAgent) -> str:
            f = findings_by_id[a.metadata["finding"]]
            return (f"Use speckit-cli to specify the remediation for {f['id']}: "
                    f"{f['rule']} ({f['cwe']}) at {f['file']}:{f.get('line')}. "
                    f"Sink: {f.get('sink')}, source: {f.get('source')}.")

        coord = FarmCoordinator(self.broker)
        results = coord.dispatch(agents, goal_for, timeout_s=timeout_s)
        for r in results:
            fid = r.agent.split("remediate.")[-1]
            rec = self.records.get(fid)
            if rec:
                rec.stage = "spec-drafted" if r.state == "completed" else "spec-failed"
                rec.spec_phases.append("specify")
        self.log(f"remediation specs drafted for {len(results)} finding(s)")

        if full_chain:
            self._advance_spec_chain(verdicts, findings_by_id, timeout_s)
        return results

    def _advance_spec_chain(self, verdicts: List[TriageVerdict],
                            findings_by_id: Dict[str, Dict[str, Any]],
                            timeout_s: float) -> None:
        """Walk spec-kit's auto_send edges per finding via the A2A bridge.

        Uses the handoff graph rather than a sequence written here, so if
        spec-kit changes its own phase ordering this follows automatically.
        """
        from a2a_bridge import send_message, get_task, resolve_input_required, next_hop

        for v in verdicts:
            rec = self.records.get(v.finding_id)
            if not rec or rec.stage == "spec-failed":
                continue
            f = findings_by_id[v.finding_id]
            agent, hops = "speckit.plan", 0
            ctx = None
            while agent and hops < 3:
                task = send_message(
                    agent,
                    f"Remediation for {f['id']} ({f['rule']}) at {f['file']}",
                    context_id=ctx, metadata={"target": v.finding_id})
                ctx = task["contextId"]
                task = self._drain_task(task["id"], get_task,
                                        resolve_input_required, timeout_s)
                rec.spec_phases.append(agent.replace("speckit.", ""))
                hop = next_hop(task["id"], auto_only=True)
                if not hop:
                    break
                agent = hop[0]["agent"]
                hops += 1
            rec.stage = "plan-ready"
        self.log("spec chains advanced: " + ", ".join(
            f"{v.finding_id}={'/'.join(self.records[v.finding_id].spec_phases)}"
            for v in verdicts if v.finding_id in self.records))

    @staticmethod
    def _drain_task(task_id: str, get_task, resolve_input_required,
                    timeout_s: float) -> Dict[str, Any]:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            t = get_task(task_id)
            state = t["status"]["state"]
            if state in ("completed", "failed"):
                return t
            if state == "input-required":
                t = resolve_input_required(task_id, approved=True,
                                           by="remediation-pipeline")
                if t["status"]["state"] in ("completed", "failed"):
                    return t
            time.sleep(0.05)
        return get_task(task_id)

    def stage_validate(self) -> RegressionReport:
        if self.baseline is None:
            raise RuntimeError(
                "No baseline captured. Refusing to report on regressions without "
                "a pre-fix comparison — 'no regression' would be unfalsifiable.")
        post = run_tool("test_runner_tool", {"suite": "all", "baseline_mode": False})
        report = compare_to_baseline(self.baseline, post)
        self.log(f"regression check: new_failures={report.new_failures or 'none'} "
                 f"clean={report.clean}")
        return report

    def stage_validate_per_finding(self, verdicts: List[TriageVerdict],
                                   ) -> Dict[str, RegressionReport]:
        """Validate each fix IN ISOLATION, then quarantine only the bad ones.

        Validating the batch as a whole means one bad fix blocks every clean
        fix alongside it -- so a single regression stalls the critical
        remediations it happened to be batched with, and the batch gets
        retried as a unit. Per-finding isolation lets good fixes ship while
        the broken one goes back for rework, which is the difference between
        this pipeline shipping weekly and shipping when everything is
        perfect (i.e. never).

        Each finding is applied against the SAME pre-fix baseline, not
        against the previous finding's result, so attribution is real:
        finding N's report reflects finding N's change alone.
        """
        if self.baseline is None:
            raise RuntimeError("No baseline captured; per-finding validation "
                               "cannot attribute regressions without one.")
        reports: Dict[str, RegressionReport] = {}
        for v in verdicts:
            post = run_tool("test_runner_tool",
                            {"suite": "all", "baseline_mode": False,
                             "finding": v.finding_id})
            rep = compare_to_baseline(self.baseline, post)
            reports[v.finding_id] = rep
            rec = self.records[v.finding_id]
            rec.validated = rep.clean
            rec.quarantined = not rep.clean
            rec.stage = "validated" if rep.clean else "quarantined"
            if not rep.clean:
                rec.notes.append(f"Quarantined: introduced {rep.new_failures}")
            self.log(f"validate {v.finding_id}: clean={rep.clean} "
                     f"new={rep.new_failures or 'none'}")
        return reports

    def publishable(self, verdicts: List[TriageVerdict]) -> Tuple[List, List]:
        """Split validated fixes from quarantined ones."""
        ok = [v for v in verdicts if self.records[v.finding_id].validated]
        held = [v for v in verdicts if self.records[v.finding_id].quarantined]
        return ok, held

    def save_state(self, path: str) -> str:
        """Persist enough to resume. Without this, a crash after push but
        before rescan loses the fact that code was already published --
        and a naive retry would branch and push a second time."""
        import json
        state = {
            "repo": self.repo, "saved_at": time.time(),
            "baseline": self.baseline,
            "records": {k: v.to_state() for k, v in self.records.items()},
            "audit": self.audit,
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(state, fh, indent=2)
        return path

    @staticmethod
    def load_state(path: str) -> Dict[str, Any]:
        import json
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    def stage_human_review(self, report: RegressionReport,
                           actionable: List[TriageVerdict],
                           escalated: List[TriageVerdict]) -> Dict[str, Any]:
        """The review packet. Everything a reviewer needs to say no."""
        return {
            "repo": self.repo,
            "findings_to_fix": [v.finding_id for v in actionable],
            "fp_dismissed": [v.finding_id for v in self.iter_dismissed()],
            "fp_escalated_for_confirmation": [v.finding_id for v in escalated],
            "regression_clean": report.clean,
            "new_failures": report.new_failures,
            "pre_existing_failures": report.baseline_failures,
            "blocking": (not report.clean) or bool(escalated),
        }

    def iter_dismissed(self) -> List[TriageVerdict]:
        return [r.triage for r in self.records.values()
                if r.stage == "dismissed-fp" and r.triage]

    def stage_publish(self, branch: str, files: List[str],
                      message: str) -> Dict[str, Any]:
        """Branch + commit + push. Called ONLY after human approval."""
        b = run_tool("repo_publish_tool", {"action": "branch", "repo": self.repo,
                                            "branch": branch})
        c = run_tool("repo_publish_tool", {"action": "commit", "repo": self.repo,
                                            "files": files, "message": message})
        p = run_tool("repo_publish_tool", {"action": "push", "repo": self.repo,
                                            "branch": branch})
        self.log(f"published {branch} @ {c.get('sha')}")
        return {"branch": b, "commit": c, "push": p}

    def stage_rescan(self, branch: str, expect_resolved: List[str]) -> Dict[str, Any]:
        out = run_tool("security_scanner_tool",
                       {"action": "rescan", "branch": branch,
                        "expect_resolved": expect_resolved})
        resolved = set(out.get("resolved_findings", []))
        still_open = [f for f in expect_resolved if f not in resolved]
        out["still_open"] = still_open
        out["verified"] = not still_open and out.get("new_findings", 0) == 0
        self.log(f"rescan: verified={out['verified']} still_open={still_open or 'none'}")
        return out
