"""
A2A bridge — harness sessions AS A2A tasks, spec-kit phases AS A2A agents.

A2A (Agent2Agent, Linux Foundation, v1.0 2026) standardises three things:
AgentCards (discovery), Tasks with a defined lifecycle, and Messages/
Artifacts exchanged over JSON-RPC + SSE. The harness already has all
three -- this module is the translation layer, not a reimplementation.

The mapping is close enough that it is barely a mapping:

    Harness SessionState          A2A TaskState
    ---------------------          -------------
    idle                       ->  submitted
    running                    ->  working
    awaiting_approval          ->  input-required   <-- same concept
    awaiting_answer            ->  input-required   <-- same concept
    completed                  ->  completed
    failed                     ->  failed
    cancelled                  ->  canceled

That `awaiting_approval -> input-required` line is the actual payoff.
A2A defines input-required as a first-class state specifically for "the
task needs something from the caller before it can continue" -- which is
precisely what an approval checkpoint is. An EXTERNAL A2A client (built
on any framework that speaks the protocol, not just this harness) sees a
standards-compliant signal to intervene, not a proprietary concept it
has to special-case.

Spec Kit phases become individually addressable A2A agents. Each gets a
real AgentCard sourced from its own SKILL.md (name, description, the
tools it's granted double as declared skills) plus a `next_agents` field
derived from spec-kit's own handoff graph -- so an A2A COORDINATOR that
has never heard of spec-kit can still discover "after speckit.plan,
speckit.tasks is next" by reading the card, the same way it discovers
anything else about an agent it just met.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional

from farm_speckit import (
    PHASE_GRANTS, PHASE_PROFILE, load_handoff_graph, phase_agent,
)
from harness_context import SKILLS
from harness_core import SESSIONS, EventType, Session, SessionState
from harness_loop import run_turn_async

TASK_STATE_MAP: Dict[str, str] = {
    SessionState.IDLE.value: "submitted",
    SessionState.RUNNING.value: "working",
    SessionState.AWAITING_APPROVAL.value: "input-required",
    SessionState.AWAITING_ANSWER.value: "input-required",
    SessionState.COMPLETED.value: "completed",
    SessionState.FAILED.value: "failed",
    SessionState.CANCELLED.value: "canceled",
}

TERMINAL_A2A_STATES = {"completed", "canceled", "failed", "rejected"}


# --------------------------------------------------------------- discovery --

def agent_card_for_phase(phase: str, base_url: str = "https://harness.internal") -> Dict[str, Any]:
    """A real AgentCard, sourced from the phase's actual skill and grants --
    not a hand-written description that can drift from what the agent does."""
    skill = SKILLS.get(phase)
    graph = load_handoff_graph()
    edges = graph.get(phase, [])

    return {
        "protocolVersion": "1.0",
        "name": phase,
        "description": skill.summary if skill else phase,
        "url": f"{base_url}/a2a/{phase}",
        "preferredTransport": "JSONRPC",
        "capabilities": {"streaming": True, "pushNotifications": False},
        "defaultInputModes": ["text/plain", "application/json"],
        "defaultOutputModes": ["text/plain", "application/json"],
        "skills": [{
            "id": phase,
            "name": phase.replace("speckit.", "").replace("-", " ").title(),
            "description": skill.summary if skill else "",
            "tags": PHASE_GRANTS.get(phase, []),
        }],
        # Not core A2A -- carried in the card's extension slot. This is how
        # a coordinator that has never seen spec-kit discovers routing
        # without out-of-band knowledge: read the next hop off the card of
        # the agent it just finished talking to.
        "extensions": [{
            "uri": "urn:speckit:handoffs",
            "params": {
                "next_agents": [
                    {"agent": e.to_agent, "automatic": e.auto_send} for e in edges
                ],
            },
        }],
        "securitySchemes": {},   # left for the deployment's real auth story
    }


def all_agent_cards(base_url: str = "https://harness.internal") -> List[Dict[str, Any]]:
    return [agent_card_for_phase(p, base_url) for p in PHASE_GRANTS]


# ------------------------------------------------------------------- tasks --

@dataclass
class A2AArtifact:
    artifact_id: str
    name: str
    parts: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class A2ATaskRef:
    """A2A's Task, backed by a harness Session. contextId groups tasks that
    belong to one multi-agent flow, mirroring A2A's own field name -- a
    coordinator uses it to correlate the specify/plan/tasks/implement
    tasks it delegated as one logical unit of work."""
    task_id: str
    context_id: str
    agent: str
    session_id: str


_TASKS: Dict[str, A2ATaskRef] = {}


def send_message(agent: str, text: str, context_id: Optional[str] = None,
                 metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """A2A's message/send. Creates or continues a Task. Returns the Task
    object in the shape a real A2A client expects: id, contextId, status."""
    if agent not in PHASE_GRANTS:
        raise ValueError(f"No AgentCard for '{agent}'. Known: {list(PHASE_GRANTS)}")

    fa = phase_agent(agent, (metadata or {}).get("target", ""))
    s = SESSIONS.create(fa.name, fa.profile, fa.tools, fa.metadata)
    run_turn_async(s, text)

    task_id = "task_" + uuid.uuid4().hex[:12]
    ctx = context_id or ("ctx_" + uuid.uuid4().hex[:10])
    _TASKS[task_id] = A2ATaskRef(task_id, ctx, agent, s.session_id)
    return get_task(task_id)


def get_task(task_id: str) -> Dict[str, Any]:
    """A2A's tasks/get."""
    ref = _TASKS.get(task_id)
    if not ref:
        raise KeyError(f"Unknown task {task_id}")
    s = SESSIONS.get(ref.session_id)
    if not s:
        raise KeyError(f"Session for task {task_id} is gone")

    state = TASK_STATE_MAP.get(s.state, "unknown")
    out: Dict[str, Any] = {
        "id": ref.task_id, "contextId": ref.context_id,
        "status": {"state": state, "timestamp": s.updated_at},
        "artifacts": [_result_artifact(s)] if s.last_result else [],
    }
    # input-required carries WHY, so a generic A2A client (with no idea what
    # a "harness checkpoint" is) still knows what's being asked of it.
    if state == "input-required":
        open_cps = [c for c in s.checkpoints.values() if not c.resolved]
        if open_cps:
            cp = open_cps[0]
            out["status"]["message"] = {
                "role": "agent",
                "parts": [{"kind": "text", "text": cp.prompt}],
                "metadata": {"checkpoint_id": cp.checkpoint_id, "kind": cp.kind,
                            **cp.payload},
            }
    return out


def _result_artifact(session: Session) -> Dict[str, Any]:
    r = session.last_result or {}
    text = r.get("answer") or r.get("detail") or ""
    return {"artifactId": "art_" + session.session_id, "name": "result",
            "parts": [{"kind": "text", "text": text}]}


def resolve_input_required(task_id: str, approved: Optional[bool] = None,
                           answer: Optional[str] = None,
                           by: str = "a2a-client") -> Dict[str, Any]:
    """A2A models this as the client sending a follow-up Message while the
    task sits in input-required. Underneath, it resolves the harness
    checkpoint -- same mechanism as any other caller, external or internal.

    Treated as idempotent by design, not just for convenience: a client
    that polled tasks/get, saw input-required, and is now sending its
    follow-up is racing the task's own progress by construction -- the
    background run can resolve and advance between the client's read and
    its write. If the task has already moved past input-required by the
    time this arrives (this checkpoint or a later one already resolved,
    or the whole task finished), that is not a client error to raise on;
    it is exactly the situation A2A's async task model exists to tolerate.
    Only a task with GENUINELY nothing to resolve and nowhere left to go
    (already terminal, never had a checkpoint at all) is worth surfacing
    as an error.
    """
    ref = _TASKS.get(task_id)
    if not ref:
        raise KeyError(f"Unknown task {task_id}")
    s = SESSIONS.get(ref.session_id)
    if not s:
        raise KeyError(f"Session for task {task_id} is gone")

    open_cps = [c for c in s.checkpoints.values() if not c.resolved]
    if not open_cps:
        current = get_task(task_id)
        if current["status"]["state"] in TERMINAL_A2A_STATES:
            return current   # raced a resolution that already landed -- fine
        if not s.checkpoints:
            raise ValueError(f"Task {task_id} was never in input-required.")
        return current       # all checkpoints resolved, run still finishing
    open_cps[0].resolve(approved=approved, answer=answer, by=by)
    return get_task(task_id)


def cancel_task(task_id: str) -> Dict[str, Any]:
    """A2A's tasks/cancel. The harness has no mid-run cancel primitive yet
    (see gap below); this marks the record without stopping the thread --
    honest about the limitation rather than pretending to support it."""
    ref = _TASKS.get(task_id)
    if not ref:
        raise KeyError(f"Unknown task {task_id}")
    s = SESSIONS.get(ref.session_id)
    if s and s.state not in (SessionState.COMPLETED.value, SessionState.FAILED.value):
        s.state = SessionState.CANCELLED.value
        s.touch()
    return get_task(task_id)


def stream_task(task_id: str, after_seq: int = 0) -> Iterator[Dict[str, Any]]:
    """A2A's message/stream and tasks/resubscribe. Wraps the harness's own
    resumable SSE bus -- same seq-based resume story A2A wants, because
    the harness was already built for a caller that isn't a browser."""
    ref = _TASKS.get(task_id)
    if not ref:
        raise KeyError(f"Unknown task {task_id}")
    bus = SESSIONS.bus(ref.session_id)

    for ev in bus.stream(after_seq=after_seq):
        kind = _a2a_event_kind(ev.type)
        if kind is None:
            continue
        yield {
            "taskId": ref.task_id, "contextId": ref.context_id,
            "kind": kind, "seq": ev.seq,
            "final": ev.type in (EventType.TURN_COMPLETED.value, EventType.TURN_FAILED.value),
            "data": ev.data,
        }
        if ev.type in (EventType.TURN_COMPLETED.value, EventType.TURN_FAILED.value):
            return


def _a2a_event_kind(harness_event_type: str) -> Optional[str]:
    """Harness events -> A2A's two streaming event kinds. Most internal
    events (plan.drafted, step.started) have no A2A equivalent and are
    dropped rather than forced into a shape A2A doesn't define -- a real
    client would not know what to do with them anyway."""
    if harness_event_type in (EventType.APPROVAL_REQUESTED.value,
                              EventType.QUESTION_ASKED.value,
                              EventType.TURN_COMPLETED.value,
                              EventType.TURN_FAILED.value):
        return "status-update"
    if harness_event_type == EventType.ARTIFACT_CREATED.value:
        return "artifact-update"
    return None


# ---------------------------------------------------------- multi-agent hop --

def next_hop(task_id: str, auto_only: bool = True) -> List[Dict[str, Any]]:
    """Read the next agent(s) to delegate to off THIS agent's own card --
    the coordinator pattern A2A is built for. No spec-kit-specific
    knowledge required on the caller's side."""
    ref = _TASKS.get(task_id)
    if not ref:
        raise KeyError(f"Unknown task {task_id}")
    card = agent_card_for_phase(ref.agent)
    hops = card["extensions"][0]["params"]["next_agents"]
    return [h for h in hops if h["automatic"]] if auto_only else hops
