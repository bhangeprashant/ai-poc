"""
Vulnerability remediation, end to end.

    python vuln_remediation_demo.py
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict

from harness_context import SKILLS
from vuln_remediation import RemediationPipeline


def step(n: str, why: str = "") -> None:
    print(f"\n{'='*74}\n{n}\n{'-'*74}")
    if why:
        print(f"{why}\n")


def main() -> None:
    SKILLS.reload()
    pipe = RemediationPipeline(repo="payments-api")

    step("1. Clone repository")
    print("  ", pipe.stage_clone())

    step("2. Fetch findings from Fortify / Sonatype")
    findings = pipe.stage_fetch()
    by_id = {f["id"]: f for f in findings}
    for f in findings:
        print(f"   {f['id']:10} {f['severity']:8} conf={f['confidence']:6} "
              f"{f['rule']:22} {f['file'].split('/')[-1]}")

    step("3. Triage — false positives FIRST",
         "Scanners over-report. Sending raw findings into the implement loop\n"
         "burns the expensive stage on noise and produces 'fixes' for things\n"
         "that were never broken — churn in security code with no benefit.")
    actionable, dismissed, escalated = pipe.stage_triage(findings)
    for v in dismissed:
        print(f"   DISMISSED  {v.finding_id:10} [{v.rule}] {v.rationale}")
    for v in escalated:
        print(f"   ESCALATED  {v.finding_id:10} [{v.rule}] FP rule matched, but severity")
        print(f"              is critical — cost of being wrong is a shipped critical vuln,")
        print(f"              so a human confirms rather than auto-closing.")
    for v in actionable:
        print(f"   ACTIONABLE {v.finding_id:10} {v.rationale}")

    step("4. Capture pre-fix test baseline",
         "Captured BEFORE any code changes. Without this, 'no regression' is\n"
         "unfalsifiable — you cannot tell a new break from an existing one.")
    b = pipe.stage_baseline()
    print(f"   {b['passed']}/{b['total']} passing; pre-existing failures: {b['failed'] or 'none'}")

    step("5. Per-finding spec-kit remediation (parallel agents)",
         "One spec-kit flow per finding, each its own farm agent with its own\n"
         "audit trail. One finding stalling does not block the others.")
    results = pipe.stage_remediate(actionable, by_id)
    for r in results:
        print(f"   {r.agent:28} {r.state:10} verdict={r.verdict}")

    step("6. Validate + regression gate",
         "Diffed against the baseline. A test already failing is not a\n"
         "regression; a pass->fail flip is, even if the suite is mostly green.")
    report = pipe.stage_validate()
    print(f"   pre-existing failures : {report.baseline_failures or 'none'}")
    print(f"   post-fix failures     : {report.post_fix_failures or 'none'}")
    print(f"   NEW failures          : {report.new_failures or 'none'}")
    print(f"   regression clean      : {report.clean}")

    step("7. Human-in-the-loop review")
    packet = pipe.stage_human_review(report, actionable, escalated)
    for k, v in packet.items():
        print(f"   {k:34} {v}")

    if packet["blocking"]:
        print("\n   BLOCKING — pipeline stops here and does not publish.")
        print("   Reasons:")
        if not report.clean:
            print(f"     - regression introduced: {report.new_failures}")
        if escalated:
            print(f"     - unconfirmed FP dismissals on critical findings: "
                  f"{[v.finding_id for v in escalated]}")
        print("\n   This is the correct outcome. A pipeline that pushed here would")
        print("   be shipping a regression and closing a critical finding nobody")
        print("   confirmed. Publishing is deliberately unreachable in this state.")
        decision = simulate_reviewer(packet, report)
        if not decision["approved"]:
            print(f"\n   Reviewer decision: REJECTED — {decision['reason']}")
            print("\n   Stages 8-9 (branch/commit/push, rescan) not executed.")
            print_audit(pipe)
            return
        print(f"\n   Reviewer decision: APPROVED WITH OVERRIDE — {decision['reason']}")
    else:
        print("\n   Non-blocking. Awaiting routine reviewer approval.")

    step("8. Branch, commit, push (post-approval only)")
    pub = pipe.stage_publish(
        branch="security/remediation-batch-1",
        files=[by_id[v.finding_id]["file"] for v in actionable],
        message="fix(security): remediate SAST/SCA findings\n\n"
                + "\n".join(f"- {v.finding_id}" for v in actionable))
    print("   ", pub["commit"])
    print("   ", pub["push"])

    step("9. Verification rescan",
         "A fix is not done when tests pass — only the scanner can say the\n"
         "vulnerability is actually gone.")
    rescan = pipe.stage_rescan("security/remediation-batch-1",
                               [v.finding_id for v in actionable])
    print(f"   verified={rescan['verified']} still_open={rescan['still_open'] or 'none'} "
          f"new_findings={rescan['new_findings']}")

    print_audit(pipe)


def simulate_reviewer(packet: Dict[str, Any], report) -> Dict[str, Any]:
    """Stands in for the human. Rejects on a real regression — which is the
    behaviour that matters, since approving here would ship the break."""
    if report.new_failures:
        return {"approved": False,
                "reason": f"new test failure(s) introduced: {report.new_failures}"}
    return {"approved": True, "reason": "regression clean, FP dismissals confirmed"}


def print_audit(pipe: RemediationPipeline) -> None:
    print(f"\n{'='*74}\nAUDIT TRAIL\n{'-'*74}")
    for line in pipe.audit:
        print(f"   {line}")
    print(f"\n{'='*74}\nPER-FINDING FINAL STATE\n{'-'*74}")
    for fid, rec in sorted(pipe.records.items()):
        t = rec.triage
        print(f"   {fid:10} {rec.severity:8} stage={rec.stage:18} "
              f"{'FP:' + t.rule if t and t.is_false_positive else ''}")
    pipe.broker.shutdown()


if __name__ == "__main__":
    main()
