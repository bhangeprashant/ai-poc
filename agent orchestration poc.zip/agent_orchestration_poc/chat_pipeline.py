"""
Console chat pipeline.

  QueryAnalyzerAgent  cleans the raw utterance (speech transcripts arrive
                      messy), resolves pronouns against conversation
                      history, and extracts entities.
  IntentMapperAgent   maps the analyzed query to one of a small set of
                      routes, so the orchestrator isn't guessing.
  ConsoleOrchestrator routes: answers directly, calls a single tool, or
                      hands off to the multi-agent engine from the agent
                      farm (the existing PlannerAgent/OrchestratorAgent),
                      and generates documents when asked.

Every turn emits a `spine` — the ordered list of agents that fired, with
status and timing. The UI draws this live; it is also the audit record of
what was invoked on the user's behalf.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Optional

from llm_client import complete_json
from tool_registry import list_tools, run_tool
from console_core import (
    PERSONAS, MODEL_CATALOG, CONVERSATIONS, Conversation, Message, title_from_query,
)
from models import AgentSpec
from agents import PlannerAgent, OrchestratorAgent, LocalDispatcher


ROUTES = ["direct_answer", "single_tool", "multi_agent", "document_generation"]

# Ceiling on how much attached-file text is injected into a prompt. Without
# this a single large upload silently blows the context window and the LLM
# call fails at request time.
MAX_CONTEXT_CHARS = int(__import__("os").environ.get("MAX_CONTEXT_CHARS", "6000"))
MAX_FARM_STEPS = int(__import__("os").environ.get("MAX_FARM_STEPS", "8"))


def build_context_block(conv: Conversation) -> str:
    """Assemble attached files + pinned memory into prompt-ready text.

    Previously uploads and pinned facts were stored but never reached any
    prompt, so attaching a file did nothing. This is what makes them real.
    """
    parts: List[str] = []

    if conv.memory:
        parts.append("Pinned facts the user wants remembered:\n" +
                     "\n".join(f"- {m}" for m in conv.memory))

    if conv.context_files:
        budget = MAX_CONTEXT_CHARS
        chunks = []
        # newest attachment first — it's the one most likely being referenced
        for f in reversed(conv.context_files):
            if budget <= 0:
                chunks.append(f"[{f['name']}: omitted, context budget exhausted]")
                continue
            excerpt = (f.get("excerpt") or "")[:budget]
            budget -= len(excerpt)
            truncated = " (truncated)" if len(f.get("excerpt") or "") > len(excerpt) else ""
            chunks.append(f"--- {f['name']}{truncated} ---\n{excerpt}")
        parts.append("Attached context:\n" + "\n\n".join(chunks))

    return "\n\n".join(parts)


class Spine:
    """Ordered record of which agents fired this turn."""

    def __init__(self) -> None:
        self.nodes: List[Dict[str, Any]] = []

    def start(self, agent: str, label: str) -> Dict[str, Any]:
        node = {"agent": agent, "label": label, "status": "running",
                "started": time.time(), "detail": None, "ms": None}
        self.nodes.append(node)
        return node

    @staticmethod
    def finish(node: Dict[str, Any], detail: str = "", status: str = "done") -> None:
        node["status"] = status
        node["detail"] = detail
        node["ms"] = int((time.time() - node["started"]) * 1000)

    def to_list(self) -> List[Dict[str, Any]]:
        return [{k: v for k, v in n.items() if k != "started"} for n in self.nodes]


# --------------------------------------------------------------------------
# 1. Query analyzer
# --------------------------------------------------------------------------

class QueryAnalyzerAgent:
    name = "query_analyzer"

    def process(self, query: str, conv: Conversation, spine: Spine) -> Dict[str, Any]:
        node = spine.start(self.name, "Query analyzer")

        history = [
            {"role": m.role, "content": m.content[:400]}
            for m in conv.messages[-6:]
        ]
        file_names = [f["name"] for f in conv.context_files]

        system_prompt = (
            "You clean and resolve user queries in a multi-turn assistant. Input may "
            "be a speech transcript with mis-transcribed technical terms. Resolve "
            "pronouns and follow-ups against the conversation history. Do not answer "
            "the question."
        )
        user_prompt = (
            f"Raw query: {query}\nHistory: {history}\nAttached files: {file_names}\n\n"
            "Return JSON: {\"cleaned_query\": str, \"entities\": [str], "
            "\"is_followup\": bool, \"references_attachment\": bool, "
            "\"corrections\": [str]}"
        )

        def mock() -> Dict[str, Any]:
            lowered = query.lower()
            entities = [e for e in ["jira", "ticket", "git", "commit", "compliance",
                                     "policy", "test", "release", "deploy"]
                        if e in lowered]
            followup_markers = ["it", "that", "those", "them", "this", "again", "also"]
            is_followup = bool(conv.messages) and any(
                f" {m} " in f" {lowered} " for m in followup_markers
            )
            return {
                "cleaned_query": query.strip(),
                "entities": entities,
                "is_followup": is_followup,
                "references_attachment": bool(file_names) and any(
                    w in lowered for w in ["file", "document", "attached", "upload", "this doc"]
                ),
                "corrections": [],
            }

        result = complete_json(system_prompt, user_prompt, mock)
        Spine.finish(node, f"{len(result.get('entities', []))} entities"
                            + (" · follow-up" if result.get("is_followup") else ""))
        return result


# --------------------------------------------------------------------------
# 2. Intent mapper
# --------------------------------------------------------------------------

class IntentMapperAgent:
    name = "intent_mapper"

    def process(self, analysis: Dict[str, Any], persona_id: str, spine: Spine) -> Dict[str, Any]:
        node = spine.start(self.name, "Intent mapper")

        persona = PERSONAS.get(persona_id, PERSONAS["generalist"])
        available = [t["name"] for t in list_tools()]

        system_prompt = (
            "Map the query to exactly one route and name the tools needed.\n"
            "direct_answer: answerable from reasoning alone, no system access.\n"
            "single_tool: one system lookup answers it.\n"
            "multi_agent: spans multiple systems or needs sequenced work.\n"
            "document_generation: the user wants a written deliverable produced."
        )
        user_prompt = (
            f"Query: {analysis.get('cleaned_query')}\n"
            f"Entities: {analysis.get('entities')}\n"
            f"Persona: {persona.label} (default tools {persona.default_tools})\n"
            f"Available tools: {available}\n\n"
            "Return JSON: {\"route\": str, \"tools\": [str], \"reason\": str, "
            "\"document_type\": str|null}"
        )

        def mock() -> Dict[str, Any]:
            q = analysis.get("cleaned_query", "").lower()
            entities = set(analysis.get("entities", []))

            doc_markers = ["write", "draft", "generate", "produce", "create a",
                           "document", "report", "plan", "summary", "note", "rca"]
            if any(m in q for m in doc_markers):
                doc_type = "report"
                for kw, dt in [("test plan", "test_plan"), ("rca", "rca"),
                               ("root cause", "rca"), ("requirement", "requirements"),
                               ("status", "status_note"), ("audit", "audit_evidence")]:
                    if kw in q:
                        doc_type = dt
                        break
                tools = [t for t in persona.default_tools if t in available][:2]
                return {"route": "document_generation", "tools": tools,
                        "reason": "User asked for a written deliverable",
                        "document_type": doc_type}

            tool_for = {"jira": "jira_tool", "ticket": "jira_tool",
                        "git": "git_tool", "commit": "git_tool",
                        "compliance": "compliance_tool", "policy": "compliance_tool"}
            matched = []
            for e in entities:
                t = tool_for.get(e)
                if t and t not in matched:
                    matched.append(t)

            if len(matched) > 1 or (matched and " and " in q):
                return {"route": "multi_agent", "tools": matched,
                        "reason": "Spans multiple systems", "document_type": None}
            if matched:
                return {"route": "single_tool", "tools": matched,
                        "reason": "One system lookup answers this", "document_type": None}
            if any(w in q for w in ["what", "how", "why", "explain", "which", "find", "search"]):
                return {"route": "single_tool", "tools": ["knowledge_search_tool"],
                        "reason": "Knowledge lookup", "document_type": None}
            return {"route": "direct_answer", "tools": [],
                    "reason": "Answerable without system access", "document_type": None}

        result = complete_json(system_prompt, user_prompt, mock)
        if result.get("route") not in ROUTES:
            result["route"] = "direct_answer"
        Spine.finish(node, f"{result['route']} · {result.get('reason', '')}")
        return result


# --------------------------------------------------------------------------
# 3. Document generation
# --------------------------------------------------------------------------

DOC_SECTIONS = {
    "test_plan": ["Scope", "Test cases", "Environments", "Exit criteria", "Risks"],
    "rca": ["Summary", "Timeline", "Root cause", "Impact", "Corrective actions"],
    "requirements": ["Objectives", "Scope", "Functional requirements", "Acceptance criteria", "Out of scope"],
    "status_note": ["Progress", "Risks", "Next steps"],
    "audit_evidence": ["Controls tested", "Evidence collected", "Findings", "Gaps"],
    "report": ["Summary", "Detail", "Recommendations"],
}


def generate_document(doc_type: str, query: str, findings: List[Dict[str, Any]],
                      persona_id: str, spine: Spine, context: str = "") -> Dict[str, Any]:
    node = spine.start("document_generator", "Document generator")
    sections = DOC_SECTIONS.get(doc_type, DOC_SECTIONS["report"])
    persona = PERSONAS.get(persona_id, PERSONAS["generalist"])

    system_prompt = persona.system_prompt + (
        " Produce a structured document. Ground every claim in the supplied findings and "
        "attached context; where a section has no supporting evidence, say so explicitly "
        "rather than inventing content."
    )
    user_prompt = (
        (f"{context}\n\n" if context else "")
        + f"Request: {query}\nDocument type: {doc_type}\nRequired sections: {sections}\n"
        f"Findings from systems: {findings}\n\n"
        "Return JSON: {\"title\": str, \"sections\": [{\"heading\": str, \"body\": str}]}"
    )

    def mock() -> Dict[str, Any]:
        body_bits = []
        if context:
            for line in context.splitlines():
                line = line.strip()
                if line and not line.startswith(("---", "Attached context", "Pinned facts")):
                    body_bits.append(line[:180])
        for f in findings:
            for to in f.get("tool_outputs", []):
                body_bits.append(f"{to['tool']}: {str(to['output'])[:160]}")
        evidence = "\n".join(f"- {b}" for b in body_bits[:8]) or "- No system findings or attached context were available for this request."
        return {
            "title": query.strip()[:70] or doc_type.replace("_", " ").title(),
            "sections": [
                {"heading": s,
                 "body": (evidence if s in ("Summary", "Progress", "Evidence collected", "Detail")
                          else f"Not established from the retrieved findings. Add input for '{s}'.")}
                for s in sections
            ],
        }

    doc = complete_json(system_prompt, user_prompt, mock)

    md_lines = [f"# {doc.get('title', doc_type)}", ""]
    for s in doc.get("sections", []):
        md_lines += [f"## {s.get('heading','')}", "", s.get("body", ""), ""]
    markdown = "\n".join(md_lines)

    artifact = {
        "artifact_id": "a_" + uuid.uuid4().hex[:8],
        "kind": "document",
        "doc_type": doc_type,
        "title": doc.get("title", doc_type),
        "format": "markdown",
        "content": markdown,
        "created_at": time.time(),
    }
    Spine.finish(node, f"{len(doc.get('sections', []))} sections")
    return artifact


# --------------------------------------------------------------------------
# 4. Console orchestrator
# --------------------------------------------------------------------------

class ConsoleOrchestrator:
    name = "orchestrator"

    def run(self, query: str, conv: Conversation, spine: Spine) -> Dict[str, Any]:
        analysis = QueryAnalyzerAgent().process(query, conv, spine)
        intent = IntentMapperAgent().process(analysis, conv.persona, spine)

        node = spine.start(self.name, "Orchestrator")
        route = intent["route"]
        cleaned = analysis.get("cleaned_query", query)
        findings: List[Dict[str, Any]] = []
        artifacts: List[Dict[str, Any]] = []
        agents_invoked: List[str] = []

        if route == "direct_answer":
            Spine.finish(node, "answered directly, no systems touched")
            answer = self._direct_answer(cleaned, conv, spine)

        elif route == "single_tool":
            tool = (intent.get("tools") or ["knowledge_search_tool"])[0]
            Spine.finish(node, f"routed to {tool}")
            tnode = spine.start(f"tool:{tool}", tool.replace("_tool", "").replace("_", " "))
            out = run_tool(tool, {"query": cleaned, "action": "search"})
            Spine.finish(tnode, "returned")
            findings.append({"tool_outputs": [{"tool": tool, "output": out}]})
            answer = self._synthesize(cleaned, findings, conv, spine)

        elif route in ("multi_agent", "document_generation"):
            tools = intent.get("tools") or ["knowledge_search_tool"]
            Spine.finish(node, f"delegating to agent farm ({len(tools)} tool(s))")
            farm = self._invoke_agent_farm(cleaned, tools, conv, spine)
            findings = farm["findings"]
            agents_invoked = farm["agents"]

            if route == "document_generation":
                artifact = generate_document(
                    intent.get("document_type") or "report",
                    cleaned, findings, conv.persona, spine,
                    context=build_context_block(conv),
                )
                artifacts.append(artifact)
                answer = (
                    f"Drafted **{artifact['title']}** covering "
                    f"{len(artifact['content'].split('## ')) - 1} sections. "
                    "It's in the Outputs panel — open it to review or export."
                )
            else:
                answer = self._synthesize(cleaned, findings, conv, spine)

        else:
            Spine.finish(node, "fallback")
            answer = self._direct_answer(cleaned, conv, spine)

        return {
            "answer": answer,
            "analysis": analysis,
            "intent": intent,
            "findings": findings,
            "artifacts": artifacts,
            "agents_invoked": agents_invoked,
        }

    # -- routes ------------------------------------------------------------

    def _invoke_agent_farm(self, query: str, tools: List[str], conv: Conversation,
                           spine: Spine) -> Dict[str, Any]:
        """Hand off to the existing multi-agent engine.

        Reuses PlannerAgent + OrchestratorAgent unchanged -- the console is a
        new front door onto the same farm, not a parallel implementation.
        """
        pnode = spine.start("planner", "Planner")
        persona = PERSONAS.get(conv.persona, PERSONAS["generalist"])
        spec = AgentSpec(name=conv.title, role=persona.label,
                         goal=query, requested_tools=tools)
        understanding = {"domain": "console", "intent": query,
                         "looks_complex": len(tools) > 1,
                         "key_entities": [t.replace("_tool", "") for t in tools]}
        trace: List[Dict[str, Any]] = []
        plan = PlannerAgent().process(understanding, spec, trace)

        # Cost guard: a single console turn should never fan out without
        # bound. Truncating is safer than refusing -- the user still gets a
        # partial answer, and the spine shows what was dropped.
        dropped = 0
        if len(plan.steps) > MAX_FARM_STEPS:
            dropped = len(plan.steps) - MAX_FARM_STEPS
            plan.steps = plan.steps[:MAX_FARM_STEPS]
            surviving = {s.step_id for s in plan.steps}
            for s in plan.steps:
                s.depends_on = [d for d in s.depends_on if d in surviving]

        Spine.finish(pnode, f"{len(plan.steps)} step(s) · {plan.complexity}"
                            + (f" · {dropped} dropped over limit" if dropped else ""))

        agents: List[str] = []
        for role in plan.required_roles():
            anode = spine.start(f"agent:{role}", role.replace("_", " "))
            agents.append(role)
            Spine.finish(anode, "spawned")

        onode = spine.start("agent_farm", "Agent farm execution")
        result = OrchestratorAgent().run(plan, trace, dispatcher=LocalDispatcher())
        Spine.finish(onode, f"{len(result['handoffs'])} handoffs")

        findings = [r for r in result["step_results"].values() if isinstance(r, dict)]
        return {"findings": findings, "agents": agents, "raw": result}

    def _direct_answer(self, query: str, conv: Conversation, spine: Spine) -> str:
        node = spine.start("responder", "Responder")
        persona = PERSONAS.get(conv.persona, PERSONAS["generalist"])
        history = [{"role": m.role, "content": m.content[:400]} for m in conv.messages[-6:]]
        context = build_context_block(conv)

        system_prompt = persona.system_prompt
        user_prompt = (
            (f"{context}\n\n" if context else "")
            + f"Conversation so far: {history}\nQuestion: {query}\n\n"
            "Return JSON: {\"answer\": str}"
        )

        def mock() -> Dict[str, Any]:
            if context:
                names = ", ".join(f["name"] for f in conv.context_files) or "pinned notes"
                return {"answer": (
                    f"[{persona.label}] Working from {names} plus what you've pinned. "
                    f"On \"{query}\" — the attached context is loaded and available; "
                    "tell me which part you want analyzed and I'll go deeper."
                )}
            return {"answer": (
                f"[{persona.label}] I can take this on without touching any connected system. "
                f"To answer \"{query}\" properly I'd want to know the scope you have in mind — "
                "which service, and over what time window."
            )}

        out = complete_json(system_prompt, user_prompt, mock)
        Spine.finish(node, "attached context used" if context else "composed")
        return out.get("answer", "")

    def _synthesize(self, query: str, findings: List[Dict[str, Any]],
                    conv: Conversation, spine: Spine) -> str:
        node = spine.start("responder", "Responder")
        persona = PERSONAS.get(conv.persona, PERSONAS["generalist"])

        system_prompt = persona.system_prompt + (
            " Answer from the findings supplied. State plainly what the findings do not cover."
        )
        user_prompt = (
            (f"{build_context_block(conv)}\n\n" if build_context_block(conv) else "")
            + f"Question: {query}\nFindings: {str(findings)[:3000]}\n\n"
            "Return JSON: {\"answer\": str}"
        )

        def mock() -> Dict[str, Any]:
            lines = []
            for f in findings:
                for to in f.get("tool_outputs", []):
                    lines.append(f"- **{to['tool']}** → {str(to['output'])[:200]}")
            joined = "\n".join(lines) or "- No findings returned."
            attached = ""
            if conv.context_files:
                names = ", ".join(f["name"] for f in conv.context_files)
                attached = f"\n\nRead alongside your attached context ({names})."
            return {"answer": (
                f"[{persona.label}] Here's what the connected systems returned for "
                f"\"{query}\":\n\n{joined}{attached}\n\n"
                "This reflects only the systems queried above — anything outside them isn't covered."
            )}

        out = complete_json(system_prompt, user_prompt, mock)
        Spine.finish(node, "composed")
        return out.get("answer", "")


# --------------------------------------------------------------------------
# Turn entry point
# --------------------------------------------------------------------------

def run_turn(conversation_id: Optional[str], query: str, persona: str,
             model: str) -> Dict[str, Any]:
    # Validate against the catalogs. An unknown persona previously reached
    # PERSONAS[...] unguarded deeper in the pipeline and raised KeyError.
    if persona not in PERSONAS:
        persona = "generalist"
    if model not in {m["id"] for m in MODEL_CATALOG}:
        model = "balanced"

    conv = CONVERSATIONS.get(conversation_id) if conversation_id else None
    if conv is None:
        conv = CONVERSATIONS.create(persona=persona, model=model,
                                     title=title_from_query(query))
    conv.persona, conv.model = persona, model

    # Conversations created via POST /api/conversations start as
    # "New conversation" and never got retitled, so the sidebar filled with
    # identical entries. Title from the first real question instead.
    if conv.title == "New conversation" and not conv.messages:
        conv.title = title_from_query(query)

    conv.messages.append(Message(role="user", content=query))

    spine = Spine()
    result = ConsoleOrchestrator().run(query, conv, spine)

    conv.messages.append(Message(
        role="assistant", content=result["answer"],
        meta={"spine": spine.to_list(), "route": result["intent"]["route"],
              "agents": result["agents_invoked"]},
    ))
    conv.artifacts.extend(result["artifacts"])

    return {
        "conversation_id": conv.conversation_id,
        "title": conv.title,
        "answer": result["answer"],
        "route": result["intent"]["route"],
        "reason": result["intent"].get("reason", ""),
        "spine": spine.to_list(),
        "agents_invoked": result["agents_invoked"],
        "tools_used": result["intent"].get("tools", []),
        "artifacts": conv.artifacts,
        "analysis": result["analysis"],
    }
