"""
Utility registry — how teams turn their own Python into a tool the harness
can call, without a platform-team PR for every new automation.

Two hosting paths, with two different trust defaults on purpose:

  FILESYSTEM utilities live under utilities/<name>/{utility.yaml, main.py}.
  Getting one merged is a normal PR, so it went through code review. The
  manifest is trusted to DECLARE its own risk level and whether it may run
  TRUSTED (in-process, no sandbox) or must run SANDBOXED.

  UPLOADED utilities arrive at runtime via POST /v1/utilities -- a team
  hosting something they wrote locally, with no review step in between.
  These ALWAYS run sandboxed and ALWAYS start at HIGH risk regardless of
  what the manifest claims, full stop. An upload endpoint that let the
  uploader also self-declare "trust me, this is low risk" would just be
  arbitrary code execution with extra steps. A team that wants a lower
  risk tier for a utility promotes it by committing it to the filesystem
  path instead, where a reviewer other than the author signs off.

Execution:

  TRUSTED  -> imported and called in-process. Fast, no sandbox overhead.
              Only reachable for filesystem utilities that declare
              trusted: true -- this is a real privilege, use it sparingly.
  SANDBOXED -> leased from the sandbox pool (kind="python_utility") the
              same way execution_harness_tool already works, so it gets
              the same isolation, the same autoscaled capacity, and the
              same approval-gate treatment as any other write-capable tool.
"""

from __future__ import annotations

import importlib.util
import os
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

UTILITIES_DIR = os.environ.get("HARNESS_UTILITIES_DIR", "./utilities")


class UtilityError(RuntimeError):
    pass


@dataclass
class Utility:
    name: str
    version: str
    description: str
    owner: str
    trusted: bool                     # True => in-process; False => sandboxed
    risk: str                         # "low" | "medium" | "high" -- feeds approvals.py's gate
    entrypoint: str                   # "main:run" for filesystem; ignored for uploaded (code is inline)
    requirements: List[str] = field(default_factory=list)
    input_schema: Dict[str, Any] = field(default_factory=dict)
    source: str = "filesystem"        # "filesystem" | "uploaded"
    dir_path: Optional[str] = None    # filesystem utilities only
    code: Optional[str] = None        # uploaded utilities only: the raw script text
    registered_at: float = field(default_factory=time.time)
    _fn: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None

    def to_public(self) -> Dict[str, Any]:
        return {
            "name": self.name, "version": self.version, "description": self.description,
            "owner": self.owner, "trusted": self.trusted, "risk": self.risk,
            "source": self.source, "input_schema": self.input_schema,
            "requirements": self.requirements, "registered_at": self.registered_at,
        }


def _load_yaml_manifest(path: str) -> Dict[str, Any]:
    """Tiny manifest parser -- avoids adding a yaml dependency for a flat
    key: value / key: [list] file. Falls back to real yaml if it's already
    installed elsewhere in the environment."""
    try:
        import yaml  # type: ignore
        with open(path, "r", encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}
    except ImportError:
        pass

    out: Dict[str, Any] = {}
    cur_list_key = None
    with open(path, "r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if not line.strip() or line.strip().startswith("#"):
                continue
            if line.startswith("  - ") and cur_list_key:
                out.setdefault(cur_list_key, []).append(line.strip()[2:].strip())
                continue
            if ":" in line:
                k, _, v = line.partition(":")
                k, v = k.strip(), v.strip()
                if v == "":
                    cur_list_key = k
                    out[k] = []
                else:
                    cur_list_key = None
                    if v.lower() in ("true", "false"):
                        out[k] = v.lower() == "true"
                    else:
                        out[k] = v.strip('"').strip("'")
    return out


class UtilityRegistry:
    def __init__(self, root: str = UTILITIES_DIR):
        self.root = root
        self._filesystem: Dict[str, Utility] = {}
        self._uploaded: Dict[str, Utility] = {}
        self._lock = threading.Lock()
        self.reload()

    # ------------------------------------------------------------ discovery
    def reload(self) -> int:
        found: Dict[str, Utility] = {}
        if os.path.isdir(self.root):
            for entry in sorted(os.listdir(self.root)):
                d = os.path.join(self.root, entry)
                manifest_path = os.path.join(d, "utility.yaml")
                if not os.path.isfile(manifest_path):
                    continue
                try:
                    m = _load_yaml_manifest(manifest_path)
                    u = Utility(
                        name=m.get("name", entry),
                        version=str(m.get("version", "0.1")),
                        description=m.get("description", ""),
                        owner=m.get("owner", "unknown"),
                        trusted=bool(m.get("trusted", False)),
                        risk=m.get("risk", "medium"),
                        entrypoint=m.get("entrypoint", "main:run"),
                        requirements=m.get("requirements", []) or [],
                        input_schema=m.get("input_schema", {}) or {},
                        source="filesystem", dir_path=d,
                    )
                    found[u.name] = u
                except Exception as exc:  # noqa: BLE001
                    # A malformed manifest must not take down discovery of
                    # every other utility -- skip it, don't crash reload().
                    sys.stderr.write(f"[utility_registry] skipping {d}: {exc}\n")
        with self._lock:
            self._filesystem = found
        return len(found)

    # -------------------------------------------------------------- upload
    def upload(self, name: str, description: str, owner: str, code: str,
              input_schema: Optional[Dict[str, Any]] = None,
              requirements: Optional[List[str]] = None) -> Utility:
        """Self-service hosting. ALWAYS sandboxed, ALWAYS high risk --
        see module docstring for why this isn't configurable here."""
        if not name or not name.replace("-", "").replace("_", "").isalnum():
            raise UtilityError("Utility name must be alphanumeric (dashes/underscores ok).")
        with self._lock:
            if name in self._filesystem:
                raise UtilityError(
                    f"'{name}' is already a filesystem-managed utility owned by "
                    f"{self._filesystem[name].owner}. Uploading can't shadow a "
                    "reviewed utility -- pick a different name.")
            existing = self._uploaded.get(name)
            version = str(round(float(existing.version) + 0.1, 1)) if existing else "0.1"
            u = Utility(
                name=name, version=version, description=description, owner=owner,
                trusted=False, risk="high", entrypoint="", source="uploaded",
                code=code, input_schema=input_schema or {},
                requirements=requirements or [],
            )
            self._uploaded[name] = u
        return u

    def remove_uploaded(self, name: str) -> bool:
        with self._lock:
            return self._uploaded.pop(name, None) is not None

    # ------------------------------------------------------------- lookups
    def all(self) -> List[Utility]:
        with self._lock:
            return list(self._filesystem.values()) + list(self._uploaded.values())

    def get(self, name: str) -> Optional[Utility]:
        with self._lock:
            return self._filesystem.get(name) or self._uploaded.get(name)

    # ------------------------------------------------------------- execute
    def execute(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        u = self.get(name)
        if not u:
            return {"error": "unknown_utility", "detail": f"'{name}' is not registered."}

        missing = [k for k, spec in u.input_schema.items()
                  if isinstance(spec, dict) and spec.get("required") and k not in params]
        if missing:
            return {"error": "missing_params", "detail": f"Missing required: {missing}"}

        if u.trusted and u.source == "filesystem":
            return self._run_in_process(u, params)
        return self._run_sandboxed(u, params)

    def _run_in_process(self, u: Utility, params: Dict[str, Any]) -> Dict[str, Any]:
        try:
            fn = self._resolve_entrypoint(u)
            out = fn(params)
            if not isinstance(out, dict):
                out = {"result": out}
            return out
        except Exception as exc:  # noqa: BLE001
            return {"error": "utility_failed", "detail": str(exc)}

    def _resolve_entrypoint(self, u: Utility) -> Callable[[Dict[str, Any]], Any]:
        if u._fn is not None:
            return u._fn
        module_name, _, func_name = u.entrypoint.partition(":")
        module_path = os.path.join(u.dir_path, f"{module_name}.py")
        if not os.path.isfile(module_path):
            raise UtilityError(f"Entrypoint module not found: {module_path}")
        spec = importlib.util.spec_from_file_location(
            f"utility_{u.name}_{module_name}", module_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore
        fn = getattr(mod, func_name, None)
        if fn is None:
            raise UtilityError(f"'{func_name}' not found in {module_path}")
        u._fn = fn
        return fn

    def _run_sandboxed(self, u: Utility, params: Dict[str, Any]) -> Dict[str, Any]:
        from sandbox_pool import POOL, Backpressure
        session_id = params.pop("_session_id", "utility-" + uuid.uuid4().hex[:8])
        code = u.code
        if code is None and u.dir_path:
            module_name, _, _ = u.entrypoint.partition(":")
            module_path = os.path.join(u.dir_path, f"{module_name}.py")
            if os.path.isfile(module_path):
                with open(module_path, "r", encoding="utf-8") as fh:
                    code = fh.read()
        try:
            with POOL.lease_ctx(session_id, kind="python_utility", timeout_s=45) as lease:
                # Real dispatch: POST {code, entrypoint, params, requirements}
                # to lease.endpoint's /execute, where the sandbox pip-installs
                # requirements.txt into a fresh venv, then calls entrypoint(params).
                # Simulated here, same as execution_harness_tool.
                return {
                    "utility": u.name, "version": u.version,
                    "sandbox": lease.endpoint, "lease_id": lease.lease_id,
                    "submitted_chars": len(code or ""),
                    "stdout": f"<simulated sandboxed run of {u.name}>",
                    "exit_code": 0,
                }
        except Backpressure as exc:
            return {"error": "sandbox_pool_exhausted", "detail": str(exc)}


UTILITIES = UtilityRegistry()


# ------------------------------------------------------------- scaffolding

MANIFEST_TEMPLATE = """\
name: {name}
version: "0.1"
description: {description}
owner: {owner}
trusted: false      # true only after review -- runs in-process with no sandbox
risk: medium        # low | medium | high -- low auto-approves like a built-in tool
entrypoint: main:run
requirements:
input_schema:
  # example:
  # ticket_id: {{type: string, required: true}}
"""

MAIN_TEMPLATE = '''\
"""%s -- generated scaffold. Replace this with real logic."""


def run(params: dict) -> dict:
    """Entrypoint called by the harness. `params` matches input_schema.
    Must return a dict (or a value the caller wraps as {"result": value})."""
    return {"echo": params}
'''


def scaffold(name: str, description: str = "", owner: str = "your-team",
            root: str = UTILITIES_DIR) -> str:
    """Create utilities/<name>/{utility.yaml, main.py}. Returns the path.
    A team runs this once, edits main.py, opens a PR -- that PR IS the
    review step that earns the lower-risk / trusted execution tiers."""
    d = os.path.join(root, name)
    if os.path.exists(d):
        raise UtilityError(f"{d} already exists.")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "utility.yaml"), "w", encoding="utf-8") as fh:
        fh.write(MANIFEST_TEMPLATE.format(name=name, description=description or name,
                                          owner=owner))
    with open(os.path.join(d, "main.py"), "w", encoding="utf-8") as fh:
        fh.write(MAIN_TEMPLATE % name)
    return d
