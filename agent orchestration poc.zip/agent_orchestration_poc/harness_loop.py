"""
The harness loop — the runtime layer that turns a model into a working agent.

  observe -> plan -> [checkpoint?] -> act -> evaluate -> compact -> repeat

Every transition emits an event, so a calling agent watching the stream sees
the run unfold in real time rather than waiting for a terminal payload.

Three things here are enforcement, not prompting:

1. APPROVAL GATES BLOCK. A write-scoped tool call does not dispatch until a
   checkpoint is resolved. The loop thread genuinely waits. Prompting a
   model to "ask before writing" is not a control -- a model can decline
   to follow it. This is a code path the model cannot route around.

2. TOOL GRANTS ARE CHECKED AGAINST THE SESSION, not the plan. If the model
   plans a call to a tool the session was never granted, dispatch is
   refused at the boundary. The planner is untrusted input.

3. STEP AND WALL-CLOCK BUDGETS ARE HARD. An agent loop without a step
   ceiling is an unbounded bill and an unbounded outage.
"""

from __future__ import annotations

import os
import threading
import time
import traceback
import uuid
from typing import Any, Callable, Dict, List, Optional

from harness_core import (
    SESSIONS, Session, SessionState, EventType, Checkpoint, Artifact,
)
from harness_context import SKILLS, SessionMemory, Skill
from llm_client import complete_json
from tool_registry import list_tools, get_tool, is_known_tool, run_tool
from approvals import TOOL_RISK, Severity

MAX_STEPS = int(os.environ.get("HARNESS_MAX_STEPS", "12"))
MAX_WALL_S = float(os.environ.get("HARNESS_MAX_WALL_S", "300"))
APPROVAL_TIMEOUT_S = float(os.environ.get("HARNESS_APPROVAL_TIMEOUT_S", "600"))
AUTO_APPROVE_LOW = os.environ.get("HARNESS_AUTO_APPROVE_LOW", "true").lower() == "true"
MAX_SUBAGENT_DEPTH = int(os.environ.get("HARNESS_MAX_SUBAGENT_DEPTH", "2"))

_MEMORIES: Dict[str, SessionMemory] = {}
_MEM_LOCK = threading.Lock()


def memory_for(session_id: str) -> SessionMemory:
    with _MEM_LOCK:
        if session_id not in _MEMORIES:
            _MEMORIES[session_id] = SessionMemory()
        return _MEMORIES[session_id]


class BudgetExceeded(RuntimeError):
    pass


class CheckpointRejected(RuntimeError):
    pass


def _tool_severity(tool: str) -> Severity:
    if tool in TOOL_RISK:
        sev, _ = TOOL_RISK[tool]
        return sev
    # Not a built-in -- check whether it's a published utility and use
    # ITS declared risk. Uploaded (unreviewed) utilities always come back
    # "high" from utility_registry regardless of what the payload claimed,
    # so this can't be used to smuggle a low-risk self-declaration past
    # the approval gate.
    from utility_registry import UTILITIES
    u = UTILITIES.get(tool)
    if u is not None:
        return {"low": Severity.LOW, "medium": Severity.MEDIUM,
               "high": Severity.HIGH}.get(u.risk, Severity.HIGH)
    return Severity.MEDIUM  # genuinely unclassified name -- default


def _requires_approval(tool: str) -> bool:
    sev = _tool_severity(tool)
    if sev == Severity.LOW and AUTO_APPROVE_LOW:
        return False
    return True


class HarnessRun:
    """One turn of the loop for one session."""

    def __init__(self, session: Session, goal: str, turn_id: str,
                 depth: int = 0, budget_steps: Optional[int] = None):
        self.session = session
        self.goal = goal
        self.turn_id = turn_id
        self.depth = depth
        self.bus = SESSIONS.bus(session.session_id)
        self.memory = memory_for(session.session_id)
        self.started = time.time()
        self.steps_used = 0
        self.budget_steps = budget_steps or MAX_STEPS
        self.tool_calls: List[Dict[str, Any]] = []
        self.refusals: List[Dict[str, Any]] = []      # denied / blocked at the gate
        self.selected_skills: List[Skill] = []

    # ------------------------------------------------------------ helpers --
    def emit(self, etype: EventType, data: Dict[str, Any]) -> None:
        self.bus.emit(etype, data, turn_id=self.turn_id)

    def _check_budget(self) -> None:
        if self.steps_used >= self.budget_steps:
            raise BudgetExceeded(
                f"Step budget exhausted ({self.budget_steps} steps). "
                "Raise HARNESS_MAX_STEPS or narrow the goal.")
        elapsed = time.time() - self.started
        if elapsed > MAX_WALL_S:
            raise BudgetExceeded(
                f"Wall-clock budget exhausted ({MAX_WALL_S:.0f}s).")

    # -------------------------------------------------------- checkpoints --
    def request_checkpoint(self, kind: str, prompt: str,
                           payload: Dict[str, Any]) -> Checkpoint:
        cp = Checkpoint(checkpoint_id="cp_" + uuid.uuid4().hex[:12],
                        kind=kind, prompt=prompt, payload=payload)
        self.session.checkpoints[cp.checkpoint_id] = cp
        prior_state = self.session.state
        self.session.state = (SessionState.AWAITING_APPROVAL.value if kind == "approval"
                              else SessionState.AWAITING_ANSWER.value)
        self.session.touch()

        self.emit(EventType.APPROVAL_REQUESTED if kind == "approval"
                  else EventType.QUESTION_ASKED,
                  {"checkpoint_id": cp.checkpoint_id, "prompt": prompt, **payload})

        # Block. This is the control.
        got = cp.wait(APPROVAL_TIMEOUT_S)
        self.session.state = prior_state
        if not got:
            cp.resolve(approved=False, answer=None, by="timeout")
            self.emit(EventType.APPROVAL_RESOLVED,
                      {"checkpoint_id": cp.checkpoint_id, "approved": False,
                       "resolved_by": "timeout"})
            raise CheckpointRejected(
                f"Checkpoint {cp.checkpoint_id} timed out after {APPROVAL_TIMEOUT_S:.0f}s "
                "with no caller response.")

        self.emit(EventType.APPROVAL_RESOLVED if kind == "approval"
                  else EventType.QUESTION_ANSWERED,
                  {"checkpoint_id": cp.checkpoint_id, "approved": cp.approved,
                   "answer": cp.answer, "resolved_by": cp.resolved_by})
        return cp

    # -------------------------------------------------------------- tools --
    def dispatch_tool(self, tool: str, params: Dict[str, Any]) -> Dict[str, Any]:
        # Boundary check: the plan is untrusted.
        if tool not in self.session.granted_tools:
            result = {"error": "tool_not_granted",
                      "detail": f"'{tool}' was not granted to this session. "
                                f"Granted: {self.session.granted_tools}"}
            self.refusals.append({"tool": tool, "reason": "not_granted"})
            self.emit(EventType.TOOL_CALL_FAILED, {"tool": tool, **result})
            self.memory.add("working",
                            f"{tool} was NOT executed: not granted to this session.",
                            tags=[tool, "refused"])
            return result

        if not is_known_tool(tool):
            result = {"error": "unknown_tool", "detail": f"'{tool}' is not registered."}
            self.emit(EventType.TOOL_CALL_FAILED, {"tool": tool, **result})
            return result

        sev = _tool_severity(tool)
        if _requires_approval(tool):
            cp = self.request_checkpoint(
                "approval",
                f"Approve {tool} ({sev.value} risk)?",
                {"tool": tool, "params": params, "severity": sev.value},
            )
            if not cp.approved:
                result = {"error": "rejected_by_caller",
                          "detail": f"Caller declined the {tool} call."}
                self.refusals.append({"tool": tool, "reason": "rejected_by_caller"})
                self.emit(EventType.TOOL_CALL_FAILED, {"tool": tool, **result})
                self.memory.add("working",
                                f"{tool} was NOT executed: the caller declined approval.",
                                tags=[tool, "refused"])
                return result

        self.emit(EventType.TOOL_CALL_STARTED,
                  {"tool": tool, "params": params, "severity": sev.value})
        t0 = time.time()
        try:
            out = run_tool(tool, params)
            ms = int((time.time() - t0) * 1000)
            self.emit(EventType.TOOL_CALL_COMPLETED,
                      {"tool": tool, "ms": ms, "output": out})
            self.tool_calls.append({"tool": tool, "params": params,
                                     "output": out, "ms": ms})
            self.memory.add("working", f"{tool} returned: {str(out)[:600]}",
                            tags=[tool])
            return out
        except Exception as exc:  # noqa: BLE001
            ms = int((time.time() - t0) * 1000)
            result = {"error": "tool_failed", "detail": str(exc)}
            self.emit(EventType.TOOL_CALL_FAILED, {"tool": tool, "ms": ms, **result})
            self.memory.add("working", f"{tool} failed: {exc}", tags=[tool, "error"])
            return result

    # ----------------------------------------------------------- subagent --
    def spawn_subagent(self, sub_goal: str, tools: List[str]) -> Dict[str, Any]:
        """Delegate an isolated task; only the SUMMARY returns to parent context.

        This is the context-engineering payoff: a subagent can burn ten steps
        of noisy tool output and hand back three lines, leaving the parent's
        working context clean.
        """
        if self.depth >= MAX_SUBAGENT_DEPTH:
            return {"error": "max_depth", "detail": f"Subagent depth {MAX_SUBAGENT_DEPTH} reached."}

        allowed = [t for t in tools if t in self.session.granted_tools]
        sub_id = "sub_" + uuid.uuid4().hex[:8]
        self.emit(EventType.SUBAGENT_SPAWNED,
                  {"subagent_id": sub_id, "goal": sub_goal, "tools": allowed,
                   "depth": self.depth + 1})

        sub_session = Session(
            session_id=self.session.session_id,   # shares bus/stream
            caller=f"subagent:{sub_id}",
            agent_profile=self.session.agent_profile,
            granted_tools=allowed,
        )
        sub_session.checkpoints = self.session.checkpoints
        sub = HarnessRun(sub_session, sub_goal, self.turn_id,
                         depth=self.depth + 1,
                         budget_steps=max(2, self.budget_steps // 2))
        sub.memory = SessionMemory()          # isolated context
        sub.bus = self.bus
        try:
            result = sub.execute()
            summary = result.get("answer", "")[:1200]
        except Exception as exc:  # noqa: BLE001
            summary = f"Subagent failed: {exc}"
            result = {"answer": summary, "tool_calls": []}

        self.emit(EventType.SUBAGENT_RETURNED,
                  {"subagent_id": sub_id, "summary": summary,
                   "tool_calls": len(result.get("tool_calls", []))})
        self.memory.add("working", f"Subagent [{sub_goal[:60]}] concluded: {summary}",
                        tags=["subagent"])
        return {"summary": summary}

    # --------------------------------------------------------------- plan --
    def plan(self) -> Dict[str, Any]:
        self.selected_skills = SKILLS.select(self.goal)
        skill_bodies = "\n\n".join(
            f"### {s.name}\n{s.body}" for s in self.selected_skills)
        granted = [t for t in self.session.granted_tools]
        tool_specs = [
            {"name": t["name"], "description": t["description"]}
            for t in list_tools() if t["name"] in granted
        ]

        system = (
            "You are the planning stage of an agent harness. Produce a minimal "
            "ordered plan that reaches the goal using only the granted tools. "
            "Prefer the fewest steps that produce defensible evidence.\n\n"
            + SKILLS.constraint_block()
        )
        user = (
            f"Goal: {self.goal}\n\n"
            f"Granted tools: {tool_specs}\n\n"
            f"Relevant skills:\n{skill_bodies or '(none matched)'}\n\n"
            f"Context so far:\n{self.memory.build_context()[:4000]}\n\n"
            "Return JSON: {\"steps\": [{\"action\": \"tool\"|\"subagent\"|\"answer\", "
            "\"tool\": str|null, \"params\": object|null, \"sub_goal\": str|null, "
            "\"why\": str}], \"complexity\": \"simple\"|\"multi_step\"}"
        )

        def mock() -> Dict[str, Any]:
            steps = []
            goal_l = self.goal.lower()
            for t in granted:
                key = t.replace("_tool", "")
                if key in goal_l or key.split("_")[0] in goal_l:
                    steps.append({"action": "tool", "tool": t,
                                  "params": {"query": self.goal[:120]},
                                  "sub_goal": None,
                                  "why": f"Goal references {key}."})
            if not steps and granted:
                steps.append({"action": "tool", "tool": granted[0],
                              "params": {"query": self.goal[:120]},
                              "sub_goal": None,
                              "why": "Default to the first granted tool for evidence."})
            steps.append({"action": "answer", "tool": None, "params": None,
                          "sub_goal": None, "why": "Synthesize from gathered evidence."})
            return {"steps": steps,
                    "complexity": "multi_step" if len(steps) > 2 else "simple"}

        out = complete_json(system, user, mock)
        steps = out.get("steps") or []
        if len(steps) > self.budget_steps:
            steps = steps[:self.budget_steps]
        out["steps"] = steps

        self.emit(EventType.PLAN_DRAFTED, {
            "steps": [{"action": s.get("action"), "tool": s.get("tool"),
                       "why": s.get("why")} for s in steps],
            "complexity": out.get("complexity"),
            "skills_selected": [s.name for s in self.selected_skills],
        })
        return out

    # ------------------------------------------------------------ execute --
    def execute(self) -> Dict[str, Any]:
        plan = self.plan()
        answer = ""

        for idx, step in enumerate(plan.get("steps", [])):
            self._check_budget()
            self.steps_used += 1
            action = step.get("action")
            self.emit(EventType.STEP_STARTED,
                      {"index": idx, "action": action, "tool": step.get("tool"),
                       "why": step.get("why")})

            if action == "tool" and step.get("tool"):
                out = self.dispatch_tool(step["tool"], step.get("params") or {})
                self.emit(EventType.STEP_COMPLETED,
                          {"index": idx, "ok": "error" not in out})

            elif action == "subagent" and step.get("sub_goal"):
                res = self.spawn_subagent(step["sub_goal"],
                                          step.get("params", {}).get("tools",
                                                                      self.session.granted_tools))
                self.emit(EventType.STEP_COMPLETED,
                          {"index": idx, "ok": "error" not in res})

            elif action == "answer":
                answer = self.synthesize()
                self.emit(EventType.STEP_COMPLETED, {"index": idx, "ok": True})

            if self.memory.needs_compaction():
                stats = self.memory.compact()
                self.emit(EventType.CONTEXT_COMPACTED, stats)

        if not answer:
            answer = self.synthesize()

        score = self.evaluate(answer)
        return {"answer": answer, "tool_calls": self.tool_calls,
                "refusals": self.refusals,
                "steps_used": self.steps_used, "evaluation": score,
                "skills_used": [s.name for s in self.selected_skills],
                "memory": self.memory.stats()}

    # ---------------------------------------------------------- synthesis --
    def synthesize(self) -> str:
        system = (
            "You are the synthesis stage of an agent harness. Answer strictly "
            "from the evidence gathered in this session. Name what the evidence "
            "does not cover instead of filling the gap.\n\n"
            + SKILLS.constraint_block()
        )
        user = (f"Goal: {self.goal}\n\n"
                f"Evidence:\n{self.memory.build_context()}\n\n"
                "Return JSON: {\"answer\": str}")

        def mock() -> Dict[str, Any]:
            if not self.tool_calls:
                if self.refusals:
                    blocked = ", ".join(sorted({r["tool"] for r in self.refusals}))
                    return {"answer": (
                        f"Could not act on: {self.goal}\n\n"
                        f"Every required tool call was blocked ({blocked}). "
                        "This is a permission outcome, not a finding — nothing was "
                        "learned about system state. Grant or approve the tools above "
                        "to get a real answer.")}
                return {"answer": f"No tool evidence was gathered for: {self.goal}. "
                                  "Nothing can be asserted about system state."}
            lines = [f"- {c['tool']}: {str(c['output'])[:180]}" for c in self.tool_calls]
            return {"answer": "Findings for \"" + self.goal + "\":\n" + "\n".join(lines)
                              + "\n\nScope is limited to the tools called above."}

        out = complete_json(system, user, mock)
        answer = out.get("answer", "")
        self.emit(EventType.MESSAGE_DELTA, {"text": answer, "final": True})
        return answer

    # ---------------------------------------------------------- evaluator --
    def evaluate(self, answer: str) -> Dict[str, Any]:
        """Cheap self-check. Grounding is the failure mode that matters."""
        errors = [c for c in self.tool_calls if isinstance(c.get("output"), dict)
                  and c["output"].get("error")]
        grounded = bool(self.tool_calls)

        # A run where every attempted tool call was refused is NOT "ok" just
        # because the answer honestly says so. The calling agent needs to
        # distinguish "nothing to find" from "I was not allowed to look",
        # because only the second is fixed by granting or approving.
        if self.refusals and not self.tool_calls:
            verdict = "blocked"
        elif not grounded:
            verdict = "ungrounded"
        elif errors or self.refusals:
            verdict = "partial"
        else:
            verdict = "ok"

        score = {
            "grounded": grounded,
            "tool_calls": len(self.tool_calls),
            "failed_tool_calls": len(errors),
            "refused_tool_calls": len(self.refusals),
            "refusals": self.refusals,
            "steps_used": self.steps_used,
            "compactions": self.memory.stats()["compactions"],
            "verdict": verdict,
        }
        self.emit(EventType.EVAL_SCORED, score)
        return score


# ----------------------------------------------------------- entry points --

def run_turn_async(session: Session, goal: str,
                   on_done: Optional[Callable[[Dict[str, Any]], None]] = None) -> str:
    """Start a turn on a worker thread and return immediately.

    Callers get progress from the event stream; the HTTP request that
    started the turn does not stay open for the whole run.
    """
    turn_id = "turn_" + uuid.uuid4().hex[:12]
    bus = SESSIONS.bus(session.session_id)
    session.state = SessionState.RUNNING.value
    session.touch()
    bus.emit(EventType.TURN_STARTED, {"goal": goal}, turn_id=turn_id)

    def worker() -> None:
        run = HarnessRun(session, goal, turn_id)
        try:
            result = run.execute()
            session.last_result = result
            session.turns.append({"turn_id": turn_id, "goal": goal,
                                   "answer": result["answer"],
                                   "steps_used": result["steps_used"]})
            session.state = SessionState.COMPLETED.value
            session.touch()
            bus.emit(EventType.TURN_COMPLETED, result, turn_id=turn_id)
            if on_done:
                on_done(result)
        except (BudgetExceeded, CheckpointRejected) as exc:
            session.state = SessionState.FAILED.value
            session.touch()
            payload = {"error": type(exc).__name__, "detail": str(exc),
                       "steps_used": run.steps_used,
                       "tool_calls": run.tool_calls}
            session.last_result = payload
            bus.emit(EventType.TURN_FAILED, payload, turn_id=turn_id)
        except Exception as exc:  # noqa: BLE001
            session.state = SessionState.FAILED.value
            session.touch()
            payload = {"error": "harness_error", "detail": str(exc),
                       "trace": traceback.format_exc()[-1200:]}
            session.last_result = payload
            bus.emit(EventType.TURN_FAILED, payload, turn_id=turn_id)

    threading.Thread(target=worker, daemon=True,
                     name=f"harness-{turn_id}").start()
    return turn_id
