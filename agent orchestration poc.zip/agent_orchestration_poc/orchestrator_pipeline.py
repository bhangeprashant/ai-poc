"""
Two-phase pipeline with a human-in-the-loop gate between them.

  PHASE 1  plan_run(agent_md, query)
             parse -> understand -> plan -> manifest -> risk assessment
             Stops. Deploys nothing. Calls no tools. Returns a run in
             state AWAITING_APPROVAL (or auto-approves if the risk
             assessment says the run is low-risk and auto-approval is on).

  --- human reviews plan + manifest + risk flags, may edit, then decides ---

  PHASE 2  execute_run(run_id, approved, edits, reviewer)
             apply edits -> deploy via backend -> dispatch steps over the
             handoff protocol -> synthesize -> teardown (always).

Nothing between the two phases is implicit: the manifest the human sees
in phase 1 is the exact object handed to the backend in phase 2.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from models import AgentSpec, Plan, PlanStep
from agents import UnderstandingAgent, PlannerAgent, OrchestratorAgent, LocalDispatcher, HttpDispatcher
from deployment import plan_manifest, get_backend, DEPLOY_BACKEND
from approvals import (
    STORE, RunState, assess_risk, apply_reviewer_edits,
)


# --------------------------------------------------------------------------
# Phase 1 — plan and stop
# --------------------------------------------------------------------------

def plan_run(agent_md: str, user_query: str, backend: Optional[str] = None) -> Dict[str, Any]:
    backend = backend or DEPLOY_BACKEND
    trace: List[Dict[str, Any]] = []

    spec = AgentSpec.parse(agent_md)
    trace.append({"agent": "spec_parser", "action": "parse_agent_md", "output": spec.__dict__})

    understanding = UnderstandingAgent().process(user_query, spec, trace)
    plan_obj = PlannerAgent().process(understanding, spec, trace)

    plan_dict = {
        "complexity": plan_obj.complexity,
        "summary": plan_obj.summary,
        "steps": [s.__dict__ for s in plan_obj.steps],
    }

    manifest = plan_manifest(spec, plan_dict, backend)

    agents_planned = [
        {"role": s["env"]["AGENT_ROLE"],
         "tools": [t for t in s["env"]["AGENT_TOOLS"].split(",") if t]}
        for s in manifest["services"]
    ]
    risk = assess_risk(agents_planned, backend, spec.constraints)
    trace.append({"agent": "risk_assessor", "action": "assess", "output": risk})

    run = STORE.create(
        spec=spec.__dict__,
        understanding=understanding,
        plan=plan_dict,
        manifest=manifest,
        risk=risk,
        backend=backend,
        trace=trace,
    )

    # Seamless path: routine low-risk runs proceed without waiting on a
    # human. Anything writing, executing code, or touching the cluster
    # falls through to the gate.
    if risk["auto_approvable"]:
        trace.append({"agent": "approval_gate", "action": "auto_approved",
                      "output": {"reason": "highest severity is low"}})
        return execute_run(run.run_id, approved=True, reviewer="auto-policy")

    return run.to_dict()


# --------------------------------------------------------------------------
# Phase 2 — deploy and execute, only after a decision
# --------------------------------------------------------------------------

def execute_run(run_id: str, approved: bool, reviewer: str = "unknown",
                edits: Optional[Dict[str, Any]] = None,
                rejection_reason: str = "") -> Dict[str, Any]:
    run = STORE.get(run_id)
    if run is None:
        return {"error": f"unknown run_id '{run_id}'"}
    if run.state == RunState.EXPIRED:
        return {**run.to_dict(), "error": "approval window expired — re-plan the run"}
    if run.state not in (RunState.AWAITING_APPROVAL,):
        return {**run.to_dict(), "error": f"run already in state '{run.state.value}'"}

    if not approved:
        run.state = RunState.REJECTED
        run.decision = {"approved": False, "reviewer": reviewer, "reason": rejection_reason}
        run.trace.append({"agent": "approval_gate", "action": "rejected",
                          "output": {"reviewer": reviewer, "reason": rejection_reason}})
        return run.to_dict()

    # --- apply the reviewer's edits, then re-derive the manifest so what
    # --- gets deployed matches what was actually approved
    change_log: List[str] = []
    effective_plan = run.plan
    if edits:
        effective_plan, change_log = apply_reviewer_edits(run.plan, edits)
        run.manifest = plan_manifest(AgentSpec(**run.spec), effective_plan, run.backend)
        run.trace.append({"agent": "approval_gate", "action": "applied_edits",
                          "output": {"changes": change_log}})

    run.decision = {"approved": True, "reviewer": reviewer, "edits": edits or {},
                    "change_log": change_log}
    run.state = RunState.APPROVED
    run.trace.append({"agent": "approval_gate", "action": "approved",
                      "output": {"reviewer": reviewer}})

    if not effective_plan["steps"]:
        run.state = RunState.COMPLETED
        run.result = {"final_summary": "No steps remained after reviewer edits.",
                      "agents_created": [], "step_results": {}, "handoffs": []}
        return run.to_dict()

    plan_obj = Plan(
        complexity=effective_plan["complexity"],
        summary=effective_plan["summary"],
        steps=[PlanStep(**s) for s in effective_plan["steps"]],
    )

    backend_impl = get_backend(run.backend)
    try:
        run.state = RunState.DEPLOYING
        endpoints = backend_impl.deploy(run.manifest, run.trace)

        run.state = RunState.EXECUTING
        dispatcher = (
            LocalDispatcher() if backend_impl.name == "simulated"
            else HttpDispatcher(endpoints)
        )
        result = OrchestratorAgent().run(plan_obj, run.trace,
                                          dispatcher=dispatcher, endpoints=endpoints)

        run.result = result
        run.state = RunState.COMPLETED
    except Exception as exc:  # noqa: BLE001 - POC-level surface of any deploy/exec failure
        run.state = RunState.FAILED
        run.result = {"error": str(exc)}
        run.trace.append({"agent": "orchestrator_agent", "action": "run_failed",
                          "output": {"error": str(exc)}})
    finally:
        # agents are ephemeral: always release the lease / delete the pods
        try:
            backend_impl.teardown(run.manifest, run.trace)
        except Exception:  # noqa: BLE001
            pass

    return run.to_dict()


def get_run(run_id: str) -> Dict[str, Any]:
    run = STORE.get(run_id)
    return run.to_dict() if run else {"error": f"unknown run_id '{run_id}'"}
