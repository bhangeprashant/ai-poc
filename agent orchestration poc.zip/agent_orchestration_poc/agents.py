"""
Agent layer: understanding -> planner -> orchestrator -> dynamically
created executor agents, all communicating via HandoffEnvelope (A2A).

Design mirrors the request:
  1. UnderstandingAgent   - reads the user's query + their agent.md spec,
                             figures out intent & domain.
  2. PlannerAgent         - decides simple vs multi-agent, drafts steps,
                             assigns a role + toolset per step.
  3. OrchestratorAgent    - the handoff hub. Instantiates one ExecutorAgent
                             per role the plan calls for (this is the
                             "seamless custom agent creation" part -- the
                             role list is not hardcoded, it comes from the
                             plan, which comes from the user's own
                             agent.md), sequences them respecting
                             dependencies, and collects results.
  4. ExecutorAgent        - generic worker; specialized only by the role
                             name + tool subset it's handed at creation
                             time. This is what makes "jira agent",
                             "compliance agent", "git agent" all the same
                             class parameterized differently, rather than
                             N hardcoded classes.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from models import AgentSpec, HandoffEnvelope, HandoffType, Plan, PlanStep
from llm_client import complete_json
from tool_registry import list_tools, run_tool


# --------------------------------------------------------------------------
# 1. Understanding agent
# --------------------------------------------------------------------------

class UnderstandingAgent:
    name = "understanding_agent"

    def process(self, user_query: str, spec: AgentSpec, trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        system_prompt = (
            "You are an intent-understanding agent in a multi-agent orchestration "
            "system. Given a user's raw query and their custom agent spec, extract "
            "the domain, the underlying goal, and whether this looks like a simple "
            "single-step task or something that spans multiple concerns."
        )
        user_prompt = (
            f"User query: {user_query}\n\n"
            f"Agent spec name: {spec.name}\nRole: {spec.role}\nGoal: {spec.goal}\n"
            f"Requested tools: {spec.requested_tools}\nConstraints: {spec.constraints}\n"
            f"Notes: {spec.raw_notes}\n\n"
            "Return JSON: {\"domain\": str, \"intent\": str, \"looks_complex\": bool, "
            "\"key_entities\": [str]}"
        )

        def mock() -> Dict[str, Any]:
            lowered = f"{user_query} {spec.role} {spec.goal}".lower()
            domain = "general"
            for kw, d in [
                ("jira", "project-management"), ("ticket", "project-management"),
                ("compliance", "compliance"), ("policy", "compliance"),
                ("git", "engineering"), ("commit", "engineering"), ("code", "engineering"),
                ("audit", "compliance"),
            ]:
                if kw in lowered:
                    domain = d
                    break
            multi_signals = ["and", "then", "also", "as well as", "across"]
            looks_complex = sum(s in lowered for s in multi_signals) >= 1 or len(user_query.split()) > 25
            return {
                "domain": domain,
                "intent": user_query.strip()[:200],
                "looks_complex": looks_complex,
                "key_entities": [w for w in ["jira", "git", "compliance"] if w in lowered],
            }

        result = complete_json(system_prompt, user_prompt, mock)
        trace.append({
            "agent": self.name,
            "action": "understand_query",
            "output": result,
        })
        return result


# --------------------------------------------------------------------------
# 2. Planner agent
# --------------------------------------------------------------------------

class PlannerAgent:
    name = "planner_agent"

    def process(self, understanding: Dict[str, Any], spec: AgentSpec, trace: List[Dict[str, Any]]) -> Plan:
        available_tools = [t["name"] for t in list_tools()]
        system_prompt = (
            "You are a planning agent. Given the extracted intent and the tools "
            "available, decide whether this needs a single executor or a team of "
            "role-specialized agents handed off to one another, and draft concrete "
            "steps. Only use tool names from the provided list."
        )
        user_prompt = (
            f"Understanding: {understanding}\n"
            f"Requested tools from agent.md: {spec.requested_tools}\n"
            f"Available tools: {available_tools}\n\n"
            "Return JSON: {\"complexity\": \"simple\"|\"multi_agent\", \"summary\": str, "
            "\"steps\": [{\"step_id\": str, \"agent_role\": str, \"instruction\": str, "
            "\"tools\": [str], \"depends_on\": [str]}]}"
        )

        def mock() -> Dict[str, Any]:
            domain = understanding.get("domain", "general")
            entities = set(understanding.get("key_entities", []))
            requested = set(spec.requested_tools) & set(available_tools)

            role_tool_map = {
                "jira": ("jira_agent", "jira_tool"),
                "git": ("git_agent", "git_tool"),
                "compliance": ("compliance_agent", "compliance_tool"),
            }

            steps: List[Dict[str, Any]] = []
            active_entities = entities or ({"jira"} if domain == "project-management"
                                            else {"git"} if domain == "engineering"
                                            else {"compliance"} if domain == "compliance"
                                            else set())
            # callers upstream (e.g. the console) may pass entity names this
            # map doesn't cover -- drop unknowns rather than raising, and let
            # the no-entity branch below handle the empty case
            active_entities = {e for e in active_entities if e in role_tool_map}

            if not active_entities:
                steps.append({
                    "step_id": "step-1",
                    "agent_role": "general_research_agent",
                    "instruction": understanding.get("intent", ""),
                    "tools": list(requested) or ["knowledge_search_tool"],
                    "depends_on": [],
                })
            else:
                prev_id = None
                for i, ent in enumerate(sorted(active_entities), start=1):
                    role, tool = role_tool_map[ent]
                    step_id = f"step-{i}"
                    steps.append({
                        "step_id": step_id,
                        "agent_role": role,
                        "instruction": f"{understanding.get('intent', '')} (focus: {ent})",
                        "tools": [tool],
                        "depends_on": [prev_id] if (prev_id and understanding.get("looks_complex")) else [],
                    })
                    prev_id = step_id
                # always close out with a compliance pass in this BFSI setting
                if "compliance" not in active_entities:
                    steps.append({
                        "step_id": f"step-{len(steps)+1}",
                        "agent_role": "compliance_agent",
                        "instruction": "Run a policy/compliance check over the combined findings",
                        "tools": ["compliance_tool"],
                        "depends_on": [steps[-1]["step_id"]],
                    })

            # Honour tools the author requested in agent.md that no entity
            # mapped to (e.g. execution_harness_tool). Without this they'd be
            # silently dropped -- and, worse, never surface in the risk
            # assessment the human approves against.
            already_granted = {t for s in steps for t in s["tools"]}
            unmapped = [t for t in spec.requested_tools
                        if t in available_tools and t not in already_granted]
            if unmapped:
                role_for_tool = {
                    "execution_harness_tool": "execution_agent",
                    "knowledge_search_tool": "research_agent",
                }
                for tool in unmapped:
                    role = role_for_tool.get(tool, "general_research_agent")
                    existing = next((s for s in steps if s["agent_role"] == role), None)
                    if existing:
                        existing["tools"] = sorted(set(existing["tools"]) | {tool})
                        continue
                    steps.append({
                        "step_id": f"step-{len(steps)+1}",
                        "agent_role": role,
                        "instruction": f"{understanding.get('intent', '')} (using {tool})",
                        "tools": [tool],
                        "depends_on": [steps[-1]["step_id"]] if steps else [],
                    })

            complexity = "multi_agent" if len(steps) > 1 or understanding.get("looks_complex") else "simple"
            return {
                "complexity": complexity,
                "summary": f"Plan for domain '{domain}' with {len(steps)} step(s)",
                "steps": steps,
            }

        result = complete_json(system_prompt, user_prompt, mock)
        plan = Plan(
            complexity=result.get("complexity", "simple"),
            summary=result.get("summary", ""),
            steps=[PlanStep(**s) for s in result.get("steps", [])],
        )
        trace.append({
            "agent": self.name,
            "action": "draft_plan",
            "output": {
                "complexity": plan.complexity,
                "summary": plan.summary,
                "steps": [s.__dict__ for s in plan.steps],
            },
        })
        return plan


# --------------------------------------------------------------------------
# 4. Executor agent (dynamically created, parameterized by role)
# --------------------------------------------------------------------------

class ExecutorAgent:
    """A generic worker agent. Its "identity" (jira_agent, compliance_agent,
    git_agent, ...) comes entirely from the role name and tool subset it's
    instantiated with -- this is the dynamic-agent-creation mechanism.
    """

    def __init__(self, role: str, tools: List[str]):
        self.role = role
        self.tools = tools
        self.instance_id = f"{role}-{uuid.uuid4().hex[:6]}"

    def run_step(self, step: PlanStep, upstream_results: Dict[str, Any],
                 trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        tool_outputs = []
        for tool_name in step.tools:
            params = {"query": step.instruction, "action": "search"}
            output = run_tool(tool_name, params)
            tool_outputs.append({"tool": tool_name, "output": output})

        system_prompt = (
            f"You are '{self.role}', a specialized agent spun up for this run. "
            f"Synthesize a short result for your assigned step using the tool outputs "
            f"and any upstream results handed to you."
        )
        user_prompt = (
            f"Instruction: {step.instruction}\nTool outputs: {tool_outputs}\n"
            f"Upstream results: {upstream_results}\n\n"
            "Return JSON: {\"summary\": str, \"confidence\": float}"
        )

        def mock() -> Dict[str, Any]:
            return {
                "summary": f"[{self.role}] completed '{step.instruction}' using {step.tools}; "
                           f"{len(tool_outputs)} tool call(s) made.",
                "confidence": 0.78,
            }

        synthesis = complete_json(system_prompt, user_prompt, mock)
        result = {
            "step_id": step.step_id,
            "role": self.role,
            "instance_id": self.instance_id,
            "tool_outputs": tool_outputs,
            "synthesis": synthesis,
        }
        trace.append({
            "agent": self.instance_id,
            "action": "execute_step",
            "step_id": step.step_id,
            "output": result,
        })
        return result


# --------------------------------------------------------------------------
# Dispatchers - the seam between "agent runs here" and "agent runs in a pod"
# --------------------------------------------------------------------------

class LocalDispatcher:
    """Runs each step in-process. Used with the simulated backend."""

    def __init__(self) -> None:
        self._pool: Dict[str, ExecutorAgent] = {}

    def bind(self, role: str, tools: List[str], endpoint_info: Dict[str, Any]) -> str:
        agent = ExecutorAgent(role=role, tools=tools)
        if endpoint_info.get("instance_id"):
            agent.instance_id = endpoint_info["instance_id"]
        self._pool[role] = agent
        return agent.instance_id

    def dispatch(self, step: PlanStep, upstream: Dict[str, Any],
                 trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        return self._pool[step.agent_role].run_step(step, upstream, trace)


class HttpDispatcher:
    """Calls the deployed agent-runtime pod over HTTP.

    Used with the warm_pool and kubernetes backends. The handoff envelope
    the orchestrator builds is identical either way -- only this transport
    differs, which is the whole point of keeping the seam here.
    """

    def __init__(self, endpoints: Dict[str, Dict[str, Any]]) -> None:
        self.endpoints = endpoints
        self._instance_ids: Dict[str, str] = {}

    def bind(self, role: str, tools: List[str], endpoint_info: Dict[str, Any]) -> str:
        instance_id = endpoint_info.get("instance_id", f"{role}-remote")
        self._instance_ids[role] = instance_id
        return instance_id

    def dispatch(self, step: PlanStep, upstream: Dict[str, Any],
                 trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        import json as _json
        import urllib.request

        base_url = self.endpoints[step.agent_role]["endpoint"]
        payload = _json.dumps({
            "step_id": step.step_id,
            "instruction": step.instruction,
            "tools": step.tools,
            "depends_on": step.depends_on,
            "upstream_results": upstream,
        }).encode()

        req = urllib.request.Request(
            f"{base_url}/execute", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                body = _json.loads(resp.read())
        except Exception as exc:  # noqa: BLE001 - one bad pod shouldn't kill the run
            trace.append({"agent": "orchestrator_agent", "action": "dispatch_failed",
                          "output": {"role": step.agent_role, "error": str(exc)}})
            return {"step_id": step.step_id, "role": step.agent_role,
                    "instance_id": self._instance_ids.get(step.agent_role, "unknown"),
                    "error": str(exc), "synthesis": {"summary": f"dispatch failed: {exc}",
                                                      "confidence": 0.0}}

        trace.extend(body.get("trace", []))
        return body["result"]


# --------------------------------------------------------------------------
# 3. Orchestrator agent - the handoff hub
# --------------------------------------------------------------------------

class OrchestratorAgent:
    name = "orchestrator_agent"

    def run(self, plan: Plan, trace: List[Dict[str, Any]],
            dispatcher: Any = None,
            endpoints: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
        trace_id = uuid.uuid4().hex[:12]
        handoffs: List[Dict[str, Any]] = []
        dispatcher = dispatcher or LocalDispatcher()
        endpoints = endpoints or {}

        # Bind one agent per required role -- this is the "seamless agent
        # creation" step. Nothing about jira_agent / compliance_agent /
        # git_agent is a hardcoded class; each is the generic runtime
        # parameterized by role + tool grant from the approved plan.
        pool: Dict[str, str] = {}
        role_tools: Dict[str, List[str]] = {}
        for step in plan.steps:
            if step.agent_role not in pool:
                instance_id = dispatcher.bind(
                    step.agent_role, step.tools, endpoints.get(step.agent_role, {})
                )
                pool[step.agent_role] = instance_id
                role_tools[step.agent_role] = step.tools
                trace.append({
                    "agent": self.name,
                    "action": "spawn_agent",
                    "output": {
                        "role": step.agent_role,
                        "instance_id": instance_id,
                        "tools": step.tools,
                        "endpoint": endpoints.get(step.agent_role, {}).get("endpoint", "in-process"),
                    },
                })

        results: Dict[str, Any] = {}
        remaining = list(plan.steps)
        # naive dependency-respecting sequential scheduler; fine for a POC,
        # swap for real async/parallel scheduling once steps are independent
        # in practice (see README "productionizing" notes).
        while remaining:
            progressed = False
            for step in list(remaining):
                if all(dep in results for dep in step.depends_on):
                    envelope = HandoffEnvelope(
                        trace_id=trace_id,
                        from_agent=self.name,
                        to_agent=pool[step.agent_role],
                        type=HandoffType.TASK,
                        payload={"step_id": step.step_id, "instruction": step.instruction},
                    )
                    handoffs.append(envelope.to_dict())

                    upstream = {dep: results[dep] for dep in step.depends_on}
                    step_result = dispatcher.dispatch(step, upstream, trace)
                    results[step.step_id] = step_result

                    result_envelope = HandoffEnvelope(
                        trace_id=trace_id,
                        from_agent=pool[step.agent_role],
                        to_agent=self.name,
                        type=HandoffType.RESULT if "error" not in step_result else HandoffType.ERROR,
                        payload=step_result,
                    )
                    handoffs.append(result_envelope.to_dict())

                    remaining.remove(step)
                    progressed = True
            if not progressed:
                # circular / unmet dependency guard for the POC
                for step in remaining:
                    results[step.step_id] = {"error": "unmet dependency", "step_id": step.step_id}
                break

        final_summary = " | ".join(
            r.get("synthesis", {}).get("summary", "") for r in results.values() if isinstance(r, dict) and "synthesis" in r
        )
        trace.append({
            "agent": self.name,
            "action": "synthesize_final",
            "output": {"final_summary": final_summary},
        })

        return {
            "trace_id": trace_id,
            "handoffs": handoffs,
            "step_results": results,
            "final_summary": final_summary,
            "agents_created": [
                {
                    "role": role,
                    "instance_id": instance_id,
                    "tools": role_tools.get(role, []),
                    "endpoint": endpoints.get(role, {}).get("endpoint", "in-process"),
                }
                for role, instance_id in pool.items()
            ],
        }
