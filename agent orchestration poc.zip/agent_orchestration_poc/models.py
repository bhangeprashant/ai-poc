"""
Core data models for the dynamic multi-agent orchestration POC.

These are the shapes that flow across the whole pipeline:
  AgentSpec        -> parsed from a user-supplied agent.md
  ToolDefinition    -> an entry in the tool/skill registry
  HandoffEnvelope   -> the agent-to-agent (A2A) message format
  PlanStep / Plan   -> output of the planner agent
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


# --------------------------------------------------------------------------
# agent.md spec
# --------------------------------------------------------------------------

@dataclass
class AgentSpec:
    """Parsed representation of a user-supplied agent.md file.

    Real agent.md files are free-form markdown. For the POC we support a
    lightweight convention:

        # <agent name>
        role: <one line role/persona>
        goal: <one line objective>
        tools: tool_a, tool_b, tool_c
        constraints:
        - constraint 1
        - constraint 2

    Anything that doesn't parse cleanly is kept in `raw_notes` and handed to
    the LLM as free text context, so a malformed/free-form agent.md still
    works -- it just leans more on the model and less on structured fields.
    """

    name: str = "unnamed-agent"
    role: str = ""
    goal: str = ""
    requested_tools: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    raw_notes: str = ""

    @staticmethod
    def parse(agent_md: str) -> "AgentSpec":
        spec = AgentSpec()
        if not agent_md or not agent_md.strip():
            return spec

        lines = agent_md.strip().splitlines()
        notes: List[str] = []
        in_constraints = False

        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue

            if stripped.startswith("# "):
                spec.name = stripped[2:].strip()
                continue

            lower = stripped.lower()
            if lower.startswith("role:"):
                spec.role = stripped.split(":", 1)[1].strip()
                in_constraints = False
                continue
            if lower.startswith("goal:"):
                spec.goal = stripped.split(":", 1)[1].strip()
                in_constraints = False
                continue
            if lower.startswith("tools:"):
                tools = stripped.split(":", 1)[1].strip()
                spec.requested_tools = [t.strip() for t in tools.split(",") if t.strip()]
                in_constraints = False
                continue
            if lower.startswith("constraints:"):
                in_constraints = True
                continue
            if in_constraints and stripped.startswith("-"):
                spec.constraints.append(stripped.lstrip("- ").strip())
                continue

            notes.append(stripped)

        spec.raw_notes = "\n".join(notes)
        return spec


# --------------------------------------------------------------------------
# Tool / skill registry entries
# --------------------------------------------------------------------------

@dataclass
class ToolDefinition:
    name: str
    description: str
    input_schema: Dict[str, str]
    handler: Callable[[Dict[str, Any]], Dict[str, Any]]
    tags: List[str] = field(default_factory=list)


# --------------------------------------------------------------------------
# Agent-to-agent handoff protocol
# --------------------------------------------------------------------------

class HandoffType(str, Enum):
    REQUEST = "request"      # user/orchestrator -> agent: "do this"
    PLAN = "plan"            # planner -> orchestrator: "here's the plan"
    TASK = "task"            # orchestrator -> executor: "run this step"
    RESULT = "result"        # executor -> orchestrator: "here's what I got"
    ERROR = "error"          # any agent -> orchestrator: "I failed"
    FINAL = "final"          # orchestrator -> caller: "final synthesized answer"


@dataclass
class HandoffEnvelope:
    """The unit of agent-to-agent communication (A2A protocol, simplified).

    In a real AWS deployment this envelope is what would travel over
    SQS / EventBridge / a Bedrock Agent action-group call instead of an
    in-process asyncio.Queue -- the shape stays the same, only the
    transport changes. See orchestrator_pipeline.py for where that seam is.
    """

    trace_id: str
    from_agent: str
    to_agent: str
    type: HandoffType
    payload: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    envelope_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "envelope_id": self.envelope_id,
            "trace_id": self.trace_id,
            "from": self.from_agent,
            "to": self.to_agent,
            "type": self.type.value,
            "payload": self.payload,
            "timestamp": self.timestamp,
        }


# --------------------------------------------------------------------------
# Planning
# --------------------------------------------------------------------------

@dataclass
class PlanStep:
    step_id: str
    agent_role: str            # e.g. "jira_agent", "compliance_agent", "git_agent"
    instruction: str
    tools: List[str]
    depends_on: List[str] = field(default_factory=list)


@dataclass
class Plan:
    complexity: str            # "simple" | "multi_agent"
    summary: str
    steps: List[PlanStep] = field(default_factory=list)

    def required_roles(self) -> List[str]:
        seen = []
        for s in self.steps:
            if s.agent_role not in seen:
                seen.append(s.agent_role)
        return seen
