"""
Console API — the chat landing page backend.

Run:  uvicorn console_api:app --reload --port 8080
Open: http://localhost:8080

Endpoints
  GET    /api/bootstrap                     personas, models, tools, connectors, templates
  GET    /api/conversations                 sidebar list
  POST   /api/conversations                 start a new one
  GET    /api/conversations/{cid}           full history + artifacts
  DELETE /api/conversations/{cid}           remove
  PATCH  /api/conversations/{cid}           rename
  POST   /api/chat                          run a turn
  POST   /api/conversations/{cid}/upload    attach context
  POST   /api/conversations/{cid}/memory    pin a fact
  GET    /api/artifacts/{cid}/{aid}         download a generated document
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from console_core import (
    PERSONAS, MODEL_CATALOG, CONNECTORS, TEMPLATES, CONVERSATIONS,
)
from speech import transcribe, backend_status, STTUnavailable
from chat_pipeline import run_turn
from tool_registry import list_tools
from approvals import TOOL_RISK

app = FastAPI(title="Agent Console")


class ChatRequest(BaseModel):
    query: str
    conversation_id: Optional[str] = None
    persona: str = "generalist"
    model: str = "balanced"


class NewConversationRequest(BaseModel):
    persona: str = "generalist"
    model: str = "balanced"


class RenameRequest(BaseModel):
    title: str


class MemoryRequest(BaseModel):
    fact: str


@app.get("/")
def index():
    return FileResponse("static/console.html")


@app.get("/api/bootstrap")
def bootstrap():
    tools = []
    for t in list_tools():
        sev = TOOL_RISK.get(t["name"], (None, ""))[0]
        tools.append({**t, "risk": sev.value if sev else "medium"})
    return {
        "personas": [
            {"id": p.id, "label": p.label, "blurb": p.blurb,
             "default_tools": p.default_tools, "suggested_prompts": p.suggested_prompts}
            for p in PERSONAS.values()
        ],
        "models": MODEL_CATALOG,
        "tools": tools,
        "connectors": CONNECTORS,
        "templates": TEMPLATES,
        "speech": backend_status(),
    }


@app.get("/api/conversations")
def list_conversations():
    return {"conversations": CONVERSATIONS.list()}


@app.post("/api/conversations")
def new_conversation(req: NewConversationRequest):
    conv = CONVERSATIONS.create(persona=req.persona, model=req.model)
    return conv.to_dict()


@app.get("/api/conversations/{cid}")
def get_conversation(cid: str):
    conv = CONVERSATIONS.get(cid)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    return conv.to_dict()


@app.delete("/api/conversations/{cid}")
def delete_conversation(cid: str):
    if not CONVERSATIONS.delete(cid):
        raise HTTPException(404, "Conversation not found")
    return {"deleted": cid}


@app.patch("/api/conversations/{cid}")
def rename_conversation(cid: str, req: RenameRequest):
    if not CONVERSATIONS.rename(cid, req.title):
        raise HTTPException(404, "Conversation not found")
    return {"conversation_id": cid, "title": req.title}


@app.post("/api/chat")
def chat(req: ChatRequest):
    if not req.query.strip():
        raise HTTPException(400, "Query is empty")
    return run_turn(req.conversation_id, req.query, req.persona, req.model)


MAX_UPLOAD_BYTES = 5 * 1024 * 1024
MAX_FILES_PER_CONVERSATION = 10


@app.post("/api/conversations/{cid}/upload")
async def upload_context(cid: str, file: UploadFile = File(...)):
    conv = CONVERSATIONS.get(cid)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    if len(conv.context_files) >= MAX_FILES_PER_CONVERSATION:
        raise HTTPException(
            400, f"This conversation already has {MAX_FILES_PER_CONVERSATION} files attached. "
                 "Start a new conversation to add more.")
    raw = await file.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            400, f"{file.filename} is {len(raw) // (1024*1024)}MB. The limit is "
                 f"{MAX_UPLOAD_BYTES // (1024*1024)}MB — attach a smaller excerpt.")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = f"<binary file, {len(raw)} bytes — text extraction not wired in this POC>"
    entry = {"name": file.filename, "size": len(raw), "excerpt": text[:2000]}
    conv.context_files.append(entry)
    return {"attached": entry["name"], "size": entry["size"],
            "context_files": [f["name"] for f in conv.context_files]}


@app.post("/api/conversations/{cid}/memory")
def pin_memory(cid: str, req: MemoryRequest):
    conv = CONVERSATIONS.get(cid)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    conv.memory.append(req.fact)
    return {"memory": conv.memory}


@app.post("/api/intake/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    """Browser-agnostic dictation: the client records with MediaRecorder and
    POSTs the blob here. Works in Chrome, Firefox, Safari 14.1+, and Edge."""
    raw = await file.read()
    try:
        return transcribe(raw, filename=file.filename or "audio.webm")
    except STTUnavailable as exc:
        raise HTTPException(503, str(exc))


@app.get("/api/artifacts/{cid}/{aid}", response_class=PlainTextResponse)
def get_artifact(cid: str, aid: str):
    conv = CONVERSATIONS.get(cid)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    for a in conv.artifacts:
        if a["artifact_id"] == aid:
            return PlainTextResponse(
                a["content"],
                headers={"Content-Disposition": f'attachment; filename="{aid}.md"'},
            )
    raise HTTPException(404, "Artifact not found")


app.mount("/static", StaticFiles(directory="static"), name="static")
