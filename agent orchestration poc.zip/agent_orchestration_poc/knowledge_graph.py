"""
Centralised hybrid knowledge graph for the farm.

Mirrors the retrieval stack already in use (semantic chunks in a vector
store + BM25, fused with RRF, over a code/dependency graph). This module
is the FARM-FACING interface to it: swap `_vector_score` and the node
loader for real ChromaDB / codegraph calls and the rest stands.

Why a farm needs this specifically -- three jobs no single agent has:

1. GRANT DERIVATION. With ~50 services and a growing tool registry, you
   cannot hand-author which tools each agent gets (PHASE_GRANTS in
   farm_speckit.py is hand-written, and that does not scale past a
   handful of phases). The graph knows which services a goal touches and
   which tools those services are wired to, so the minimum grant set is
   derivable rather than guessed.

2. BLAST RADIUS AS RISK. A static per-tool risk table says `git_tool` is
   medium always. But a git write to a leaf service with no dependents is
   not the same action as a git write to an auth service that 14 services
   depend on. The graph knows the difference. Risk should be a function
   of REACH, not just of tool identity -- this module computes that reach
   and the broker escalates on it.

3. CROSS-AGENT FINDINGS. In a farm, one agent discovering something
   should not leave every sibling to rediscover it. Findings land as
   graph nodes attributed to the run that produced them, so a later agent
   retrieves them like any other knowledge -- with provenance intact.

Retrieval is hybrid on purpose. Vector search alone misses exact
identifiers (service names, ticket IDs, error codes) that BM25 nails;
BM25 alone misses paraphrase. RRF fuses both without needing tuned
weights, which matters because nobody re-tunes weights as an estate
grows.
"""

from __future__ import annotations

import math
import re
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

RRF_K = 60          # standard RRF damping; rank position dominates, not raw score


# ------------------------------------------------------------------- model --

@dataclass
class Node:
    node_id: str
    kind: str                    # service | repo | spec | tool | finding | decision | agent
    name: str
    text: str = ""               # searchable body
    attrs: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)


@dataclass
class Edge:
    src: str
    dst: str
    rel: str                     # depends_on | implements | owns | uses_tool | produced_by | about
    attrs: Dict[str, Any] = field(default_factory=dict)


def _tokens(s: str) -> List[str]:
    return re.findall(r"[a-z0-9_\-]+", s.lower())


class KnowledgeGraph:
    """Graph + hybrid retrieval. Thread-safe for farm-wide concurrent use."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.nodes: Dict[str, Node] = {}
        self.out: Dict[str, List[Edge]] = defaultdict(list)
        self.inc: Dict[str, List[Edge]] = defaultdict(list)
        self._df: Dict[str, int] = defaultdict(int)      # document frequency for BM25
        self._doclen: Dict[str, int] = {}

    # ------------------------------------------------------------- mutation
    def add_node(self, node: Node) -> str:
        with self._lock:
            self.nodes[node.node_id] = node
            toks = _tokens(f"{node.name} {node.text}")
            self._doclen[node.node_id] = len(toks)
            for t in set(toks):
                self._df[t] += 1
        return node.node_id

    def add_edge(self, src: str, dst: str, rel: str, **attrs: Any) -> None:
        with self._lock:
            e = Edge(src, dst, rel, attrs)
            self.out[src].append(e)
            self.inc[dst].append(e)

    def record_finding(self, text: str, run_id: str, agent: str,
                       about: Optional[List[str]] = None) -> str:
        """A farm agent's discovery, retrievable by every other agent.

        Provenance is not optional: a finding with no run/agent attached is
        an unsourced claim, and a later agent has no way to judge it.
        """
        nid = f"finding:{run_id}:{int(time.time()*1000) % 100000}"
        self.add_node(Node(nid, "finding", f"finding by {agent}", text,
                           {"run_id": run_id, "agent": agent}))
        for target in (about or []):
            self.add_edge(nid, target, "about")
        return nid

    # ------------------------------------------------------------ retrieval
    def _bm25(self, query: str, candidates: Iterable[str],
              k1: float = 1.5, b: float = 0.75) -> List[Tuple[str, float]]:
        with self._lock:
            N = max(1, len(self.nodes))
            avgdl = (sum(self._doclen.values()) / N) if self._doclen else 1.0
            q = _tokens(query)
            scored: List[Tuple[str, float]] = []
            for nid in candidates:
                node = self.nodes.get(nid)
                if not node:
                    continue
                toks = _tokens(f"{node.name} {node.text}")
                if not toks:
                    continue
                tf = defaultdict(int)
                for t in toks:
                    tf[t] += 1
                dl = len(toks)
                s = 0.0
                for t in q:
                    if t not in tf:
                        continue
                    df = self._df.get(t, 0) or 1
                    idf = math.log(1 + (N - df + 0.5) / (df + 0.5))
                    s += idf * (tf[t] * (k1 + 1)) / (tf[t] + k1 * (1 - b + b * dl / avgdl))
                if s > 0:
                    scored.append((nid, s))
        scored.sort(key=lambda x: -x[1])
        return scored

    def _vector_score(self, query: str, candidates: Iterable[str]) -> List[Tuple[str, float]]:
        """Stand-in for the real embedding store (ChromaDB in the live stack).

        Token-overlap cosine is a deliberately weak proxy -- it is here so
        the FUSION path is exercised and testable without a model in the
        loop. Replace with a real embedding query; the RRF code below does
        not change.
        """
        q = set(_tokens(query))
        if not q:
            return []
        out: List[Tuple[str, float]] = []
        with self._lock:
            for nid in candidates:
                node = self.nodes.get(nid)
                if not node:
                    continue
                d = set(_tokens(f"{node.name} {node.text}"))
                if not d:
                    continue
                sim = len(q & d) / math.sqrt(len(q) * len(d))
                if sim > 0:
                    out.append((nid, sim))
        out.sort(key=lambda x: -x[1])
        return out

    def hybrid_search(self, query: str, kinds: Optional[List[str]] = None,
                      top_k: int = 8) -> List[Dict[str, Any]]:
        """BM25 + vector, fused with Reciprocal Rank Fusion.

        RRF over score-weighting: it needs no per-corpus tuning and is
        robust to the two retrievers producing scores on different scales,
        which they always do.
        """
        with self._lock:
            cands = [n for n, nd in self.nodes.items()
                     if not kinds or nd.kind in kinds]
        lex = self._bm25(query, cands)
        vec = self._vector_score(query, cands)

        ranks: Dict[str, float] = defaultdict(float)
        contrib: Dict[str, List[str]] = defaultdict(list)
        for rank, (nid, _) in enumerate(lex[:50]):
            ranks[nid] += 1.0 / (RRF_K + rank + 1)
            contrib[nid].append("bm25")
        for rank, (nid, _) in enumerate(vec[:50]):
            ranks[nid] += 1.0 / (RRF_K + rank + 1)
            contrib[nid].append("vector")

        fused = sorted(ranks.items(), key=lambda x: -x[1])[:top_k]
        lex_map = dict(lex)
        vec_map = dict(vec)
        return [{
            "node_id": nid,
            "kind": self.nodes[nid].kind,
            "name": self.nodes[nid].name,
            "text": self.nodes[nid].text[:300],
            "rrf_score": round(score, 5),
            # Raw component scores travel with the result on purpose. RRF is
            # rank-based, so it compresses very different relevance levels
            # into nearly identical fused scores -- taking top_k off the
            # fused score alone silently admits near-irrelevant hits. A
            # caller deciding something consequential (like which services a
            # goal touches) needs the raw signal to apply a floor.
            "bm25_score": round(lex_map.get(nid, 0.0), 4),
            "vector_score": round(vec_map.get(nid, 0.0), 4),
            "matched_by": contrib[nid],
            "attrs": self.nodes[nid].attrs,
        } for nid, score in fused]

    # ------------------------------------------------------------- traversal
    def neighbors(self, node_id: str, rel: Optional[str] = None,
                  direction: str = "out") -> List[str]:
        with self._lock:
            edges = self.out[node_id] if direction == "out" else self.inc[node_id]
            return [e.dst if direction == "out" else e.src
                    for e in edges if rel is None or e.rel == rel]

    def blast_radius(self, node_id: str, rel: str = "depends_on",
                     max_depth: int = 4) -> Dict[str, Any]:
        """Who breaks if this node changes.

        Walks INCOMING depends_on edges: if B depends_on A, changing A
        reaches B. Getting this direction backwards is the classic bug --
        it would report a leaf service as high-impact and an auth service
        as safe, which is exactly inverted.
        """
        seen: Set[str] = set()
        frontier = [node_id]
        by_depth: Dict[int, List[str]] = {}
        for depth in range(1, max_depth + 1):
            nxt: List[str] = []
            for n in frontier:
                for dep in self.neighbors(n, rel=rel, direction="in"):
                    if dep not in seen and dep != node_id:
                        seen.add(dep)
                        nxt.append(dep)
            if not nxt:
                break
            by_depth[depth] = nxt
            frontier = nxt
        with self._lock:
            names = [self.nodes[n].name for n in seen if n in self.nodes]
        return {"root": node_id, "reached": len(seen), "dependents": names,
                "by_depth": {d: len(v) for d, v in by_depth.items()}}

    def tools_for(self, node_ids: Iterable[str]) -> List[str]:
        """Which registry tools the given services/repos are wired to."""
        tools: Set[str] = set()
        for n in node_ids:
            for t in self.neighbors(n, rel="uses_tool", direction="out"):
                node = self.nodes.get(t)
                if node and node.kind == "tool":
                    tools.add(node.name)
        return sorted(tools)

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            by_kind: Dict[str, int] = defaultdict(int)
            for n in self.nodes.values():
                by_kind[n.kind] += 1
            edges = sum(len(v) for v in self.out.values())
        return {"nodes": len(self.nodes), "edges": edges, "by_kind": dict(by_kind)}


KG = KnowledgeGraph()


def seed_demo_estate(kg: KnowledgeGraph) -> None:
    """A small stand-in for the real ~50-service estate."""
    services = {
        "auth-svc": ("Java", "Authentication and session issuing for all customer-facing services",
                     ["knowledge_search_tool", "git_tool"]),
        "payments-api": ("Java", "Payment initiation, refunds, settlement callbacks",
                         ["jira_tool", "git_tool", "knowledge_search_tool"]),
        "ledger-svc": ("Scala", "Double-entry ledger and balance projections",
                       ["git_tool", "knowledge_search_tool"]),
        "notify-worker": ("Python", "Outbound email and SMS notification worker",
                          ["jira_tool", "knowledge_search_tool"]),
        "web-portal": ("Angular", "Customer web portal frontend",
                       ["git_tool", "execution_harness_tool", "knowledge_search_tool"]),
    }
    for name, (lang, desc, tools) in services.items():
        nid = f"service:{name}"
        kg.add_node(Node(nid, "service", name, desc, {"language": lang}))
        for t in tools:
            tid = f"tool:{t}"
            if tid not in kg.nodes:
                kg.add_node(Node(tid, "tool", t, f"registry tool {t}"))
            kg.add_edge(nid, tid, "uses_tool")

    # depends_on: src depends on dst
    deps = [("payments-api", "auth-svc"), ("payments-api", "ledger-svc"),
            ("notify-worker", "payments-api"), ("web-portal", "auth-svc"),
            ("web-portal", "payments-api"), ("ledger-svc", "auth-svc")]
    for a, b in deps:
        kg.add_edge(f"service:{a}", f"service:{b}", "depends_on")

    specs = {
        "spec:refund-flow": ("Refund flow specification",
                             "Customer-initiated refunds for settled payments, "
                             "including partial refunds and ledger reversal entries",
                             ["payments-api", "ledger-svc"]),
        "spec:login-mfa": ("MFA login specification",
                           "Multi-factor authentication step-up during login for high risk sessions",
                           ["auth-svc", "web-portal"]),
    }
    for sid, (name, text, impls) in specs.items():
        kg.add_node(Node(sid, "spec", name, text))
        for s in impls:
            kg.add_edge(sid, f"service:{s}", "implements")
