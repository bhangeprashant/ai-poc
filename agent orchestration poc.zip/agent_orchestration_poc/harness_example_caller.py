"""
Example: how another agent calls the Harness Orchestrator.

Run the harness first:
    uvicorn harness_api:app --port 8080
Then:
    python harness_example_caller.py
"""

from __future__ import annotations

from harness_client import HarnessClient, HarnessError

BASE = "http://127.0.0.1:8080"


def pattern_1_streaming() -> None:
    """Full control: react to each event as it arrives."""
    print("\n--- Pattern 1: streaming with manual checkpoint handling ---")
    hc = HarnessClient(BASE, caller="qa_agent")
    sid = hc.open_session(granted_tools=["jira_tool", "knowledge_search_tool"])

    # Seed what this caller already knows, so the harness doesn't re-derive it.
    hc.seed_memory(sid, "Release window is Friday 18:00 IST", kind="semantic")

    for ev in hc.run(sid, "Find open vendor risk tickets and summarise them"):
        t, d = ev["type"], ev["data"]
        if t == "plan.drafted":
            print("  plan:", [s["tool"] or s["action"] for s in d["steps"]])
        elif t == "approval.requested":
            # Caller decides. This is the whole point of the checkpoint.
            approve = d["severity"] in ("low", "medium")
            print(f"  approval for {d['tool']} ({d['severity']}) -> {approve}")
            hc.approve(sid, d["checkpoint_id"], approved=approve)
        elif t == "tool.completed":
            print(f"  {d['tool']} ok in {d['ms']}ms")
        elif t == "context.compacted":
            print(f"  compacted {d['compacted']} observations "
                  f"({d['before']}->{d['after']} chars)")
        elif t == "turn.completed":
            print("  verdict:", d["evaluation"]["verdict"])
            print("  answer:", d["answer"][:160].replace("\n", " "))
        elif t == "turn.failed":
            print("  failed:", d.get("detail"))


def pattern_2_policy() -> None:
    """Less code: hand the harness a policy and wait for the result."""
    print("\n--- Pattern 2: declarative approval policy ---")
    hc = HarnessClient(BASE, caller="release_agent")
    sid = hc.open_session(granted_tools=["jira_tool", "execution_harness_tool"])

    result = hc.run_with_policy(
        sid,
        "Check jira for the auth change, then run the verification script",
        # Never auto-approve high risk. Sandboxed code execution stays human.
        approve_when=lambda cp: cp["severity"] != "high",
    )
    ev = result.get("evaluation", {})
    print("  verdict:", ev.get("verdict"))
    print("  executed:", [c["tool"] for c in result.get("tool_calls", [])])
    print("  refused:", [r["tool"] for r in result.get("refusals", [])])


def pattern_3_oneshot() -> None:
    """Simplest: blocking call. Read-only tools only."""
    print("\n--- Pattern 3: blocking one-shot ---")
    hc = HarnessClient(BASE, caller="docs_agent")
    out = hc.invoke("What is our data retention window?",
                    granted_tools=["knowledge_search_tool"])
    print("  state:", out["state"])
    print("  answer:", out["result"]["answer"][:160].replace("\n", " "))

    print("\n  ...and the same call with a write tool is refused:")
    try:
        hc.invoke("Update the ticket", granted_tools=["git_tool"])
    except HarnessError as exc:
        print("  ", str(exc)[:150])


if __name__ == "__main__":
    for fn in (pattern_1_streaming, pattern_2_policy, pattern_3_oneshot):
        try:
            fn()
        except HarnessError as exc:
            print("harness error:", exc)
        except Exception as exc:  # noqa: BLE001
            print("error:", exc)
