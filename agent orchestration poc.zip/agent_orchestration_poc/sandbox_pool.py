"""
Sandbox pool manager — the VDI / Sauce-Labs-style execution layer.

Replaces "spin up a VDI, run the test, tear it down" with a pool of
long-lived sandbox pods (browser or code-exec) that agents lease on
demand, backed by an autoscaler driven by QUEUE DEPTH, not CPU.

Why queue depth and not CPU: a browser/VDI session's cost is dominated by
cold-start latency (seconds), not compute. By the time CPU crosses a
threshold, requests have already been waiting. Queue depth is a leading
indicator -- it rises the instant demand exceeds capacity, before any pod
is even under load.

Two tiers of scaling:

  WARM FLOOR (min_replicas)   Always running. Leased instantly. This is
                               what makes a burst feel free -- no cold
                               start on the fast path.
  REACTIVE BURST (up to max)  Scales from queue depth. New pods register
                               themselves into the pool on boot (same
                               self-registration idea as WarmPoolBackend
                               in deployment.py, generalized here to
                               sandbox/browser workers instead of agent
                               roles).

This module does the QUEUEING, LEASING, and SCALE DECISION. It does NOT
itself call the Kubernetes API by default -- see ScalingBackend. The
recommended production setup is:

  this manager  -->  exposes /v1/sandbox/metrics (Prometheus format)
  KEDA          -->  scrapes that metric, patches the Deployment's replica
                      count, including scale-to-zero off-hours
  new pod boots -->  calls POST /v1/sandbox/register to join the pool

That split keeps the scaling *policy* (KEDA's ScaledObject, editable by
platform team without a code change) separate from the pool's *mechanics*
(leasing, backpressure, session affinity), which live here.

A direct-scale backend (patching replicas from Python) is included for
teams not running KEDA, or for local/dev use.
"""

from __future__ import annotations

import math
import os
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Deque, Dict, List, Optional


class Backpressure(RuntimeError):
    """Raised when the pool cannot admit a request even after queueing.

    Refusing explicitly beats letting a caller hang indefinitely -- the
    same philosophy as the harness's approval timeout: an unbounded wait
    is a worse failure mode than a clear, immediate error.
    """


class ReplicaState(str, Enum):
    WARMING = "warming"      # registered, not yet ready
    READY = "ready"
    DRAINING = "draining"    # finishing current lease, then removable


@dataclass
class Replica:
    replica_id: str
    endpoint: str
    capacity: int                     # concurrent sessions this pod can host
    kind: str                         # "browser" | "code_exec" | "android_emulator" | "ios_simulator" | "real_device" | ...
    capabilities: Dict[str, str] = field(default_factory=dict)
    # e.g. {"platform": "android", "os_version": "14", "device_model": "Pixel8"}
    # or   {"platform": "ios", "os_version": "17.4", "device_model": "iPhone15Pro"}
    state: str = ReplicaState.READY.value
    leases: Dict[str, float] = field(default_factory=dict)   # lease_id -> started_at
    registered_at: float = field(default_factory=time.time)
    last_active_at: float = field(default_factory=time.time)

    @property
    def in_use(self) -> int:
        return len(self.leases)

    @property
    def free(self) -> int:
        return max(0, self.capacity - self.in_use)

    def matches(self, kind: str, requirements: Dict[str, str]) -> bool:
        if self.kind != kind:
            return False
        return all(self.capabilities.get(k) == v for k, v in requirements.items())


@dataclass
class Lease:
    lease_id: str
    replica_id: str
    endpoint: str
    session_id: str
    kind: str
    capabilities: Dict[str, str] = field(default_factory=dict)
    external: bool = False            # True if served by an overflow provider, not our own inventory
    granted_at: float = field(default_factory=time.time)


@dataclass
class QueuedRequest:
    request_id: str
    session_id: str
    kind: str
    requirements: Dict[str, str]
    enqueued_at: float
    event: threading.Event = field(default_factory=threading.Event)
    lease: Optional[Lease] = None
    error: Optional[str] = None


class ScalingBackend:
    """Pluggable. Default is metrics-only: the pool computes a desired
    replica count and exposes it, but does not act on it -- KEDA/HPA does.
    """

    def current_target(self) -> Optional[int]:
        return None

    def apply(self, desired: int) -> None:
        pass  # no-op: an external autoscaler (KEDA/HPA) reads /metrics instead


class DirectKubernetesBackend(ScalingBackend):
    """For teams not running KEDA: patch the Deployment's replica count
    directly from Python. Requires `kubernetes` and in-cluster or kubeconfig
    auth. Optional import -- only touched if this backend is selected.
    """

    def __init__(self, deployment: str, namespace: str = "default"):
        self.deployment = deployment
        self.namespace = namespace
        self._last_applied: Optional[int] = None

    def apply(self, desired: int) -> None:
        if desired == self._last_applied:
            return
        from kubernetes import client, config  # type: ignore
        try:
            config.load_incluster_config()
        except Exception:  # noqa: BLE001
            config.load_kube_config()
        apps = client.AppsV1Api()
        apps.patch_namespaced_deployment_scale(
            name=self.deployment, namespace=self.namespace,
            body={"spec": {"replicas": desired}},
        )
        self._last_applied = desired

    def current_target(self) -> Optional[int]:
        return self._last_applied


class SimulatedBackend(ScalingBackend):
    """For local dev / tests: tracks a target count with no real infra."""

    def __init__(self):
        self._target = 0

    def apply(self, desired: int) -> None:
        self._target = desired

    def current_target(self) -> Optional[int]:
        return self._target


class ExternalDeviceProvider:
    """Burst valve to a paid device cloud (BrowserStack, Sauce Labs, AWS
    Device Farm) for real-device requests your own rack can't serve.

    This is the answer to "you can't autoscale physical inventory": you
    don't -- you own a floor of your most-used device/OS combos, queue
    fairly for the rest, and overflow genuinely rare or peak-only
    combinations to a managed provider that already owns thousands of
    devices. Same pattern as cloud-bursting compute, applied to hardware
    you can't provision in real time.
    """

    def acquire(self, requirements: Dict[str, str], timeout_s: float) -> Optional[Lease]:
        raise NotImplementedError

    def release(self, lease: Lease) -> None:
        raise NotImplementedError


class SimulatedExternalDeviceCloud(ExternalDeviceProvider):
    """Stands in for a real BrowserStack/Sauce Labs/Device Farm integration
    in this environment. A real implementation calls that provider's
    session-creation API and returns a Lease pointing at the WebDriver/
    Appium endpoint it hands back."""

    def __init__(self, name: str = "external-device-cloud"):
        self.name = name
        self._active: Dict[str, Dict[str, str]] = {}

    def acquire(self, requirements: Dict[str, str], timeout_s: float) -> Optional[Lease]:
        lid = "ext_" + uuid.uuid4().hex[:10]
        self._active[lid] = requirements
        return Lease(lease_id=lid, replica_id=self.name,
                     endpoint=f"https://{self.name}/session/{lid}",
                     session_id="", kind="real_device",
                     capabilities=requirements, external=True)

    def release(self, lease: Lease) -> None:
        self._active.pop(lease.lease_id, None)


class SandboxPoolManager:
    def __init__(self,
                min_replicas: int = 2,
                max_replicas: int = 20,
                target_utilization: float = 0.75,
                max_queue: int = 100,
                queue_timeout_s: float = 45.0,
                idle_evict_after_s: float = 300.0,
                scale_up_cooldown_s: float = 15.0,
                scale_down_cooldown_s: float = 90.0,
                backend: Optional[ScalingBackend] = None,
                elastic: bool = True,
                overflow_provider: Optional[ExternalDeviceProvider] = None):
        self.min_replicas = min_replicas
        self.max_replicas = max_replicas
        self.target_utilization = target_utilization
        self.max_queue = max_queue
        self.queue_timeout_s = queue_timeout_s
        self.idle_evict_after_s = idle_evict_after_s
        self.scale_up_cooldown_s = scale_up_cooldown_s
        self.scale_down_cooldown_s = scale_down_cooldown_s
        self.backend = backend or SimulatedBackend()
        # ELASTIC pools (browsers, Android emulators, iOS simulators) can be
        # scaled by creating more pods. FIXED pools (real devices) cannot --
        # max_replicas here means "physical units we own", set by procurement,
        # not by an autoscaler. See _tick(): a fixed pool never asks the
        # backend to scale beyond what's actually registered.
        self.elastic = elastic
        self.overflow_provider = overflow_provider

        self._lock = threading.Lock()
        self._replicas: Dict[str, Replica] = {}
        self._queue: Deque[QueuedRequest] = deque()
        self._last_scale_up = 0.0
        self._last_scale_down = 0.0
        self._admitted_total = 0
        self._rejected_total = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="sandbox-pool-autoscaler")
        self._thread.start()

    # --------------------------------------------------- replica lifecycle
    def register(self, endpoint: str, capacity: int = 1,
                kind: str = "browser", capabilities: Optional[Dict[str, str]] = None) -> str:
        """A newly-scaled-up pod calls this on boot to join the pool.
        For a fixed (real-device) pool, this is what happens when a device
        is physically racked and its host agent comes online -- not a
        scale-up event, just inventory joining."""
        rid = "rep_" + uuid.uuid4().hex[:10]
        with self._lock:
            self._replicas[rid] = Replica(replica_id=rid, endpoint=endpoint,
                                          capacity=capacity, kind=kind,
                                          capabilities=capabilities or {})
        self._try_drain_queue()
        return rid

    def deregister(self, replica_id: str) -> bool:
        with self._lock:
            rep = self._replicas.get(replica_id)
            if not rep:
                return False
            if rep.in_use:
                rep.state = ReplicaState.DRAINING.value
                return True          # removed once its leases release
            del self._replicas[replica_id]
        return True

    # ------------------------------------------------------------- leasing
    def acquire(self, session_id: str, kind: str = "browser",
               timeout_s: Optional[float] = None,
               requirements: Optional[Dict[str, str]] = None) -> Lease:
        """`requirements` narrows within `kind` -- e.g. kind="real_device",
        requirements={"platform": "android", "device_model": "Pixel8",
        "os_version": "14"}. Unspecified keys are wildcards."""
        requirements = requirements or {}
        timeout_s = self.queue_timeout_s if timeout_s is None else timeout_s
        lease = self._try_acquire_now(session_id, kind, requirements)
        if lease:
            self._admitted_total += 1
            return lease

        with self._lock:
            if len(self._queue) >= self.max_queue:
                queue_full = True
            else:
                queue_full = False
                req = QueuedRequest(request_id="q_" + uuid.uuid4().hex[:10],
                                    session_id=session_id, kind=kind,
                                    requirements=requirements,
                                    enqueued_at=time.time())
                self._queue.append(req)

        if queue_full:
            # For a fixed pool (real devices), overflow to a paid device
            # cloud is the right response to "no capacity" -- there is no
            # local scale-up to wait for. For an elastic pool, overflowing
            # to a third party is usually not worth the cost; prefer to
            # surface backpressure so the autoscaler has a reason to act.
            if not self.elastic and self.overflow_provider:
                ext = self.overflow_provider.acquire(requirements, timeout_s)
                if ext:
                    self._admitted_total += 1
                    return ext
            self._rejected_total += 1
            raise Backpressure(
                f"Sandbox pool queue is full ({self.max_queue} waiting). "
                f"Capacity: {self._capacity_summary()}. Retry with backoff, "
                "or reduce concurrent sessions from this caller."
            )

        got = req.event.wait(timeout_s)
        with self._lock:
            if req in self._queue:
                self._queue.remove(req)
        if got and req.lease is not None:
            self._admitted_total += 1
            return req.lease

        if not self.elastic and self.overflow_provider:
            ext = self.overflow_provider.acquire(requirements, timeout_s=5.0)
            if ext:
                self._admitted_total += 1
                return ext

        self._rejected_total += 1
        raise Backpressure(
            f"No sandbox became available within {timeout_s:.0f}s. "
            f"Capacity: {self._capacity_summary()}. "
            + ("The pool may be scaling up -- retry shortly."
               if self.elastic else
               "This is fixed physical inventory; no overflow provider is "
               "configured, or it also had no matching device. Consider "
               "widening `requirements` or provisioning more of this "
               "device/OS combination.")
        )

    def _try_acquire_now(self, session_id: str, kind: str,
                         requirements: Optional[Dict[str, str]] = None) -> Optional[Lease]:
        with self._lock:
            return self._try_acquire_now_locked(session_id, kind, requirements or {})

    def _try_acquire_now_locked(self, session_id: str, kind: str,
                                requirements: Optional[Dict[str, str]] = None) -> Optional[Lease]:
        """Same as above but assumes the caller already holds self._lock --
        required so drain's pop-and-grant is one atomic step (see _try_drain_queue)."""
        requirements = requirements or {}
        for rep in self._replicas.values():
            if rep.state != ReplicaState.READY.value:
                continue
            if not rep.matches(kind, requirements):
                continue
            if rep.free > 0:
                lid = "lse_" + uuid.uuid4().hex[:10]
                rep.leases[lid] = time.time()
                rep.last_active_at = time.time()
                return Lease(lease_id=lid, replica_id=rep.replica_id,
                            endpoint=rep.endpoint, session_id=session_id,
                            kind=kind, capabilities=rep.capabilities)
        return None

    def release(self, lease: Lease) -> None:
        if lease.external:
            if self.overflow_provider:
                self.overflow_provider.release(lease)
            return
        with self._lock:
            rep = self._replicas.get(lease.replica_id)
            if rep and lease.lease_id in rep.leases:
                del rep.leases[lease.lease_id]
                rep.last_active_at = time.time()
                if rep.state == ReplicaState.DRAINING.value and rep.in_use == 0:
                    del self._replicas[lease.replica_id]
        self._try_drain_queue()

    def _try_drain_queue(self) -> None:
        # Best-effort: hand out freed/new capacity to the longest-waiting
        # requests first, so bursts resolve in arrival order.
        #
        # BUG THIS FIXES: granting a lease without popping the request left
        # it at queue[0] for the next loop iteration. If capacity remained,
        # the same already-satisfied request got a SECOND, orphaned lease --
        # nobody would ever release it -- while every other queued request
        # starved behind it. The pop must happen atomically with the grant,
        # under the same lock, or a concurrent acquire() removing itself
        # (see below) can race with this loop over the same entry.
        #
        # Requirements-aware: a request for a specific device model must not
        # be skipped just because SOME capacity freed up -- only grant when
        # a replica matching ITS requirements is free. We scan the queue in
        # order but may skip past a request whose device isn't free yet to
        # satisfy one behind it that can be served now (head-of-line
        # blocking on a single scarce SKU would otherwise stall everyone).
        while True:
            with self._lock:
                if not self._queue:
                    return
                granted = False
                for req in list(self._queue):
                    lease = self._try_acquire_now_locked(req.session_id, req.kind,
                                                          req.requirements)
                    if lease:
                        self._queue.remove(req)
                        granted = True
                        break
                if not granted:
                    return
            req.lease = lease
            req.event.set()

    def lease_ctx(self, session_id: str, kind: str = "browser",
                 timeout_s: Optional[float] = None):
        """`with pool.lease_ctx(session_id) as lease: ...` -- auto-releases."""
        return _LeaseContext(self, session_id, kind, timeout_s)

    # -------------------------------------------------------------- scaling
    def _capacity_summary(self) -> str:
        with self._lock:
            total = sum(r.capacity for r in self._replicas.values())
            used = sum(r.in_use for r in self._replicas.values())
        return f"{used}/{total} sessions in use, {len(self._queue)} queued"

    def _desired_replicas(self) -> int:
        with self._lock:
            in_use = sum(r.in_use for r in self._replicas.values())
            queued = len(self._queue)
            current = len(self._replicas)
            capacity_per_replica = (
                sum(r.capacity for r in self._replicas.values()) / len(self._replicas)
                if self._replicas else 1
            )
        if not self.elastic:
            # Fixed inventory: "desired" is a capacity-planning signal, not
            # an instruction anyone can act on automatically. Report demand
            # honestly (may exceed what's physically racked) but never
            # suggest scaling past max_replicas, which here means "units we
            # own", not a ceiling a scaler is free to approach.
            demand = in_use + queued
            return min(current, self.max_replicas) if demand <= current else current
        demand = in_use + queued
        # Target utilization headroom: don't run pods pinned at 100% --
        # leave slack so a burst doesn't immediately overflow into the queue.
        raw = math.ceil(demand / max(capacity_per_replica * self.target_utilization, 0.1))
        return max(self.min_replicas, min(self.max_replicas, raw))

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception:  # noqa: BLE001
                pass
            self._stop.wait(5.0)

    def _tick(self) -> None:
        if not self.elastic:
            # Nothing to autoscale -- physical inventory changes by
            # procurement, not by this loop. Still run idle bookkeeping
            # so devices that crash/disconnect eventually age out if their
            # host process deregisters them; otherwise there is genuinely
            # nothing for this tick to do.
            return
        desired = self._desired_replicas()
        now = time.time()
        with self._lock:
            current = len(self._replicas)

        if desired > current and (now - self._last_scale_up) > self.scale_up_cooldown_s:
            self.backend.apply(desired)
            self._last_scale_up = now
        elif desired < current and (now - self._last_scale_down) > self.scale_down_cooldown_s:
            # Only evict replicas that are actually idle -- never a busy one.
            with self._lock:
                idle = sorted(
                    [r for r in self._replicas.values()
                     if r.in_use == 0 and now - r.last_active_at > self.idle_evict_after_s
                     and r.state == ReplicaState.READY.value],
                    key=lambda r: r.last_active_at,
                )
                to_remove = max(0, current - desired)
                for r in idle[:to_remove]:
                    del self._replicas[r.replica_id]
            self.backend.apply(desired)
            self._last_scale_down = now

    def status(self) -> Dict[str, Any]:
        with self._lock:
            reps = list(self._replicas.values())
            queue_len = len(self._queue)
            oldest_wait = (time.time() - self._queue[0].enqueued_at) if self._queue else 0.0
            unmet_requirements = [dict(r.requirements) for r in self._queue]
        total_cap = sum(r.capacity for r in reps)
        in_use = sum(r.in_use for r in reps)
        out = {
            "elastic": self.elastic,
            "replicas": len(reps),
            "min_replicas": self.min_replicas,
            "max_replicas": self.max_replicas,
            "desired_replicas": self._desired_replicas(),
            "total_capacity": total_cap,
            "in_use": in_use,
            "utilization": round(in_use / total_cap, 3) if total_cap else 0.0,
            "queue_depth": queue_len,
            "oldest_queued_wait_s": round(oldest_wait, 1),
            "admitted_total": self._admitted_total,
            "rejected_total": self._rejected_total,
            "backend_target": self.backend.current_target(),
        }
        if not self.elastic:
            # For a fixed pool, a queue that never clears is a procurement
            # signal, not an autoscaling one -- surface exactly what's
            # unmet so someone can act on it.
            out["overflow_provider_configured"] = self.overflow_provider is not None
            out["unmet_requirements_sample"] = unmet_requirements[:10]
        return out

    def metrics_prometheus(self) -> str:
        """Text-format metrics for a KEDA Prometheus trigger or an HPA
        custom-metrics adapter to scrape. This -- not this process calling
        the Kubernetes API -- is the recommended path to real autoscaling.
        """
        s = self.status()
        lines = [
            "# HELP sandbox_pool_queue_depth Requests waiting for a sandbox lease",
            "# TYPE sandbox_pool_queue_depth gauge",
            f"sandbox_pool_queue_depth {s['queue_depth']}",
            "# HELP sandbox_pool_utilization Fraction of leased capacity in use",
            "# TYPE sandbox_pool_utilization gauge",
            f"sandbox_pool_utilization {s['utilization']}",
            "# HELP sandbox_pool_desired_replicas Manager's computed target replica count",
            "# TYPE sandbox_pool_desired_replicas gauge",
            f"sandbox_pool_desired_replicas {s['desired_replicas']}",
            "# HELP sandbox_pool_oldest_queued_wait_seconds Longest current queue wait",
            "# TYPE sandbox_pool_oldest_queued_wait_seconds gauge",
            f"sandbox_pool_oldest_queued_wait_seconds {s['oldest_queued_wait_s']}",
            "# HELP sandbox_pool_rejected_total Requests refused due to backpressure",
            "# TYPE sandbox_pool_rejected_total counter",
            f"sandbox_pool_rejected_total {s['rejected_total']}",
        ]
        return "\n".join(lines) + "\n"

    def shutdown(self) -> None:
        self._stop.set()


class _LeaseContext:
    def __init__(self, pool: SandboxPoolManager, session_id: str, kind: str,
                timeout_s: Optional[float]):
        self.pool, self.session_id, self.kind, self.timeout_s = pool, session_id, kind, timeout_s
        self.lease: Optional[Lease] = None

    def __enter__(self) -> Lease:
        self.lease = self.pool.acquire(self.session_id, self.kind, self.timeout_s)
        return self.lease

    def __exit__(self, *exc) -> None:
        if self.lease:
            self.pool.release(self.lease)


# Default pool for the process. Sized for browser/VDI-style 1-session-per-pod
# isolation; a code-exec pool would use higher capacity_per_replica.
POOL = SandboxPoolManager(
    min_replicas=int(os.environ.get("SANDBOX_MIN_REPLICAS", "2")),
    max_replicas=int(os.environ.get("SANDBOX_MAX_REPLICAS", "20")),
    target_utilization=float(os.environ.get("SANDBOX_TARGET_UTIL", "0.75")),
)
