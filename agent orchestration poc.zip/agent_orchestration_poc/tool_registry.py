"""
Tool / skill registry.

This is the "skills list" agents pick from during planning and execution.
Each tool is a mock handler for the POC -- swap `handler` for a real call
(Jira REST API, git CLI, your execution harness, a RAG lookup, etc.) to move
this from POC to production. The registry itself (name -> ToolDefinition)
is exactly the surface a real MCP server / tool-use API would expose.
"""

from __future__ import annotations

import random
from typing import Any, Dict, List, Optional

from models import ToolDefinition


def _jira_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    action = params.get("action", "search")
    query = params.get("query", "")
    return {
        "action": action,
        "query": query,
        "results": [
            {"key": "PROJ-101", "summary": f"Ticket related to: {query}", "status": "In Progress"},
            {"key": "PROJ-142", "summary": f"Follow-up on: {query}", "status": "Backlog"},
        ],
    }


def _git_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    action = params.get("action", "search_commits")
    query = params.get("query", "")
    return {
        "action": action,
        "query": query,
        "results": [
            {"sha": "a1b2c3d", "message": f"fix: {query}", "author": "svc-agent"},
        ],
    }


def _compliance_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    query = params.get("query", "")
    flagged = random.choice([True, False])
    return {
        "query": query,
        "policy_check": "BFSI-data-handling-v3",
        "flagged": flagged,
        "notes": "Potential PII exposure in output" if flagged else "No policy violations detected",
    }


def _knowledge_search_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    query = params.get("query", "")
    return {
        "query": query,
        "hits": [
            {"source": "internal-kb", "snippet": f"Relevant context for '{query}'", "score": 0.82},
        ],
    }


def _execution_harness_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    """Leases a real sandbox from the pool for the run, then releases it --
    replaces a dedicated VDI/Sauce-Labs-style checkout with an on-demand,
    autoscaled slot. See sandbox_pool.py."""
    code = params.get("code", "")
    language = params.get("language", "python")
    kind = params.get("kind", "code_exec")

    from sandbox_pool import POOL, Backpressure
    session_id = params.get("session_id", "adhoc")
    try:
        with POOL.lease_ctx(session_id, kind=kind, timeout_s=45) as lease:
            # Real dispatch would POST {code, language} to lease.endpoint's
            # /execute route (the same shape as agent_runtime.py's /execute).
            # Left simulated here since no real sandbox image is deployed
            # in this environment.
            return {
                "language": language,
                "submitted_chars": len(code),
                "sandbox": lease.endpoint,
                "lease_id": lease.lease_id,
                "stdout": "<simulated sandboxed execution output>",
                "exit_code": 0,
            }
    except Backpressure as exc:
        return {"error": "sandbox_pool_exhausted", "detail": str(exc)}




# ---------------------------------------------------------- security tools --

_VULN_FIXTURE = [
    {"id": "FTFY-1001", "rule": "SQL Injection", "cwe": "CWE-89", "severity": "critical",
     "file": "payments-api/src/main/java/repo/RefundRepository.java", "line": 142,
     "sink": "Statement.executeQuery", "source": "HttpServletRequest.getParameter",
     "scanner": "fortify", "confidence": "high",
     "snippet": "String q = \"SELECT * FROM refunds WHERE id='\" + req.getParameter(\"id\") + \"'\";"},
    {"id": "FTFY-1002", "rule": "Hardcoded Credential", "cwe": "CWE-798", "severity": "high",
     "file": "payments-api/src/test/java/repo/RefundRepositoryTest.java", "line": 31,
     "sink": "DriverManager.getConnection", "source": "literal",
     "scanner": "fortify", "confidence": "low",
     "snippet": 'String pw = "test-password-fixture";'},
    {"id": "FTFY-1003", "rule": "Cross-Site Scripting", "cwe": "CWE-79", "severity": "high",
     "file": "web-portal/src/app/refund/refund.component.html", "line": 18,
     "sink": "innerHTML", "source": "route.queryParams",
     "scanner": "fortify", "confidence": "high",
     "snippet": "<div [innerHTML]=\"refundNote\"></div>"},
    {"id": "SONA-2201", "rule": "Vulnerable Dependency", "cwe": "CWE-1395", "severity": "critical",
     "file": "ledger-svc/build.sbt", "line": 12,
     "component": "com.fasterxml.jackson.core:jackson-databind:2.9.8",
     "fixed_version": "2.15.4", "cve": "CVE-2020-36518",
     "scanner": "sonatype", "confidence": "high", "snippet": ""},
    {"id": "SONA-2202", "rule": "Vulnerable Dependency", "cwe": "CWE-1395", "severity": "medium",
     "file": "notify-worker/requirements-dev.txt", "line": 4,
     "component": "requests:2.19.1", "fixed_version": "2.32.0",
     "cve": "CVE-2023-32681", "scanner": "sonatype", "confidence": "low",
     "scope": "dev-only", "snippet": ""},
]


def _security_scanner_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    """Fortify SSC / Sonatype IQ style findings fetch.

    Swap for the real REST calls: Fortify SSC
    /api/v1/projectVersions/{id}/issues, Sonatype IQ
    /api/v2/applications/{app}/reports. Shape below mirrors what both
    return once normalised: a stable finding id, rule/CWE, location, and
    the scanner's own confidence -- which is the field triage depends on.
    """
    action = params.get("action", "fetch_findings")
    if action == "rescan":
        return {"action": "rescan", "scan_id": "scan_" + params.get("branch", "x")[:12],
                "status": "completed", "new_findings": 0,
                "resolved_findings": params.get("expect_resolved", []),
                "note": "Post-fix verification scan"}
    scanner = params.get("scanner")
    findings = [f for f in _VULN_FIXTURE if not scanner or f["scanner"] == scanner]
    return {"action": action, "scanner": scanner or "all",
            "count": len(findings), "findings": findings}


def _repo_read_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    """Clone and inspect only. Cannot publish anything.

    Split from publish so it can carry its own (low) risk tier: rating a
    clone at the same severity as a push meant every read-only repo action
    needed a human, which trains reviewers to rubber-stamp -- the worst
    possible outcome for a gate that also guards real pushes.
    """
    action = params.get("action", "clone")
    repo = params.get("repo", "unknown")
    if action == "clone":
        return {"action": "clone", "repo": repo, "path": f"/workspace/{repo}",
                "commit": "a1b2c3d", "status": "cloned"}
    if action == "status":
        return {"action": "status", "repo": repo, "dirty": True,
                "modified": params.get("files", [])}
    return {"action": action, "repo": repo, "status": "unsupported_read_action"}


def _repo_publish_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    """Branch / commit / push -- everything that mutates or publishes.

    Still one tool because these three are always used together and a
    partial application (commit with no branch) is worse than none.
    """
    action = params.get("action", "branch")
    repo = params.get("repo", "unknown")
    repo = params.get("repo", "unknown")
    if action == "branch":
        return {"action": "branch", "repo": repo,
                "branch": params.get("branch", "security/remediation"), "status": "created"}
    if action == "commit":
        return {"action": "commit", "repo": repo, "sha": "f9e8d7c",
                "files": params.get("files", []), "message": params.get("message", "")}
    if action == "push":
        return {"action": "push", "repo": repo, "branch": params.get("branch"),
                "remote": "origin", "status": "pushed"}
    return {"action": action, "repo": repo, "status": "unknown_action"}


def _test_runner_handler(params: Dict[str, Any]) -> Dict[str, Any]:
    """Runs the suite and returns a comparable result set.

    Returns per-test outcomes rather than a pass/fail summary on purpose:
    regression detection needs to diff against a pre-fix BASELINE, and a
    bare 'N passed' cannot tell you whether the same N passed.
    """
    suite = params.get("suite", "all")
    baseline = params.get("baseline_mode", False)
    finding = params.get("finding")

    tests = {
        "RefundRepositoryTest.testFindById": "pass",
        "RefundRepositoryTest.testPartialRefund": "pass",
        "RefundControllerTest.testRefundEndpoint": "pass",
        "LedgerReversalTest.testReversalEntry": "pass",
        "SerializationTest.testJacksonRoundTrip": "pass",
    }
    if not baseline:
        # Per-finding fault injection so isolation is actually observable:
        # the jackson-databind major bump (SONA-2201) breaks serialisation,
        # while the SQLi and XSS fixes are clean. Batch-level validation
        # would blame all three.
        if finding == "SONA-2201":
            tests["SerializationTest.testJacksonRoundTrip"] = "fail"
        elif finding is None:
            tests["SerializationTest.testJacksonRoundTrip"] = "fail"
    failed = [k for k, v in tests.items() if v == "fail"]
    return {"suite": suite, "baseline_mode": baseline, "total": len(tests),
            "passed": len(tests) - len(failed), "failed": failed, "results": tests}


REGISTRY: Dict[str, ToolDefinition] = {
    "jira_tool": ToolDefinition(
        name="jira_tool",
        description="Search, read, and comment on Jira tickets",
        input_schema={"action": "str", "query": "str"},
        handler=_jira_handler,
        tags=["jira", "tickets", "pm"],
    ),
    "git_tool": ToolDefinition(
        name="git_tool",
        description="Search commits, diffs, and PRs across the org's repos",
        input_schema={"action": "str", "query": "str"},
        handler=_git_handler,
        tags=["git", "code", "vcs"],
    ),
    "compliance_tool": ToolDefinition(
        name="compliance_tool",
        description="Run a BFSI compliance / policy check against a piece of content",
        input_schema={"query": "str"},
        handler=_compliance_handler,
        tags=["compliance", "governance", "bfsi"],
    ),
    "knowledge_search_tool": ToolDefinition(
        name="knowledge_search_tool",
        description="Semantic search over the enterprise knowledge base",
        input_schema={"query": "str"},
        handler=_knowledge_search_handler,
        tags=["rag", "search", "knowledge"],
    ),
    "execution_harness_tool": ToolDefinition(
        name="execution_harness_tool",
        description="Run a snippet of code in the sandboxed execution harness",
        input_schema={"code": "str", "language": "str"},
        handler=_execution_harness_handler,
        tags=["code-exec", "sandbox"],
    ),
    "security_scanner_tool": ToolDefinition(
        name="security_scanner_tool",
        description="Fetch SAST/SCA findings from Fortify SSC or Sonatype IQ, and trigger verification rescans.",
        input_schema={"action": "str", "scanner": "str"},
        handler=_security_scanner_handler,
        tags=["security", "sast", "sca", "read"],
    ),
    "repo_read_tool": ToolDefinition(
        name="repo_read_tool",
        description="Clone a repository and inspect working-tree status. Cannot publish.",
        input_schema={"action": "str", "repo": "str"},
        handler=_repo_read_handler,
        tags=["git", "read"],
    ),
    "repo_publish_tool": ToolDefinition(
        name="repo_publish_tool",
        description="Create a branch, commit changes, and push to the shared remote.",
        input_schema={"action": "str", "repo": "str", "branch": "str"},
        handler=_repo_publish_handler,
        tags=["git", "write", "irreversible"],
    ),
    "test_runner_tool": ToolDefinition(
        name="test_runner_tool",
        description="Run a test suite and return per-test outcomes for baseline comparison.",
        input_schema={"suite": "str", "baseline_mode": "bool"},
        handler=_test_runner_handler,
        tags=["test", "validation"],
    ),
}

def list_tools() -> List[Dict[str, Any]]:
    built_in = [
        {"name": t.name, "description": t.description, "tags": t.tags, "origin": "built_in"}
        for t in REGISTRY.values()
    ]
    from utility_registry import UTILITIES
    published = [
        {"name": u.name, "description": u.description, "tags": ["utility", u.source],
         "origin": u.source, "owner": u.owner, "trusted": u.trusted}
        for u in UTILITIES.all()
    ]
    return built_in + published


def get_tool(name: str) -> Optional[ToolDefinition]:
    return REGISTRY.get(name)


def is_known_tool(name: str) -> bool:
    """True for a built-in OR a published utility. get_tool() alone only
    covers built-ins -- checking it in isolation would wrongly reject every
    utility as 'unknown' before dispatch even reaches run_tool()."""
    if name in REGISTRY:
        return True
    from utility_registry import UTILITIES
    return UTILITIES.get(name) is not None


def run_tool(name: str, params: Dict[str, Any]) -> Dict[str, Any]:
    tool = get_tool(name)
    if tool is not None:
        return tool.handler(params)
    from utility_registry import UTILITIES
    if UTILITIES.get(name) is not None:
        return UTILITIES.execute(name, params)
    return {"error": f"unknown tool '{name}'"}
