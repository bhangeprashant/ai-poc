"""
Spec Kit in an agent farm — three patterns, run for real.

    python farm_speckit_demo.py

  A. Handoff-driven pipeline   -- spec-kit's own graph as farm routing
  B. Parallel independent critics -- analyze + checklist as separate agents
  C. Fan-out implementation    -- one plan, N repos, N agents
"""

from __future__ import annotations

import time
from typing import Any, Dict

from farm_core import aggregate
from farm_speckit import (
    SpecKitPipeline, parallel_critics, fan_out_implement, default_broker,
    load_handoff_graph, PHASE_GRANTS,
)
from harness_context import SKILLS


def hdr(t: str, why: str) -> None:
    print(f"\n{'='*72}\n{t}\n{'-'*72}\n{why}\n")


def pattern_a() -> Dict[str, Any]:
    hdr("A. Handoff-driven pipeline",
        "Spec-kit's own frontmatter says which phase-agent runs next and\n"
        "whether the edge is automatic. The farm follows that graph rather\n"
        "than a sequence we invented. Auto edges advance freely; gated edges\n"
        "stop for a decision — which is where spec-kit intends human steering.")

    broker = default_broker()
    pipe = SpecKitPipeline(broker, target="payments-api")
    steps = pipe.run_from("speckit.plan",
                          "Create the implementation plan for the payments refund flow")

    for s in steps:
        marker = {"entry": "  ", "auto": "==>", "gated": "-->"}.get(s.edge_type, "  ")
        print(f"   {marker} {s.phase:22} {s.state:10} verdict={s.verdict:9} grants={s.granted_tools}")

    gated = pipe.gated_edges_from("speckit.tasks")
    print(f"\n   Pipeline stopped before: {gated}")
    print("   (spec-kit marks tasks->implement non-automatic — a human decides")
    print("    whether a plan becomes code. The farm honours that.)")
    broker.shutdown()
    return {"steps": len(steps), "stopped_before": gated}


def pattern_b() -> Dict[str, Any]:
    hdr("B. Parallel independent critics",
        "analyze and checklist review what specify/plan produced. Run as one\n"
        "agent, a reviewer critiques its own reasoning with every prior\n"
        "justification still in context. As separate farm agents they see the\n"
        "artifacts only — and both are READ-ONLY by grant, so neither can edit\n"
        "what it is reviewing.")

    broker = default_broker()
    t0 = time.time()
    steps = parallel_critics(broker, target="payments-api")
    elapsed = time.time() - t0

    for s in steps:
        print(f"   {s.phase:22} {s.state:10} verdict={s.verdict:9} grants={s.granted_tools}")
    print(f"\n   Both critics ran concurrently in {elapsed:.1f}s, in separate sessions.")
    writes = [t for s in steps for t in s.granted_tools
              if t in ("git_tool", "execution_harness_tool", "speckit-cli")]
    print(f"   Write-capable tools held by any critic: {writes or 'none'}")
    broker.shutdown()
    return {"critics": len(steps), "write_tools": writes}


def pattern_c() -> Dict[str, Any]:
    hdr("C. Fan-out implementation across repos",
        "One approved plan drives N repos, each with its own implement agent,\n"
        "own checkpoints, own failure surface. Implementation is the only\n"
        "phase holding write + execute grants, so each repo independently\n"
        "stops for a real decision — and one repo waiting does not stall the\n"
        "others.")

    import threading
    broker = default_broker()
    repos = ["payments-api", "ledger-svc", "notify-worker"]

    holder: Dict[str, Any] = {}
    t = threading.Thread(
        target=lambda: holder.setdefault("results", fan_out_implement(broker, repos, timeout_s=25)),
        daemon=True)
    t.start()

    # Watch the escalations arrive, then act as the on-call reviewer.
    time.sleep(1.2)
    esc = dict(broker.pending_escalations)
    print(f"   {len(esc)} repos independently raised an approval, in parallel:")
    for cid, info in esc.items():
        print(f"      {info['caller']:34} wants {info['tool']} ({info['severity']})")
    # Approve two, reject one -- to show per-repo isolation of the outcome.
    for i, (cid, info) in enumerate(esc.items()):
        broker.resolve_escalation(cid, approved=(i < 2), by="oncall@example.com")
    t.join(timeout=30)
    results = holder.get("results", [])

    print()
    for r in results:
        refused = [x["tool"] for x in r.refusals] or "none"
        print(f"   {r.agent:34} {r.state:10} verdict={r.verdict:9} refused={refused}")

    agg = aggregate(results)
    print(f"\n   Farm aggregate: {agg['overall']}  ({agg['completed']}/{agg['agents']} completed)")
    print(f"   Audit: {broker.audit_summary()}")
    print("\n   Each repo got its own decision — two approved, one rejected — and")
    print("   the rejected repo's outcome did not change the other two.")
    broker.shutdown()
    return {"repos": len(repos), "escalations": len(esc), "aggregate": agg}


if __name__ == "__main__":
    SKILLS.reload()
    graph = load_handoff_graph()
    edges = sum(len(v) for v in graph.values())
    print(f"Loaded {len([k for k in graph if k.startswith('speckit')])} spec-kit "
          f"phase-agents, {edges} handoff edges, "
          f"{len(set(map(tuple, PHASE_GRANTS.values())))} distinct grant sets.")

    out = {"A": pattern_a(), "B": pattern_b(), "C": pattern_c()}
    print(f"\n{'='*72}\nSUMMARY\n{'-'*72}")
    for k, v in out.items():
        print(f"  Pattern {k}: {v}")
