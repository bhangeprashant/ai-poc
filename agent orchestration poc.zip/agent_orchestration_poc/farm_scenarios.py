"""
Top 5 farm scenarios — each exercises a capability that only matters once
MULTIPLE agents share one harness.

Run all:      python farm_scenarios.py
Run one:      python farm_scenarios.py 3

  1. Release readiness gate      -- many specialists, ONE approval plane
  2. Cross-repo SDD rollout      -- shared skills/constitution across N repos
  3. Incident triage swarm       -- parallel investigation, context isolation
  4. Mobile regression fleet     -- contention for FIXED capacity, fair queueing
  5. Shared utility plane        -- risk-tiered access to team-published tools

Every scenario runs against the real harness: real sessions, real
approval gate, real sandbox pool, real utility registry. Nothing here
mocks the thing it's demonstrating.
"""

from __future__ import annotations

import sys
import threading
import time
from typing import Any, Dict, List

from farm_core import (
    PolicyBroker, PolicyRule, FarmAgent, FarmCoordinator, aggregate,
    APPROVE, DENY, ESCALATE,
)
from harness_core import SESSIONS, SessionState
from harness_loop import run_turn_async
from sandbox_pool import SandboxPoolManager, Backpressure, SimulatedExternalDeviceCloud


def hdr(n: int, title: str, why: str) -> None:
    print(f"\n{'='*74}\nSCENARIO {n}: {title}\n{'-'*74}\n{why}\n")


def line(label: str, value: Any) -> None:
    print(f"   {label:<34} {value}")


# ============================================================ SCENARIO 1 ====

def scenario_1_release_gate() -> Dict[str, Any]:
    hdr(1, "Release readiness gate",
        "Four specialist agents assess a release in parallel. Without a farm\n"
        "layer, a human sits on four event streams resolving checkpoints by\n"
        "hand. The PolicyBroker collapses that to one decision plane: routine\n"
        "reads auto-approve, production writes escalate to a human, and\n"
        "nothing is approved by omission.")

    broker = PolicyBroker(rules=[
        PolicyRule("readonly-auto", APPROVE, max_severity="low",
                   reason="Read-only checks carry no side effects."),
        PolicyRule("qa-tracker-write", APPROVE, callers=["qa_agent"],
                   tools=["jira_tool"], max_severity="medium",
                   reason="QA owns its own tickets."),
        PolicyRule("no-prod-code-exec", DENY, tools=["execution_harness_tool"],
                   reason="Arbitrary code execution is never auto-approved in a release gate."),
        # Anything else -- notably git writes -- falls through to escalation.
    ])

    agents = [
        FarmAgent("qa_agent", "qa", ["jira_tool", "knowledge_search_tool"]),
        FarmAgent("compliance_agent", "compliance", ["compliance_tool", "knowledge_search_tool"]),
        FarmAgent("release_agent", "engineer", ["git_tool", "jira_tool"]),
        FarmAgent("security_agent", "compliance", ["execution_harness_tool", "knowledge_search_tool"]),
    ]
    goals = {
        "qa_agent": "Check jira for open defects blocking the payments release",
        "compliance_agent": "Run the compliance check for the payments release",
        "release_agent": "Check git for unmerged changes on the release branch",
        "security_agent": "Run the security scan in the execution harness",
    }

    coord = FarmCoordinator(broker)
    t = threading.Thread(
        target=lambda: coord.dispatch(agents, lambda a: goals[a.name], timeout_s=25),
        daemon=True)
    t.start()

    # Watch escalations appear, then act as the human on-call would.
    time.sleep(1.2)
    esc = dict(broker.pending_escalations)
    line("agents dispatched", len(agents))
    line("auto-resolved by policy", len([a for a in broker.audit if a.decision != ESCALATE]))
    line("escalated to human", len(esc))
    for cid, info in esc.items():
        print(f"      -> {info['caller']} wants {info['tool']} ({info['severity']}) — human decides")
        broker.resolve_escalation(cid, approved=True, by="oncall@example.com")
    t.join(timeout=25)

    time.sleep(0.4)
    print()
    line("audit summary", broker.audit_summary())
    denied = [a for a in broker.audit if a.decision == DENY]
    line("policy-denied actions", [(a.caller, a.tool) for a in denied])
    broker.shutdown()
    return {"escalations": len(esc), "denied": len(denied), "audit": len(broker.audit)}


# ============================================================ SCENARIO 2 ====

def scenario_2_sdd_rollout() -> Dict[str, Any]:
    hdr(2, "Cross-repo spec-driven development rollout",
        "One coordinator fans a Spec Kit workflow across many repos, each\n"
        "handled by its own agent. The value: every agent reads the SAME\n"
        "speckit skills and the SAME project constitution from the harness,\n"
        "so 50 repos get one consistent process instead of 50 interpretations\n"
        "of it — and the constitution is a constraint, enforced, not advice.")

    from harness_context import SKILLS
    SKILLS.reload()
    speckit = [s for s in SKILLS.all() if s.name.startswith("speckit")]
    constraints = [s for s in SKILLS.constraints()]
    line("speckit skills available to every agent", len(speckit))
    line("constraints enforced on every agent", [c.name for c in constraints])

    broker = PolicyBroker(rules=[
        PolicyRule("sdd-scaffold", APPROVE, tools=["speckit-cli"], max_severity="medium",
                   reason="Spec scaffolding writes only into specs/ on a feature branch."),
        PolicyRule("reads", APPROVE, max_severity="low", reason="Read-only."),
    ])

    repos = ["payments-api", "ledger-svc", "notify-worker"]
    agents = [FarmAgent(f"sdd_agent_{r}", "engineer", ["speckit-cli", "knowledge_search_tool"],
                        {"repo": r}) for r in repos]
    coord = FarmCoordinator(broker)
    results = coord.dispatch(
        agents,
        lambda a: f"Use speckit-cli to run the specify phase for {a.metadata['repo']}",
        timeout_s=25)

    print()
    for r in results:
        line(f"{r.agent}", f"{r.state} · verdict={r.verdict} · skills-driven")
    agg = aggregate(results)
    line("farm aggregate", agg)
    broker.shutdown()
    return {"repos": len(repos), "aggregate": agg}


# ============================================================ SCENARIO 3 ====

def scenario_3_incident_swarm() -> Dict[str, Any]:
    hdr(3, "Incident triage swarm",
        "Several investigators pursue different hypotheses in parallel on one\n"
        "incident. Each runs in its OWN session with its own working memory,\n"
        "so a noisy log-dump in one investigation never pollutes another's\n"
        "context. Only their conclusions are aggregated — the harness's\n"
        "subagent/compaction model applied across agents rather than within one.")

    broker = PolicyBroker(rules=[
        PolicyRule("investigate-reads", APPROVE, max_severity="medium",
                   reason="Triage is read-heavy; medium reads are pre-authorised during an incident."),
        PolicyRule("no-exec-during-incident", DENY, tools=["execution_harness_tool"],
                   reason="No arbitrary code execution against a system already misbehaving."),
    ])

    hypotheses = {
        "investigator_deploy": ("Check git for deploys correlated with the payments 503 window", ["git_tool"]),
        "investigator_tickets": ("Check jira for recent incidents matching payments 503", ["jira_tool"]),
        "investigator_kb": ("Search the knowledge base for prior payments 503 root causes", ["knowledge_search_tool"]),
        "investigator_exec": ("Run a diagnostic script in the execution harness", ["execution_harness_tool"]),
    }
    agents = [FarmAgent(n, "qa", tools) for n, (_, tools) in hypotheses.items()]
    coord = FarmCoordinator(broker)
    results = coord.dispatch(agents, lambda a: hypotheses[a.name][0], timeout_s=25)

    print()
    for r in results:
        detail = f"{r.verdict}"
        if r.refusals:
            detail += f" (refused: {[x['tool'] for x in r.refusals]})"
        line(r.agent, detail)

    agg = aggregate(results)
    print()
    line("farm aggregate", agg["overall"])
    print("\n   Note: the exec investigator was policy-DENIED, so the farm verdict is")
    print("   not 'ok' — one hypothesis genuinely went unchecked. A farm that")
    print("   reported 'ok' here would be claiming coverage it does not have.")
    broker.shutdown()
    return {"aggregate": agg}


# ============================================================ SCENARIO 4 ====

def scenario_4_device_fleet() -> Dict[str, Any]:
    hdr(4, "Mobile regression fleet on fixed device capacity",
        "Many test agents contend for a small rack of real devices. This is\n"
        "where a farm without queueing fails: a batch regression starves the\n"
        "interactive agent a human is waiting on. The pool queues fairly,\n"
        "refuses honestly under load, and overflows to a paid device cloud\n"
        "rather than failing outright.")

    cloud = SimulatedExternalDeviceCloud()
    pool = SandboxPoolManager(min_replicas=0, max_replicas=2, elastic=False,
                              max_queue=3, queue_timeout_s=1.5,
                              overflow_provider=cloud)
    pool.register("http://pixel8-01:4723", capacity=1, kind="real_device",
                  capabilities={"platform": "android", "device_model": "Pixel8"})
    pool.register("http://iphone15-01:4723", capacity=1, kind="real_device",
                  capabilities={"platform": "ios", "device_model": "iPhone15Pro"})

    line("physical devices in rack", 2)
    line("agents requesting devices", 6)

    outcomes: List[Dict[str, Any]] = []
    lock = threading.Lock()

    def agent_run(name: str, platform: str, hold: float) -> None:
        try:
            lease = pool.acquire(name, kind="real_device", timeout_s=1.5,
                                 requirements={"platform": platform})
            with lock:
                outcomes.append({"agent": name, "result": "leased",
                                 "device": lease.endpoint, "external": lease.external})
            time.sleep(hold)
            pool.release(lease)
        except Backpressure as exc:
            with lock:
                outcomes.append({"agent": name, "result": "backpressure",
                                 "detail": str(exc)[:60]})

    threads = []
    for i in range(3):
        threads.append(threading.Thread(target=agent_run,
                                        args=(f"regression_agent_{i}", "android", 0.9)))
    for i in range(3):
        threads.append(threading.Thread(target=agent_run,
                                        args=(f"ios_agent_{i}", "ios", 0.9)))
    for t in threads:
        t.start()
        time.sleep(0.05)
    for t in threads:
        t.join(timeout=10)

    print()
    own = [o for o in outcomes if o["result"] == "leased" and not o.get("external")]
    ext = [o for o in outcomes if o["result"] == "leased" and o.get("external")]
    bp = [o for o in outcomes if o["result"] == "backpressure"]
    line("served by owned devices", len(own))
    line("overflowed to device cloud", len(ext))
    line("refused with backpressure", len(bp))
    line("pool status", pool.status())
    print("\n   Every agent got a definite answer — a device, a cloud device, or a")
    print("   clear refusal. None hung waiting on capacity that was never coming.")
    pool.shutdown()
    return {"owned": len(own), "external": len(ext), "backpressure": len(bp)}


# ============================================================ SCENARIO 5 ====

def scenario_5_utility_plane() -> Dict[str, Any]:
    hdr(5, "Shared utility plane across teams",
        "Teams publish their own automation once; every agent in the farm can\n"
        "call it. The risk tier travels with the utility, so a reviewed,\n"
        "low-risk tool runs friction-free for everyone while an unreviewed\n"
        "upload stays gated for everyone — including the team that wrote it.")

    from utility_registry import UTILITIES
    from sandbox_pool import POOL
    POOL.register("http://sbx-py-farm:9000", capacity=4, kind="python_utility")
    UTILITIES.reload()

    UTILITIES.upload("adhoc-log-parser", "Team-written log parser", "sre_team",
                     code="def run(params):\n    return {'parsed': True}\n")

    published = UTILITIES.all()
    line("utilities visible to all agents", len(published))
    for u in published:
        line(f"  {u.name}", f"source={u.source} risk={u.risk} trusted={u.trusted}")

    broker = PolicyBroker(rules=[
        PolicyRule("reviewed-low", APPROVE, max_severity="low",
                   reason="Reviewed, low-risk utilities are pre-authorised farm-wide."),
        PolicyRule("reviewed-medium", APPROVE, tools=["speckit-cli"], max_severity="medium",
                   reason="Reviewed scaffolding utility."),
        # Uploaded utilities are forced to HIGH risk by the registry, so they
        # match no approve rule and escalate -- for every caller, including
        # the authoring team.
    ])

    agents = [
        FarmAgent("docs_agent", "generalist", ["changelog-formatter"]),
        FarmAgent("sre_team", "engineer", ["adhoc-log-parser"]),
    ]
    coord = FarmCoordinator(broker)
    t = threading.Thread(
        target=lambda: coord.dispatch(
            agents,
            lambda a: (f"Use {a.tools[0]} to process the latest release notes"),
            timeout_s=20),
        daemon=True)
    t.start()
    time.sleep(1.2)

    esc = dict(broker.pending_escalations)
    print()
    # A low-risk reviewed utility never even reaches the broker: the harness
    # auto-approves at dispatch (AUTO_APPROVE_LOW), so it raises no checkpoint
    # at all. That is the friction-free path working, not a missing approval --
    # counting broker approvals alone would misreport it as "0 approved".
    from harness_loop import _requires_approval, _tool_severity
    for name in ("changelog-formatter", "adhoc-log-parser"):
        sev = _tool_severity(name).value
        gated = _requires_approval(name)
        line(f"{name} ({sev})",
             "gated — needs approval" if gated else "no checkpoint raised (friction-free)")

    line("escalated to a human", len(esc))
    for cid, info in esc.items():
        print(f"      -> {info['caller']} calling {info['tool']} "
              f"({info['severity']}) — needs a human")
        broker.resolve_escalation(cid, approved=True, by="platform-eng")
    t.join(timeout=20)
    print("\n   The team that uploaded the utility still had to get it approved.")
    print("   Authorship is not authorisation.")
    broker.shutdown()
    return {"escalations": len(esc)}


SCENARIOS = {
    1: scenario_1_release_gate,
    2: scenario_2_sdd_rollout,
    3: scenario_3_incident_swarm,
    4: scenario_4_device_fleet,
    5: scenario_5_utility_plane,
}


if __name__ == "__main__":
    which = [int(a) for a in sys.argv[1:] if a.isdigit()] or list(SCENARIOS)
    summary = {}
    for n in which:
        try:
            summary[n] = SCENARIOS[n]()
        except Exception as exc:  # noqa: BLE001
            import traceback
            print(f"\n   SCENARIO {n} FAILED: {exc}")
            traceback.print_exc()
            summary[n] = {"error": str(exc)}
    print(f"\n{'='*74}\nSUMMARY\n{'-'*74}")
    for n, s in summary.items():
        print(f"  Scenario {n}: {s}")
