"""
Farm layer — what changes when MANY agents share one harness.

A single agent calling the harness needs a loop and a gate. A farm needs
three things a single agent never does:

  1. ONE APPROVAL PLANE. With 20 agents running, a human cannot sit on 20
     event streams resolving checkpoints. The PolicyBroker is the farm's
     single decision point: agents raise checkpoints exactly as before,
     and the broker resolves them from declared rules, escalating only
     what no rule covers. Critically, the DEFAULT IS ESCALATE, not
     approve -- a broker that auto-approves anything it doesn't recognise
     is just the gate removed with extra steps.

  2. FAIR ACCESS TO SCARCE CAPACITY. Agents contend for the same sandbox
     and device pool. Without priority, a 200-run batch regression starves
     the one interactive agent a human is waiting on.

  3. CROSS-AGENT ATTRIBUTION. When something writes to production, "an
     agent did it" is not an answer. Every decision the broker makes is
     recorded with which agent asked, what it wanted, which rule fired,
     and what happened.

The farm does NOT get its own execution path. Agents still go through
HarnessRun, still hit the same gate, still lease from the same pool. The
farm layer only decides and observes -- it never becomes a way around
the controls the harness already enforces.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from harness_core import SESSIONS, Session, SessionState
from harness_loop import run_turn_async


# ------------------------------------------------------------------ policy --

ESCALATE = "escalate"
APPROVE = "approve"
DENY = "deny"


@dataclass
class PolicyRule:
    """One declarative rule. First match wins, in list order."""
    name: str
    decision: str                      # approve | deny | escalate
    callers: Optional[List[str]] = None        # None = any caller
    tools: Optional[List[str]] = None          # None = any tool
    max_severity: Optional[str] = None         # approve only at/below this
    reason: str = ""

    def matches(self, caller: str, tool: str, severity: str) -> bool:
        if self.callers is not None and caller not in self.callers:
            return False
        if self.tools is not None and tool not in self.tools:
            return False
        if self.max_severity is not None:
            order = {"low": 0, "medium": 1, "high": 2}
            if order.get(severity, 2) > order.get(self.max_severity, 0):
                return False
        return True


@dataclass
class AuditEntry:
    ts: float
    session_id: str
    caller: str
    tool: str
    severity: str
    decision: str
    rule: str
    reason: str


class PolicyBroker:
    """The farm's single approval plane.

    Runs one background thread that watches every farm session for open
    checkpoints and resolves them against the rule list. Anything no rule
    covers goes to `pending_escalations` for a human -- it is NOT approved
    by default and it does NOT silently time out unnoticed.
    """

    def __init__(self, rules: Optional[List[PolicyRule]] = None,
                 poll_interval: float = 0.15):
        self.rules = rules or []
        self.poll_interval = poll_interval
        self.audit: List[AuditEntry] = []
        self.pending_escalations: Dict[str, Dict[str, Any]] = {}
        self._watched: Dict[str, Session] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="farm-policy-broker")
        self._thread.start()

    def watch(self, session: Session) -> None:
        with self._lock:
            self._watched[session.session_id] = session

    def decide(self, caller: str, tool: str, severity: str) -> tuple:
        for rule in self.rules:
            if rule.matches(caller, tool, severity):
                return rule.decision, rule.name, rule.reason
        # No rule matched. Escalate -- never approve by omission.
        return (ESCALATE, "default",
                "No rule covers this caller/tool/severity combination.")

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception:  # noqa: BLE001
                pass
            self._stop.wait(self.poll_interval)

    def _tick(self) -> None:
        with self._lock:
            sessions = list(self._watched.values())
        for s in sessions:
            for cp in list(s.checkpoints.values()):
                if cp.resolved or cp.checkpoint_id in self.pending_escalations:
                    continue
                if cp.kind != "approval":
                    continue
                tool = cp.payload.get("tool", "")
                severity = cp.payload.get("severity", "high")
                decision, rule_name, reason = self.decide(s.caller, tool, severity)

                entry = AuditEntry(ts=time.time(), session_id=s.session_id,
                                   caller=s.caller, tool=tool, severity=severity,
                                   decision=decision, rule=rule_name, reason=reason)
                self.audit.append(entry)

                if decision == APPROVE:
                    cp.resolve(approved=True, by=f"policy:{rule_name}")
                elif decision == DENY:
                    cp.resolve(approved=False, by=f"policy:{rule_name}")
                else:
                    # Park it for a human. The agent stays blocked, which is
                    # the correct outcome -- an unresolved high-risk action
                    # should stall, not proceed.
                    self.pending_escalations[cp.checkpoint_id] = {
                        "session_id": s.session_id, "caller": s.caller,
                        "tool": tool, "severity": severity,
                        "prompt": cp.prompt, "raised_at": time.time(),
                    }

    def resolve_escalation(self, checkpoint_id: str, approved: bool,
                           by: str = "human") -> bool:
        info = self.pending_escalations.pop(checkpoint_id, None)
        if not info:
            return False
        s = SESSIONS.get(info["session_id"])
        if not s:
            return False
        cp = s.checkpoints.get(checkpoint_id)
        if not cp or cp.resolved:
            return False
        cp.resolve(approved=approved, by=by)
        self.audit.append(AuditEntry(
            ts=time.time(), session_id=info["session_id"], caller=info["caller"],
            tool=info["tool"], severity=info["severity"],
            decision=APPROVE if approved else DENY, rule="human-escalation",
            reason=f"Resolved by {by}"))
        return True

    def audit_summary(self) -> Dict[str, Any]:
        by_decision: Dict[str, int] = {}
        by_caller: Dict[str, int] = {}
        for e in self.audit:
            by_decision[e.decision] = by_decision.get(e.decision, 0) + 1
            by_caller[e.caller] = by_caller.get(e.caller, 0) + 1
        return {"total": len(self.audit), "by_decision": by_decision,
                "by_caller": by_caller,
                "open_escalations": len(self.pending_escalations)}

    def shutdown(self) -> None:
        self._stop.set()


# ------------------------------------------------------------- coordination --

@dataclass
class FarmAgent:
    """One member of the farm."""
    name: str
    profile: str
    tools: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FarmResult:
    agent: str
    session_id: str
    state: str
    answer: str = ""
    verdict: str = ""
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    refusals: List[Dict[str, Any]] = field(default_factory=list)
    error: str = ""


class FarmCoordinator:
    """Fans a goal out to many agents and collects their results.

    Each agent gets its OWN session with its OWN tool grants -- the farm
    never hands one broad grant to everyone. A QA agent that only needs
    read access does not get write scope because a sibling agent needed it.
    """

    def __init__(self, broker: PolicyBroker):
        self.broker = broker

    def dispatch(self, agents: List[FarmAgent], goal_for: Callable[[FarmAgent], str],
                 timeout_s: float = 30.0) -> List[FarmResult]:
        sessions: Dict[str, Session] = {}
        for a in agents:
            s = SESSIONS.create(a.name, a.profile, a.tools, a.metadata)
            self.broker.watch(s)
            sessions[a.name] = s
            run_turn_async(s, goal_for(a))

        deadline = time.time() + timeout_s
        while time.time() < deadline:
            if all(s.state in (SessionState.COMPLETED.value,
                               SessionState.FAILED.value)
                   for s in sessions.values()):
                break
            time.sleep(0.05)

        results = []
        for a in agents:
            s = sessions[a.name]
            r = s.last_result or {}
            results.append(FarmResult(
                agent=a.name, session_id=s.session_id, state=s.state,
                answer=r.get("answer", ""),
                verdict=(r.get("evaluation") or {}).get("verdict", ""),
                tool_calls=r.get("tool_calls", []),
                refusals=r.get("refusals", []),
                error=r.get("detail", "") if r.get("error") else "",
            ))
        return results


def aggregate(results: List[FarmResult]) -> Dict[str, Any]:
    """Roll many agent outcomes into one farm-level verdict.

    The rule that matters: a farm result is only as trustworthy as its
    weakest member. One `blocked` agent means the farm did not actually
    check what it claims to have checked, so the aggregate cannot be `ok`.
    """
    verdicts = [r.verdict for r in results if r.verdict]
    if any(v == "blocked" for v in verdicts):
        overall = "blocked"
    elif any(v in ("partial", "ungrounded") for v in verdicts):
        overall = "partial"
    elif verdicts and all(v == "ok" for v in verdicts):
        overall = "ok"
    else:
        overall = "unknown"
    return {
        "overall": overall,
        "agents": len(results),
        "completed": sum(1 for r in results if r.state == "completed"),
        "by_verdict": {v: verdicts.count(v) for v in set(verdicts)},
        "total_tool_calls": sum(len(r.tool_calls) for r in results),
        "total_refusals": sum(len(r.refusals) for r in results),
    }
