"""
KG + registry in a farm — end to end.

    python farm_kg_demo.py

Shows the two things the centralised graph actually buys a farm:
  A. Grants derived from the graph instead of a hand-authored table
  B. Approval severity that follows blast radius, not just tool identity
  C. Findings shared across agents with provenance intact
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict

from farm_core import PolicyBroker, PolicyRule, FarmAgent, FarmCoordinator, APPROVE, DENY
from knowledge_graph import KG, seed_demo_estate
from tool_broker import BROKER, ROLE_CEILINGS


def hdr(t: str, why: str) -> None:
    print(f"\n{'='*72}\n{t}\n{'-'*72}\n{why}\n")


def part_a() -> Dict[str, Any]:
    hdr("A. Grants derived from the graph, not a table",
        "A hand-authored (phase x service) grant matrix does not survive 50\n"
        "services. The broker resolves the goal to real subjects via hybrid\n"
        "search, reads their uses_tool edges, then intersects with the role\n"
        "ceiling. Two narrowings: what the work needs, and what the role may\n"
        "ever hold. The tighter one wins.")

    goals = {
        "refund work": "Implement the refund reversal flow across payments and ledger",
        "MFA work": "Fix the MFA step-up during login",
    }
    out = {}
    for label, goal in goals.items():
        print(f"   {label}: \"{goal}\"")
        for role in ("reviewer", "implementer"):
            d = BROKER.derive_grants(role, goal)
            print(f"      {role:12} subjects={d.resolved_subjects}")
            print(f"      {'':12} granted ={d.granted}")
            if d.withheld_by_ceiling:
                print(f"      {'':12} withheld={d.withheld_by_ceiling} (role ceiling)")
        out[label] = BROKER.derive_grants("implementer", goal).granted
        print()
    return out


def part_b() -> Dict[str, Any]:
    hdr("B. Blast radius drives approval severity",
        "The registry says git_tool is medium, always. The graph knows a git\n"
        "write to auth-svc reaches 4 services and one to notify-worker reaches\n"
        "none. Same tool, same registry entry, different real risk — so the\n"
        "policy plane sees different severities and only one needs a human.")

    broker = PolicyBroker(rules=[
        PolicyRule("reads", APPROVE, max_severity="low", reason="Read-only."),
        PolicyRule("contained-writes", APPROVE, max_severity="medium",
                   reason="Writes with a contained blast radius are pre-authorised."),
        # high severity (hub services) matches nothing -> escalates to a human
    ])

    results = {}
    for svc in ("service:notify-worker", "service:payments-api", "service:auth-svc"):
        eff, why = BROKER.effective_severity("git_tool", svc)
        decision, rule, _ = broker.decide("implement_agent", "git_tool", eff)
        name = svc.split(":")[1]
        radius = KG.blast_radius(svc)["reached"]
        print(f"   git_tool on {name:15} dependents={radius}  severity={eff:7} "
              f"-> {decision.upper():9} (rule: {rule})")
        results[name] = {"severity": eff, "decision": decision, "dependents": radius}
    print("\n   Note the same tool produced two different outcomes. A static risk")
    print("   table cannot express this: it would either gate every git write")
    print("   (and nobody would ship) or gate none (and auth-svc goes unguarded).")
    broker.shutdown()
    return results


def part_c() -> Dict[str, Any]:
    hdr("C. Findings shared across agents, with provenance",
        "One agent's discovery should not leave siblings to rediscover it.\n"
        "Findings become graph nodes attributed to the run and agent that\n"
        "produced them, so a later agent retrieves them like any other\n"
        "knowledge — and can weigh them, because the source travels along.")

    KG.record_finding(
        "Refund reversal fails when the ledger entry predates the 2026-03 schema migration; "
        "affects partial refunds only.",
        run_id="run_a41", agent="investigator_ledger",
        about=["service:ledger-svc", "spec:refund-flow"])
    KG.record_finding(
        "auth-svc session tokens are not refreshed during MFA step-up, causing a 401 on slow devices.",
        run_id="run_b12", agent="investigator_auth",
        about=["service:auth-svc"])

    print("   A later agent asks about refunds and gets the prior finding:")
    for h in BROKER.context_for("why do partial refunds fail", top_k=3):
        src = ""
        if h["kind"] == "finding":
            src = f"  [from {h['attrs'].get('agent')} / {h['attrs'].get('run_id')}]"
        print(f"      {h['rrf_score']:.5f} {h['kind']:8} {h['name'][:38]:38}{src}")
    print("\n   Every finding carries which run and which agent produced it. A")
    print("   finding with no provenance is an unsourced claim a later agent")
    print("   has no way to judge.")
    return KG.stats()


def part_d() -> Dict[str, Any]:
    hdr("D. A live farm run using derived grants",
        "Agents are constructed from the broker's decision rather than a\n"
        "hand-written tool list, then run through the normal harness gate.")

    broker = PolicyBroker(rules=[
        PolicyRule("reads", APPROVE, max_severity="low", reason="Read-only."),
        PolicyRule("contained", APPROVE, max_severity="medium",
                   reason="Contained blast radius."),
    ])
    goal = "Implement the refund reversal flow across payments and ledger"

    agents = []
    for role, profile in (("reviewer", "qa"), ("implementer", "engineer")):
        d = BROKER.derive_grants(role, goal)
        agents.append(FarmAgent(f"{role}_agent", profile, d.granted,
                                {"derived_from": d.resolved_subjects}))
        print(f"   {role:12} -> grants {d.granted}")

    coord = FarmCoordinator(broker)
    t = threading.Thread(target=lambda: coord.dispatch(
        agents, lambda a: goal, timeout_s=20), daemon=True)
    t.start()
    time.sleep(1.2)
    esc = dict(broker.pending_escalations)
    for cid in esc:
        broker.resolve_escalation(cid, approved=True, by="oncall@example.com")
    t.join(timeout=25)
    print(f"\n   audit: {broker.audit_summary()}")
    broker.shutdown()
    return {"agents": len(agents), "escalations": len(esc)}


if __name__ == "__main__":
    seed_demo_estate(KG)
    print(f"Knowledge graph seeded: {KG.stats()}")
    print(f"Role ceilings defined: {list(ROLE_CEILINGS)}")
    out = {"A": part_a(), "B": part_b(), "C": part_c(), "D": part_d()}
    print(f"\n{'='*72}\nSUMMARY\n{'-'*72}")
    for k, v in out.items():
        print(f"  Part {k}: {v}")
