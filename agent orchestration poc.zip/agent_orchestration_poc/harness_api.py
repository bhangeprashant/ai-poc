"""
Harness Orchestrator — HTTP API.

Other agents call this. It runs the loop and streams every step back in
real time.

  POST   /v1/sessions                      open a session, declare tool grants
  POST   /v1/sessions/{id}/turns           submit a goal (returns immediately)
  GET    /v1/sessions/{id}/events          SSE stream, resumable via ?after=
  POST   /v1/sessions/{id}/checkpoints/{c} resolve an approval / answer
  GET    /v1/sessions/{id}                 full session state (stream-independent)
  POST   /v1/sessions/{id}/memory          seed semantic / personalized memory
  POST   /v1/invoke                        one-shot blocking convenience call
  GET    /v1/skills                        skill catalog
  GET    /v1/tools                         tool catalog with risk classes
  GET    /healthz

Two delivery modes on purpose:

  Streaming (sessions + SSE) is the real interface. A calling agent sees
  planning, each tool call, approval requests, and compaction as they
  happen, and can resolve checkpoints mid-run.

  /v1/invoke is a blocking convenience wrapper for simple callers that
  just want an answer. It cannot support approval checkpoints -- there is
  nobody to ask inside a single request -- so it only accepts sessions
  whose granted tools are all auto-approvable, and rejects otherwise
  rather than silently escalating privilege.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field

from harness_core import SESSIONS, SessionState, EventType
from harness_context import SKILLS
from harness_loop import (
    run_turn_async, memory_for, _requires_approval, MAX_STEPS,
)
from tool_registry import list_tools
from approvals import TOOL_RISK, Severity
from utility_registry import UTILITIES, UtilityError, scaffold as scaffold_utility

app = FastAPI(title="Harness Orchestrator", version="1.0")

INVOKE_TIMEOUT_S = float(os.environ.get("HARNESS_INVOKE_TIMEOUT_S", "120"))


class CreateSession(BaseModel):
    caller: str = Field(..., description="Identity of the calling agent")
    agent_profile: str = "generalist"
    granted_tools: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SubmitTurn(BaseModel):
    goal: str


class ResolveCheckpoint(BaseModel):
    approved: Optional[bool] = None
    answer: Optional[str] = None
    resolved_by: str = "caller"


class SeedMemory(BaseModel):
    kind: str = "semantic"
    content: str


class InvokeRequest(BaseModel):
    caller: str
    goal: str
    agent_profile: str = "generalist"
    granted_tools: List[str] = Field(default_factory=list)
    timeout_s: float = INVOKE_TIMEOUT_S


class UploadUtility(BaseModel):
    name: str
    description: str = ""
    owner: str
    code: str
    input_schema: Dict[str, Any] = Field(default_factory=dict)
    requirements: List[str] = Field(default_factory=list)


class ScaffoldUtility(BaseModel):
    name: str
    description: str = ""
    owner: str = "your-team"


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {"ok": True, "sessions": len(SESSIONS.list()),
            "skills": len(SKILLS.all()), "max_steps": MAX_STEPS}


@app.get("/v1/tools")
def tools() -> Dict[str, Any]:
    out = []
    for t in list_tools():
        sev, why = TOOL_RISK.get(t["name"], (Severity.MEDIUM, "unclassified"))
        out.append({**t, "risk": sev.value, "risk_rationale": why,
                    "requires_approval": _requires_approval(t["name"])})
    return {"tools": out}


@app.get("/v1/skills")
def skills() -> Dict[str, Any]:
    return {"skills": [
        {"name": s.name, "kind": s.kind, "summary": s.summary,
         "applies_to": s.applies_to}
        for s in SKILLS.all()
    ]}


@app.post("/v1/sessions")
def create_session(req: CreateSession) -> Dict[str, Any]:
    known = {t["name"] for t in list_tools()}
    unknown = [t for t in req.granted_tools if t not in known]
    if unknown:
        raise HTTPException(400, f"Unknown tools requested: {unknown}. "
                                 f"See GET /v1/tools.")
    s = SESSIONS.create(req.caller, req.agent_profile,
                        req.granted_tools, req.metadata)
    return s.public()


@app.get("/v1/sessions")
def list_sessions(caller: Optional[str] = None) -> Dict[str, Any]:
    return {"sessions": [s.public() for s in SESSIONS.list(caller)]}


@app.get("/v1/sessions/{sid}")
def get_session(sid: str) -> Dict[str, Any]:
    s = SESSIONS.get(sid)
    if not s:
        raise HTTPException(404, "Session not found")
    bus = SESSIONS.bus(sid)
    return {**s.public(), "current_seq": bus.current_seq(),
            "memory": memory_for(sid).stats()}


@app.post("/v1/sessions/{sid}/turns")
def submit_turn(sid: str, req: SubmitTurn) -> Dict[str, Any]:
    s = SESSIONS.get(sid)
    if not s:
        raise HTTPException(404, "Session not found")
    if s.state in (SessionState.RUNNING.value,
                   SessionState.AWAITING_APPROVAL.value,
                   SessionState.AWAITING_ANSWER.value):
        raise HTTPException(409, f"Session is {s.state}; one turn at a time. "
                                 "Resolve open checkpoints or wait for completion.")
    bus = SESSIONS.bus(sid)
    from_seq = bus.current_seq()
    turn_id = run_turn_async(s, req.goal)
    return {"session_id": sid, "turn_id": turn_id, "state": s.state,
            "stream": f"/v1/sessions/{sid}/events?after={from_seq}",
            "note": "Attach to the stream for real-time progress."}


@app.get("/v1/sessions/{sid}/events")
def stream_events(sid: str, after: int = 0) -> StreamingResponse:
    """SSE. Resume with ?after=<last seq you processed>."""
    if not SESSIONS.get(sid):
        raise HTTPException(404, "Session not found")
    bus = SESSIONS.bus(sid)

    def gen():
        # Tell proxies not to buffer; without this, SSE arrives in chunks
        # at the worst possible moment and "real time" stops being true.
        yield ": harness stream open\n\n"
        for ev in bus.stream(after_seq=after):
            yield ev.to_sse()

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-transform",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/v1/sessions/{sid}/checkpoints/{cid}")
def resolve_checkpoint(sid: str, cid: str, req: ResolveCheckpoint) -> Dict[str, Any]:
    s = SESSIONS.get(sid)
    if not s:
        raise HTTPException(404, "Session not found")
    cp = s.checkpoints.get(cid)
    if not cp:
        raise HTTPException(404, "Checkpoint not found")
    if cp.resolved:
        raise HTTPException(409, f"Checkpoint already resolved "
                                 f"({'approved' if cp.approved else 'rejected'}) "
                                 f"by {cp.resolved_by}.")
    if cp.kind == "approval" and req.approved is None:
        raise HTTPException(400, "'approved' is required for an approval checkpoint.")
    cp.resolve(approved=req.approved, answer=req.answer, by=req.resolved_by)
    s.touch()
    return {"checkpoint_id": cid, "resolved": True, "approved": cp.approved}


@app.post("/v1/sessions/{sid}/memory")
def seed_memory(sid: str, req: SeedMemory) -> Dict[str, Any]:
    if not SESSIONS.get(sid):
        raise HTTPException(404, "Session not found")
    if req.kind not in ("semantic", "personalized", "episodic"):
        raise HTTPException(400, "kind must be semantic, personalized, or episodic")
    mem = memory_for(sid)
    mem.add(req.kind, req.content)
    return {"ok": True, "memory": mem.stats()}


@app.post("/v1/invoke")
def invoke(req: InvokeRequest) -> Dict[str, Any]:
    """Blocking one-shot. Refuses tools that would need a checkpoint."""
    needs = [t for t in req.granted_tools if _requires_approval(t)]
    if needs:
        raise HTTPException(
            400,
            f"Tools {needs} require an approval checkpoint, which a blocking "
            "call cannot service — there is no one to ask inside a single "
            "request. Open a session and attach to the event stream instead: "
            "POST /v1/sessions, then POST /v1/sessions/{id}/turns.",
        )
    known = {t["name"] for t in list_tools()}
    unknown = [t for t in req.granted_tools if t not in known]
    if unknown:
        raise HTTPException(400, f"Unknown tools requested: {unknown}")

    s = SESSIONS.create(req.caller, req.agent_profile, req.granted_tools, {})
    run_turn_async(s, req.goal)

    deadline = time.time() + req.timeout_s
    while time.time() < deadline:
        if s.state in (SessionState.COMPLETED.value, SessionState.FAILED.value):
            return {"session_id": s.session_id, "state": s.state,
                    "result": s.last_result}
        time.sleep(0.05)
    raise HTTPException(504, f"Turn did not complete within {req.timeout_s:.0f}s. "
                             f"Session {s.session_id} is still running; attach to "
                             f"/v1/sessions/{s.session_id}/events.")


@app.post("/v1/maintenance/evict")
def evict() -> Dict[str, Any]:
    return {"evicted": SESSIONS.evict_idle()}


# --------------------------------------------------------------- utilities

@app.get("/v1/utilities")
def list_utilities() -> Dict[str, Any]:
    return {"utilities": [u.to_public() for u in UTILITIES.all()]}


@app.post("/v1/utilities")
def upload_utility(req: UploadUtility) -> Dict[str, Any]:
    """Self-service hosting for a team's locally-written script.

    Always lands sandboxed and at HIGH risk, regardless of what the team
    believes about their own code -- see utility_registry.py's docstring.
    To get a lower risk tier or in-process execution, commit it under
    utilities/<name>/ instead, where a PR review is the actual trust
    boundary, not a self-report in an API payload.
    """
    try:
        u = UTILITIES.upload(req.name, req.description, req.owner, req.code,
                             req.input_schema, req.requirements)
    except UtilityError as exc:
        raise HTTPException(400, str(exc))
    return {**u.to_public(),
            "note": "Registered as a callable tool. It runs sandboxed and "
                    "requires approval on every call until promoted to a "
                    "reviewed filesystem utility."}


@app.delete("/v1/utilities/{name}")
def delete_utility(name: str) -> Dict[str, Any]:
    ok = UTILITIES.remove_uploaded(name)
    if not ok:
        raise HTTPException(
            404, "No such uploaded utility (filesystem-managed utilities "
                 "are removed by deleting their directory and reloading, "
                 "not through this endpoint).")
    return {"removed": True}


@app.post("/v1/utilities/reload")
def reload_utilities() -> Dict[str, Any]:
    """Rescan the filesystem utilities directory for new/changed manifests
    -- call after merging a PR that adds one, or wire to a git webhook."""
    count = UTILITIES.reload()
    return {"filesystem_utilities": count}


@app.post("/v1/utilities/scaffold")
def scaffold(req: ScaffoldUtility) -> Dict[str, Any]:
    """Creates utilities/<name>/{utility.yaml, main.py} on disk so a team
    has a starting point to edit and PR -- this endpoint does not itself
    register anything callable until that PR lands and /reload runs."""
    try:
        path = scaffold_utility(req.name, req.description, req.owner)
    except UtilityError as exc:
        raise HTTPException(400, str(exc))
    return {"path": path, "next_step": "Edit main.py, open a PR, then "
                                       "POST /v1/utilities/reload once merged."}
