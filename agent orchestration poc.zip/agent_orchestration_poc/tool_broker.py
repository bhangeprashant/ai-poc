"""
Tool broker — how a farm uses the WHOLE registry.

Hand-authored grant tables (PHASE_GRANTS in farm_speckit.py) work for ten
phases and fall over at fifty services times a growing registry. Nobody
maintains that matrix, so in practice it rots one of two ways: agents get
over-granted "to be safe" (which removes least privilege entirely), or
they get under-granted and every run fails on a missing tool.

The broker derives grants instead, from three inputs:

  1. WHAT THE REGISTRY OFFERS -- list_tools(), including team-published
     utilities, so a newly published utility is discoverable the moment
     it lands without touching a grant table.
  2. WHAT THE GOAL IS ABOUT -- hybrid KG search resolves free-text intent
     to the services/specs actually involved.
  3. WHAT THOSE SERVICES ARE WIRED TO -- the graph's uses_tool edges give
     the candidate tool set for exactly those services.

Then it INTERSECTS with what the phase is permitted to do at all. Two
independent narrowings, and the tighter one wins:

    derived_grants = (tools the work needs) ∩ (tools this role may ever hold)

That intersection is the important part. Derivation alone would let a
goal that mentions "run the tests" pull execution_harness_tool into a
spec-writing agent's grants -- the graph would happily supply it. The
role ceiling stops that. Derivation decides what is NEEDED; the ceiling
decides what is ALLOWED; an agent gets neither more than it needs nor
more than its role permits.

Risk works the same way. The registry's static table says git_tool is
medium always. The graph knows a git write to auth-svc reaches 4 other
services and a write to notify-worker reaches none. The broker escalates
severity by blast radius, so the same tool on a hub service requires a
human where on a leaf it does not.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from approvals import TOOL_RISK, Severity
from knowledge_graph import KnowledgeGraph, KG
from tool_registry import list_tools

SEV_ORDER = {"low": 0, "medium": 1, "high": 2}
SEV_BY_INDEX = ["low", "medium", "high"]

# The ceiling: the widest set of tools a role may EVER hold, regardless of
# what the graph suggests the work needs. Roles are few and change slowly;
# services and tools are many and change constantly. Putting the hand-
# authored boundary here rather than per-(phase x service) is what keeps
# it maintainable.
ROLE_CEILINGS: Dict[str, Set[str]] = {
    "reader":     {"knowledge_search_tool"},
    "analyst":    {"knowledge_search_tool", "jira_tool"},
    "author":     {"knowledge_search_tool", "jira_tool", "speckit-cli"},
    "implementer": {"knowledge_search_tool", "jira_tool", "git_tool",
                    "speckit-cli", "execution_harness_tool"},
    "reviewer":   {"knowledge_search_tool"},
}


@dataclass
class GrantDecision:
    role: str
    goal: str
    resolved_subjects: List[str] = field(default_factory=list)
    candidate_tools: List[str] = field(default_factory=list)
    granted: List[str] = field(default_factory=list)
    withheld_by_ceiling: List[str] = field(default_factory=list)
    unavailable_in_registry: List[str] = field(default_factory=list)
    rationale: str = ""


class ToolBroker:
    def __init__(self, kg: Optional[KnowledgeGraph] = None):
        self.kg = kg or KG

    # ------------------------------------------------------------ discovery
    def registry_catalog(self) -> Dict[str, Dict[str, Any]]:
        """Everything callable right now: built-ins + published utilities."""
        cat: Dict[str, Dict[str, Any]] = {}
        for t in list_tools():
            name = t["name"]
            sev, why = TOOL_RISK.get(name, (None, ""))
            cat[name] = {
                "description": t.get("description", ""),
                "origin": t.get("origin", "built_in"),
                "base_severity": sev.value if sev else self._utility_severity(name),
                "risk_rationale": why,
            }
        return cat

    def _utility_severity(self, name: str) -> str:
        from utility_registry import UTILITIES
        u = UTILITIES.get(name)
        return u.risk if u else "high"

    # ------------------------------------------------------------ derivation
    def derive_grants(self, role: str, goal: str, top_k: int = 6,
                      relevance_floor: float = 0.25) -> GrantDecision:
        ceiling = ROLE_CEILINGS.get(role, ROLE_CEILINGS["reader"])
        catalog = self.registry_catalog()

        hits = self.kg.hybrid_search(goal, kinds=["service", "spec"], top_k=top_k)

        # RRF is rank-based and compresses scores, so the Nth-ranked hit can
        # be nearly irrelevant while scoring within a hair of the first.
        # Ranking alone therefore over-resolves the subject set, which
        # inflates candidate tools and quietly widens the grant. Filter on
        # the RAW lexical score relative to the best hit: a service the goal
        # does not actually mention should not become a subject just because
        # it placed fourth in a five-node graph.
        if hits:
            top_bm25 = max(h["bm25_score"] for h in hits) or 0.0
            if top_bm25 > 0:
                hits = [h for h in hits if h["bm25_score"] >= top_bm25 * relevance_floor]

        subjects = [h["node_id"] for h in hits]

        # A spec resolves to the services that implement it -- otherwise a
        # goal phrased against a spec yields no tools at all. These are
        # STRUCTURALLY implied, so they bypass the relevance floor.
        expanded: List[str] = []
        seen: Set[str] = set()
        for nid in subjects:
            if nid not in seen:
                seen.add(nid)
                expanded.append(nid)
            if nid.startswith("spec:"):
                for impl in self.kg.neighbors(nid, rel="implements", direction="out"):
                    if impl not in seen:
                        seen.add(impl)
                        expanded.append(impl)

        candidates = self.kg.tools_for(expanded)
        granted, withheld, missing = [], [], []
        for t in candidates:
            if t not in catalog:
                missing.append(t)          # graph knows it, registry doesn't offer it
            elif t in ceiling:
                granted.append(t)
            else:
                withheld.append(t)

        # A reader with no graph hits still needs to be able to look things
        # up, or it cannot even report that it found nothing.
        if not granted and "knowledge_search_tool" in ceiling:
            granted = ["knowledge_search_tool"]

        return GrantDecision(
            role=role, goal=goal,
            resolved_subjects=[self.kg.nodes[n].name for n in expanded if n in self.kg.nodes],
            candidate_tools=candidates, granted=sorted(granted),
            withheld_by_ceiling=sorted(withheld),
            unavailable_in_registry=sorted(missing),
            rationale=(f"{len(candidates)} tool(s) wired to the resolved subjects; "
                       f"{len(granted)} within the '{role}' ceiling, "
                       f"{len(withheld)} withheld."),
        )

    # ------------------------------------------------------- risk escalation
    def effective_severity(self, tool: str, subject_node: Optional[str] = None
                           ) -> Tuple[str, str]:
        """Base registry risk, escalated by how far a change would reach."""
        base = self.registry_catalog().get(tool, {}).get("base_severity", "high")
        if not subject_node or subject_node not in self.kg.nodes:
            return base, "No subject resolved; using base registry risk."

        # Read-only tools do not get escalated: reading an auth service that
        # everything depends on is still just a read.
        if base == "low":
            return base, "Read-only tool; blast radius does not apply."

        radius = self.kg.blast_radius(subject_node)
        reached = radius["reached"]
        bump = 1 if reached >= 3 else 0
        idx = min(2, SEV_ORDER.get(base, 2) + bump)
        eff = SEV_BY_INDEX[idx]
        if eff != base:
            why = (f"Escalated {base} -> {eff}: {self.kg.nodes[subject_node].name} "
                   f"has {reached} dependent service(s) ({', '.join(radius['dependents'][:4])}).")
        else:
            why = (f"{self.kg.nodes[subject_node].name} has {reached} dependent(s); "
                   f"no escalation.")
        return eff, why

    # ------------------------------------------------------ shared retrieval
    def context_for(self, goal: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Grounding context any farm agent can pull, findings included.

        Findings recorded by sibling agents rank alongside specs and
        services, so work done once is not redone -- and each carries the
        run and agent that produced it, so a later agent can weigh it.
        """
        return self.kg.hybrid_search(goal, kinds=["service", "spec", "finding"],
                                     top_k=top_k)


BROKER = ToolBroker()
