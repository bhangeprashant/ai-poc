"""
Deployment backends.

Three interchangeable implementations behind one interface, selected by
DEPLOY_BACKEND (simulated | warm_pool | kubernetes):

  SimulatedBackend  - generates the manifest, deploys nothing. Default;
                      lets the whole flow be demoed with no cluster.
  WarmPoolBackend   - a fixed set of generic agent-runtime pods is already
                      running; "creating" an agent means leasing a free
                      pod and pushing the role+tools config into it.
                      Sub-second, no cold start. Recommended for the
                      interactive agent page.
  KubernetesBackend - genuinely applies a Deployment+Service per agent and
                      polls until Ready. Real isolation, 10-30s cold start.
                      Use for heavy/elevated-scope specialist agents.

Every backend must produce the manifest BEFORE anything is applied, since
the human reviewer approves that exact manifest. `plan_manifest()` is
therefore separate from `deploy()`, and `deploy()` takes the approved
manifest as input rather than re-deriving it.
"""

from __future__ import annotations

import os
import threading
import time
import uuid
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from models import AgentSpec

BASE_PORT = int(os.environ.get("AGENT_BASE_PORT", "9000"))
AGENT_IMAGE = os.environ.get("AGENT_IMAGE", "internal-registry/agent-runtime:1.0.0")
DEPLOY_BACKEND = os.environ.get("DEPLOY_BACKEND", "simulated")
READINESS_TIMEOUT = int(os.environ.get("READINESS_TIMEOUT", "120"))


# --------------------------------------------------------------------------
# Manifest generation (backend-independent, approved by the human)
# --------------------------------------------------------------------------

def plan_manifest(spec: AgentSpec, plan: Dict[str, Any], backend: str) -> Dict[str, Any]:
    """Derive the exact deployment manifest from an approved-or-pending plan.

    One Deployment/Service per distinct agent role in the plan. Note the
    image is the SAME for every agent -- specialization happens purely via
    env vars, which is what makes dynamic agent creation cheap (no per-role
    image build).
    """
    roles: List[Dict[str, Any]] = []
    seen = set()
    for step in plan.get("steps", []):
        role = step["agent_role"]
        if role in seen:
            # merge tool grants if a role appears in several steps
            for r in roles:
                if r["role"] == role:
                    r["tools"] = sorted(set(r["tools"]) | set(step["tools"]))
            continue
        seen.add(role)
        roles.append({"role": role, "tools": list(step["tools"])})

    namespace = f"agents-{(spec.name or 'default').lower().replace(' ', '-')}"
    services = []
    for i, r in enumerate(roles):
        port = BASE_PORT + i
        safe_name = r["role"].replace("_", "-")
        services.append({
            "kind": "Deployment",
            "name": safe_name,
            "namespace": namespace,
            "image": AGENT_IMAGE,
            "replicas": 1,
            "container_port": port,
            "env": {
                "AGENT_ROLE": r["role"],
                "AGENT_TOOLS": ",".join(r["tools"]),
                "PARENT_SPEC": spec.name,
                "AGENT_PORT": str(port),
            },
            "resources": {
                "requests": {"cpu": "100m", "memory": "256Mi"},
                "limits": {"cpu": "500m", "memory": "512Mi"},
            },
            "readiness_probe": {"http_get": {"path": "/healthz", "port": port},
                                 "initial_delay_seconds": 3, "period_seconds": 2},
            "service": {"type": "ClusterIP", "port": port, "target_port": port},
        })

    return {
        "cluster": os.environ.get("EKS_CLUSTER_NAME", "aws-eks-agent-cluster"),
        "namespace": namespace,
        "backend": backend,
        "plan_complexity": plan.get("complexity"),
        "services": services,
    }


# --------------------------------------------------------------------------
# Backend interface
# --------------------------------------------------------------------------

class DeploymentBackend(ABC):
    name: str = "base"

    @abstractmethod
    def deploy(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Materialize the approved manifest. Returns an endpoint map:
        {role: {"endpoint": str, "status": str, "instance_id": str}}"""

    @abstractmethod
    def teardown(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> None:
        """Release whatever deploy() acquired. Always called in a finally."""


# --------------------------------------------------------------------------
# Simulated
# --------------------------------------------------------------------------

class SimulatedBackend(DeploymentBackend):
    name = "simulated"

    def deploy(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        endpoints = {}
        for svc in manifest["services"]:
            role = svc["env"]["AGENT_ROLE"]
            instance_id = f"{role}-{uuid.uuid4().hex[:6]}"
            endpoints[role] = {
                "endpoint": f"http://{svc['name']}.{svc['namespace']}.svc.cluster.local:{svc['container_port']}",
                "status": "simulated_ready",
                "instance_id": instance_id,
            }
            trace.append({"agent": "deployer", "action": "simulate_deploy",
                          "output": {"role": role, "instance_id": instance_id}})
        return endpoints

    def teardown(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> None:
        trace.append({"agent": "deployer", "action": "simulate_teardown",
                      "output": {"services": len(manifest["services"])}})


# --------------------------------------------------------------------------
# Warm pool
# --------------------------------------------------------------------------

class WarmPoolBackend(DeploymentBackend):
    """Lease from a pool of already-running generic agent-runtime pods.

    Pool membership comes from WARM_POOL_ENDPOINTS (comma-separated
    base URLs). Each lease pushes {role, tools} to the pod's /configure
    endpoint, so the same pod can serve as a jira_agent on one run and a
    compliance_agent on the next. This is the seamless path: no pod
    creation, no cold start.

    Lease state is MODULE-level, not per-instance: get_backend() constructs
    a fresh backend per run, so instance-level tracking meant two concurrent
    runs would hand the same pod to two different roles and the second
    /configure would silently overwrite the first.
    """

    name = "warm_pool"

    _lease_lock = threading.Lock()
    _globally_leased: Dict[str, str] = {}      # endpoint -> run/instance tag

    def __init__(self) -> None:
        raw = os.environ.get("WARM_POOL_ENDPOINTS", "")
        self.pool = [e.strip() for e in raw.split(",") if e.strip()]
        self._leased: List[str] = []

    @classmethod
    def pool_status(cls) -> Dict[str, Any]:
        raw = os.environ.get("WARM_POOL_ENDPOINTS", "")
        total = len([e for e in raw.split(",") if e.strip()])
        with cls._lease_lock:
            return {"total": total, "leased": len(cls._globally_leased),
                    "free": total - len(cls._globally_leased)}

    def deploy(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        import json as _json
        import urllib.request

        services = manifest["services"]

        # Reserve atomically before any network call, so a concurrent run
        # can't be handed the same endpoints while we're configuring.
        with WarmPoolBackend._lease_lock:
            available = [e for e in self.pool if e not in WarmPoolBackend._globally_leased]
            if len(available) < len(services):
                raise RuntimeError(
                    f"Warm pool exhausted: need {len(services)} agents, {len(available)} free "
                    f"of {len(self.pool)}. Scale the agent-runtime Deployment, or use the "
                    "kubernetes backend for this run."
                )
            reserved = available[:len(services)]
            for ep in reserved:
                WarmPoolBackend._globally_leased[ep] = manifest.get("namespace", "run")
            self._leased = list(reserved)

        endpoints = {}
        try:
            for svc, base_url in zip(services, reserved):
                role = svc["env"]["AGENT_ROLE"]
                tools = svc["env"]["AGENT_TOOLS"].split(",") if svc["env"]["AGENT_TOOLS"] else []
                instance_id = f"{role}-{uuid.uuid4().hex[:6]}"

                payload = _json.dumps({
                    "role": role, "tools": tools, "instance_id": instance_id,
                }).encode()
                req = urllib.request.Request(
                    f"{base_url}/configure", data=payload,
                    headers={"Content-Type": "application/json"}, method="POST",
                )
                urllib.request.urlopen(req, timeout=10).read()

                endpoints[role] = {"endpoint": base_url, "status": "leased",
                                    "instance_id": instance_id}
                trace.append({"agent": "deployer", "action": "lease_warm_pod",
                              "output": {"role": role, "endpoint": base_url,
                                          "instance_id": instance_id}})
        except Exception:
            # a failed configure must not strand the reservation
            self.teardown(manifest, trace)
            raise
        return endpoints

    def teardown(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> None:
        import urllib.request
        for base_url in self._leased:
            try:
                req = urllib.request.Request(f"{base_url}/release", method="POST")
                urllib.request.urlopen(req, timeout=5).read()
            except Exception:  # noqa: BLE001 - teardown must not mask run errors
                pass
        with WarmPoolBackend._lease_lock:
            for ep in self._leased:
                WarmPoolBackend._globally_leased.pop(ep, None)
        trace.append({"agent": "deployer", "action": "release_warm_pods",
                      "output": {"released": len(self._leased)}})
        self._leased = []


# --------------------------------------------------------------------------
# Real Kubernetes
# --------------------------------------------------------------------------

class KubernetesBackend(DeploymentBackend):
    """Actually applies Deployment+Service objects and polls until Ready.

    Requires the `kubernetes` package and either in-cluster config (a
    ServiceAccount bound to a Role that can create deployments/services in
    the target namespace) or a local kubeconfig.
    """

    name = "kubernetes"

    def __init__(self) -> None:
        from kubernetes import client, config  # type: ignore

        try:
            config.load_incluster_config()
        except Exception:  # noqa: BLE001 - local dev fallback
            config.load_kube_config()

        self.apps = client.AppsV1Api()
        self.core = client.CoreV1Api()
        self.client = client
        self._created: List[tuple] = []

    def _ensure_namespace(self, ns: str) -> None:
        try:
            self.core.read_namespace(ns)
        except self.client.exceptions.ApiException as exc:
            if exc.status != 404:
                raise
            self.core.create_namespace(
                self.client.V1Namespace(metadata=self.client.V1ObjectMeta(name=ns))
            )

    def _to_k8s_deployment(self, svc: Dict[str, Any]):
        c = self.client
        env = [c.V1EnvVar(name=k, value=v) for k, v in svc["env"].items()]
        container = c.V1Container(
            name=svc["name"],
            image=svc["image"],
            ports=[c.V1ContainerPort(container_port=svc["container_port"])],
            env=env,
            resources=c.V1ResourceRequirements(
                requests=svc["resources"]["requests"],
                limits=svc["resources"]["limits"],
            ),
            readiness_probe=c.V1Probe(
                http_get=c.V1HTTPGetAction(path="/healthz", port=svc["container_port"]),
                initial_delay_seconds=3, period_seconds=2,
            ),
        )
        labels = {"app": svc["name"], "managed-by": "agent-forge"}
        return c.V1Deployment(
            metadata=c.V1ObjectMeta(name=svc["name"], labels=labels),
            spec=c.V1DeploymentSpec(
                replicas=svc["replicas"],
                selector=c.V1LabelSelector(match_labels=labels),
                template=c.V1PodTemplateSpec(
                    metadata=c.V1ObjectMeta(labels=labels),
                    spec=c.V1PodSpec(containers=[container]),
                ),
            ),
        )

    def _to_k8s_service(self, svc: Dict[str, Any]):
        c = self.client
        return c.V1Service(
            metadata=c.V1ObjectMeta(name=svc["name"]),
            spec=c.V1ServiceSpec(
                selector={"app": svc["name"], "managed-by": "agent-forge"},
                ports=[c.V1ServicePort(port=svc["service"]["port"],
                                        target_port=svc["service"]["target_port"])],
                type=svc["service"]["type"],
            ),
        )

    def _wait_ready(self, name: str, ns: str, trace: List[Dict[str, Any]]) -> str:
        deadline = time.time() + READINESS_TIMEOUT
        while time.time() < deadline:
            dep = self.apps.read_namespaced_deployment_status(name, ns)
            ready = dep.status.ready_replicas or 0
            if ready >= (dep.spec.replicas or 1):
                return "ready"
            time.sleep(2)
        trace.append({"agent": "deployer", "action": "readiness_timeout",
                      "output": {"deployment": name, "namespace": ns}})
        return "timeout"

    def deploy(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> Dict[str, Any]:
        ns = manifest["namespace"]
        self._ensure_namespace(ns)

        endpoints = {}
        for svc in manifest["services"]:
            role = svc["env"]["AGENT_ROLE"]
            self.apps.create_namespaced_deployment(ns, self._to_k8s_deployment(svc))
            self.core.create_namespaced_service(ns, self._to_k8s_service(svc))
            self._created.append((svc["name"], ns))
            trace.append({"agent": "deployer", "action": "apply_manifest",
                          "output": {"deployment": svc["name"], "namespace": ns}})

            status = self._wait_ready(svc["name"], ns, trace)
            endpoints[role] = {
                "endpoint": f"http://{svc['name']}.{ns}.svc.cluster.local:{svc['container_port']}",
                "status": status,
                "instance_id": f"{role}-{uuid.uuid4().hex[:6]}",
            }
        return endpoints

    def teardown(self, manifest: Dict[str, Any], trace: List[Dict[str, Any]]) -> None:
        for name, ns in self._created:
            try:
                self.apps.delete_namespaced_deployment(name, ns)
                self.core.delete_namespaced_service(name, ns)
            except Exception:  # noqa: BLE001
                pass
        trace.append({"agent": "deployer", "action": "teardown",
                      "output": {"deleted": len(self._created)}})
        self._created = []


# --------------------------------------------------------------------------
# Factory
# --------------------------------------------------------------------------

def get_backend(name: Optional[str] = None) -> DeploymentBackend:
    name = name or DEPLOY_BACKEND
    if name == "kubernetes":
        return KubernetesBackend()
    if name == "warm_pool":
        return WarmPoolBackend()
    return SimulatedBackend()
