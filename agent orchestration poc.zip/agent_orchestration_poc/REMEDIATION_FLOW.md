# End-to-End Flow — Automated Vulnerability Remediation

`python remediation_e2e.py`

## The flow

```
 1  CLONE                repo_read_tool                    low   auto-approved
       │
 2  FETCH FINDINGS       security_scanner_tool             low   auto-approved
       │                 Fortify SSC + Sonatype IQ
       │
 3  PRIORITISE           severity → KG blast radius        —     no tool
       │
 4  TRIAGE               read-only agent, no write tools   —     deterministic rules
       │                 ├─ dismissed (FP)
       │                 ├─ escalated (FP but critical) ──────► HUMAN
       │                 └─ actionable
       │
 5  BASELINE             test_runner_tool                  low   auto-approved
       │                 ⚠ must precede any change
       │
 6  SPEC-KIT CHAIN       speckit-cli, per finding          med   auto-approved
       │                 specify → plan → tasks → analyze
       │                 (stops before implement — spec-kit's own gate)
       │
 7  VALIDATE PER FINDING test_runner_tool                  low   auto-approved
       │                 ├─ clean      → publishable
       │                 └─ regressed  → QUARANTINED (does not block others)
       │
 8  REVIEW PACKET        —                                 —     no tool
       │
 9  HUMAN GATE  ◄────────────────────────────────────────────────── blocks here
       │
10  BRANCH/COMMIT/PUSH   repo_publish_tool                 HIGH  gated
       │
11  VERIFICATION RESCAN  security_scanner_tool             low   auto-approved
                         scanner closes the finding, not the tests
```

## Verified run

| Finding | Severity | Outcome |
|---|---|---|
| FTFY-1001 | critical | SQL Injection → validated → **pushed** |
| FTFY-1003 | high | XSS → validated → **pushed** |
| SONA-2201 | critical | jackson-databind bump → **quarantined** (broke serialisation) |
| FTFY-1002 | high | Hardcoded credential in test source → dismissed (FP) |
| SONA-2202 | medium | Dev-only dependency → dismissed (FP) |

Rescan: `verified=True, still_open=none, new_findings=0`.

## What the review pass changed

Three defects found by auditing the pipeline's actual behaviour, none of which were in the original gap list:

### 1. One bad fix sank the whole batch

Regression was validated at batch level, so a single bad fix blocked every clean fix beside it — and the batch got retried as a unit. In practice that means the pipeline ships only when everything is perfect, i.e. never.

`stage_validate_per_finding()` now validates each fix against the **same pre-fix baseline** (not against the previous fix's result, so attribution is real) and quarantines only what actually broke.

**Before:** 3 actionable → 1 regression → 0 shipped.
**After:** 3 actionable → 1 quarantined → **2 shipped**, 1 back for rework.

### 2. No prioritisation

Findings were processed in scanner fetch order, which reflects API pagination, not urgency — a critical waited behind a medium. `prioritise()` sorts by severity, then **KG blast radius** as the tiebreaker, then id for determinism. Two criticals are not equally urgent if one sits in a service four others depend on.

### 3. No resumable state

Everything was in-memory. A crash after push but before rescan lost the fact that code was already published — and a naive retry would branch and push a second time. `save_state()` / `load_state()` persist per-finding stage, baseline, and audit trail.

## Known gaps closed

**`repo_tool` split.** Clone and push shared one tool and therefore one risk tier, forcing the whole thing to `high`. That meant every read-only repo action needed a human — which trains reviewers to rubber-stamp the gate that also guards real pushes. Now `repo_read_tool` (low, auto) and `repo_publish_tool` (high, gated).

**Full spec-kit chain.** `stage_remediate` previously ran `specify` only. It now walks `specify → plan → tasks → analyze` per finding via the A2A bridge, following spec-kit's **own** `auto_send` handoff edges rather than a sequence written here — so if spec-kit changes its phase ordering, this follows automatically. It stops before `implement`, which spec-kit marks non-automatic. For security work that boundary is worth keeping: a plan that patches the wrong sink is cheap to discard, a pushed patch is not.

## Design decisions that survive review

- **Triage first, read-only.** Holds no write tools, so it cannot "fix" what it is judging.
- **Critical + FP rule ≠ auto-dismiss.** The rule may be right; being wrong ships a critical vulnerability that *looks like success*. Verified: same rule auto-dismisses at `high`, escalates at `critical`.
- **Baseline or refuse.** `stage_validate*` raises rather than reporting a comforting number without a pre-fix comparison.
- **Human gates the push, not the commit.** A commit is recoverable; a push publishes the fix *and by implication the vulnerability* to everyone with read access, before deployment.
- **The scanner closes the finding.** Tests passing means nothing broke — only a rescan says the vulnerability is gone.

## Still open

- **`implement` is not wired to real file edits.** The chain produces plans; applying patches and re-running per-finding validation against actual diffs is the next step. Stages 7–11 are built and tested against that future output.
- **Quarantined findings have no rework loop.** They're held with a reason, but nothing re-plans them — currently a human picks them up.
- **FP rules are two hand-written heuristics.** Real triage needs reachability analysis (is the sink reachable from an untrusted source?) plus historical dismissal data. The KG is the right home for both.
- **Rescan trusts the scanner's `resolved_findings`.** A scanner that simply failed to run reports zero new findings and looks identical to success — a real implementation should diff full finding sets across scans.
- **Scanner returns fixture data.** Real calls go in `_security_scanner_handler`; the normalised shape it returns is already what the pipeline consumes.
- **Per-finding validation is sequential.** Fine at 5 findings, slow at 200 — it should fan out across the sandbox pool like every other parallel stage.
