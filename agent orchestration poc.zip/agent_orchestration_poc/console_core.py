"""
Console core: the catalogs and stores behind the chat console.

  personas       role-based system prompts + default tool grants
  model catalog  selectable models with capability/cost hints
  connectors     ecosystem systems the console can reach
  ConversationStore  multi-turn history, per conversation
  ArtifactStore      generated documents and outputs
  MemoryStore        durable facts the user pins for a conversation

All stores are in-memory for the POC. Each has a narrow interface so it
can be swapped for Postgres/DynamoDB without touching the pipeline.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# --------------------------------------------------------------------------
# Personas
# --------------------------------------------------------------------------

@dataclass
class Persona:
    id: str
    label: str
    blurb: str
    system_prompt: str
    default_tools: List[str]
    suggested_prompts: List[str]


PERSONAS: Dict[str, Persona] = {
    "generalist": Persona(
        id="generalist",
        label="Generalist",
        blurb="Broad help across systems, no assumed specialism",
        system_prompt="You are a capable enterprise assistant. Be concise and concrete.",
        default_tools=["knowledge_search_tool"],
        suggested_prompts=[
            "Summarize what changed in the platform this sprint",
            "Draft a status note for leadership",
        ],
    ),
    "engineer": Persona(
        id="engineer",
        label="Engineer",
        blurb="Code, commits, pipelines, and technical debugging",
        system_prompt=(
            "You are a senior platform engineer. Prefer precise technical detail, "
            "name specific files and commands, and flag risk in changes."
        ),
        default_tools=["git_tool", "knowledge_search_tool", "execution_harness_tool"],
        suggested_prompts=[
            "What changed in the auth service last week?",
            "Trace why the nightly job started failing",
        ],
    ),
    "qa": Persona(
        id="qa",
        label="QA / Test",
        blurb="Coverage, regressions, and test strategy",
        system_prompt=(
            "You are a QA lead. Think in terms of coverage gaps, regression risk, "
            "and reproducible steps. Always state what you could not verify."
        ),
        default_tools=["jira_tool", "git_tool", "knowledge_search_tool"],
        suggested_prompts=[
            "Which areas regressed after the last release?",
            "Draft a test plan for the payments change",
        ],
    ),
    "analyst": Persona(
        id="analyst",
        label="Business Analyst",
        blurb="Requirements, tickets, and stakeholder-ready writeups",
        system_prompt=(
            "You are a business analyst. Translate technical detail into clear "
            "business language. Structure output for stakeholders."
        ),
        default_tools=["jira_tool", "knowledge_search_tool"],
        suggested_prompts=[
            "Turn this thread into a requirements doc",
            "Summarize open items by business impact",
        ],
    ),
    "compliance": Persona(
        id="compliance",
        label="Risk & Compliance",
        blurb="Policy checks, controls, and audit evidence",
        system_prompt=(
            "You are a risk and compliance reviewer in a regulated environment. "
            "Cite the control being tested. Never assert compliance you cannot evidence."
        ),
        default_tools=["compliance_tool", "knowledge_search_tool", "jira_tool"],
        suggested_prompts=[
            "Check this change against data-retention policy",
            "Assemble audit evidence for last quarter's releases",
        ],
    ),
}


# --------------------------------------------------------------------------
# Model catalog
# --------------------------------------------------------------------------

MODEL_CATALOG: List[Dict[str, Any]] = [
    {"id": "fast", "label": "Fast", "detail": "Low latency, routine lookups and summaries",
     "context": "200K", "relative_cost": 1},
    {"id": "balanced", "label": "Balanced", "detail": "Default for most multi-step work",
     "context": "200K", "relative_cost": 3, "default": True},
    {"id": "deep", "label": "Deep reasoning", "detail": "Complex orchestration, long analysis",
     "context": "200K", "relative_cost": 8},
]


# --------------------------------------------------------------------------
# Ecosystem connectors
# --------------------------------------------------------------------------

CONNECTORS: List[Dict[str, Any]] = [
    {"id": "jira", "label": "Issue tracker", "status": "connected",
     "scope": "read + comment", "tools": ["jira_tool"]},
    {"id": "vcs", "label": "Source control", "status": "connected",
     "scope": "read", "tools": ["git_tool"]},
    {"id": "kb", "label": "Knowledge base", "status": "connected",
     "scope": "read", "tools": ["knowledge_search_tool"]},
    {"id": "policy", "label": "Policy engine", "status": "connected",
     "scope": "evaluate", "tools": ["compliance_tool"]},
    {"id": "sandbox", "label": "Execution sandbox", "status": "connected",
     "scope": "run code", "tools": ["execution_harness_tool"]},
    {"id": "warehouse", "label": "Data warehouse", "status": "available",
     "scope": "not configured", "tools": []},
    {"id": "itsm", "label": "Service management", "status": "available",
     "scope": "not configured", "tools": []},
]


# --------------------------------------------------------------------------
# Templates
# --------------------------------------------------------------------------

TEMPLATES: List[Dict[str, Any]] = [
    {"id": "status_note", "label": "Status note",
     "prompt": "Write a status note covering progress, risks, and next steps for: "},
    {"id": "test_plan", "label": "Test plan",
     "prompt": "Draft a test plan with scope, cases, and exit criteria for: "},
    {"id": "req_doc", "label": "Requirements doc",
     "prompt": "Produce a requirements document with objectives, scope, and acceptance criteria for: "},
    {"id": "audit_evidence", "label": "Audit evidence pack",
     "prompt": "Assemble an audit evidence summary, naming controls tested, for: "},
    {"id": "rca", "label": "Root cause analysis",
     "prompt": "Write an RCA with timeline, cause, impact, and corrective actions for: "},
]


# --------------------------------------------------------------------------
# Conversations
# --------------------------------------------------------------------------

@dataclass
class Message:
    role: str                       # "user" | "assistant"
    content: str
    ts: float = field(default_factory=time.time)
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Conversation:
    conversation_id: str
    title: str
    persona: str
    model: str
    created_at: float
    messages: List[Message] = field(default_factory=list)
    context_files: List[Dict[str, Any]] = field(default_factory=list)
    memory: List[str] = field(default_factory=list)
    artifacts: List[Dict[str, Any]] = field(default_factory=list)

    def summary(self) -> Dict[str, Any]:
        return {
            "conversation_id": self.conversation_id,
            "title": self.title,
            "persona": self.persona,
            "turns": len([m for m in self.messages if m.role == "user"]),
            "updated_at": self.messages[-1].ts if self.messages else self.created_at,
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conversation_id": self.conversation_id,
            "title": self.title,
            "persona": self.persona,
            "model": self.model,
            "created_at": self.created_at,
            "messages": [
                {"role": m.role, "content": m.content, "ts": m.ts, "meta": m.meta}
                for m in self.messages
            ],
            "context_files": self.context_files,
            "memory": self.memory,
            "artifacts": self.artifacts,
        }


class ConversationStore:
    def __init__(self) -> None:
        self._data: Dict[str, Conversation] = {}
        self._lock = threading.Lock()

    def create(self, persona: str = "generalist", model: str = "balanced",
               title: str = "New conversation") -> Conversation:
        cid = "c_" + uuid.uuid4().hex[:10]
        conv = Conversation(conversation_id=cid, title=title, persona=persona,
                            model=model, created_at=time.time())
        with self._lock:
            self._data[cid] = conv
        return conv

    def get(self, cid: str) -> Optional[Conversation]:
        with self._lock:
            return self._data.get(cid)

    def list(self) -> List[Dict[str, Any]]:
        with self._lock:
            convs = list(self._data.values())
        convs.sort(key=lambda c: c.summary()["updated_at"], reverse=True)
        return [c.summary() for c in convs]

    def delete(self, cid: str) -> bool:
        with self._lock:
            return self._data.pop(cid, None) is not None

    def rename(self, cid: str, title: str) -> bool:
        conv = self.get(cid)
        if conv:
            conv.title = title
            return True
        return False


CONVERSATIONS = ConversationStore()


def title_from_query(query: str) -> str:
    """First few words of the opening question, used as the sidebar label."""
    words = query.strip().split()
    title = " ".join(words[:7])
    return (title[:60] + "…") if len(title) > 60 else (title or "New conversation")
