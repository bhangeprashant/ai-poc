"""
Harness client SDK — what a CALLING AGENT imports.

Hides the parts every caller would otherwise get wrong:

  - SSE framing and reassembly
  - resuming from the last seen seq after a dropped connection, instead of
    restarting the stream and re-processing events
  - answering approval checkpoints without deadlocking the run
  - distinguishing "stream ended because the turn finished" from "stream
    ended because the socket died"

Usage from another agent:

    from harness_client import HarnessClient

    hc = HarnessClient("http://harness:8080", caller="qa_agent")
    session = hc.open_session(granted_tools=["jira_tool", "knowledge_search_tool"])

    for event in hc.run(session, "Find open vendor-risk tickets and summarise"):
        if event["type"] == "tool.started":
            log(f"calling {event['data']['tool']}")
        elif event["type"] == "approval.requested":
            hc.approve(session, event["data"]["checkpoint_id"], approved=True)
        elif event["type"] == "turn.completed":
            return event["data"]["answer"]
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, Iterator, List, Optional


class HarnessError(RuntimeError):
    pass


class HarnessClient:
    def __init__(self, base_url: str, caller: str, timeout: float = 30.0):
        self.base = base_url.rstrip("/")
        self.caller = caller
        self.timeout = timeout

    # ------------------------------------------------------------- plumbing
    def _post(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        req = urllib.request.Request(
            self.base + path, data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            detail = e.read().decode()[:400]
            raise HarnessError(f"POST {path} -> {e.code}: {detail}") from e

    def _get(self, path: str) -> Dict[str, Any]:
        try:
            with urllib.request.urlopen(self.base + path, timeout=self.timeout) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            detail = e.read().decode()[:400]
            raise HarnessError(f"GET {path} -> {e.code}: {detail}") from e

    # ------------------------------------------------------------- sessions
    def open_session(self, granted_tools: List[str],
                     agent_profile: str = "generalist",
                     metadata: Optional[Dict[str, Any]] = None) -> str:
        out = self._post("/v1/sessions", {
            "caller": self.caller, "agent_profile": agent_profile,
            "granted_tools": granted_tools, "metadata": metadata or {},
        })
        return out["session_id"]

    def session(self, sid: str) -> Dict[str, Any]:
        return self._get(f"/v1/sessions/{sid}")

    def seed_memory(self, sid: str, content: str, kind: str = "semantic") -> Dict[str, Any]:
        return self._post(f"/v1/sessions/{sid}/memory",
                          {"kind": kind, "content": content})

    def approve(self, sid: str, checkpoint_id: str, approved: bool = True) -> Dict[str, Any]:
        return self._post(f"/v1/sessions/{sid}/checkpoints/{checkpoint_id}",
                          {"approved": approved, "resolved_by": self.caller})

    def answer(self, sid: str, checkpoint_id: str, text: str) -> Dict[str, Any]:
        return self._post(f"/v1/sessions/{sid}/checkpoints/{checkpoint_id}",
                          {"answer": text, "resolved_by": self.caller})

    # -------------------------------------------------------------- running
    def run(self, sid: str, goal: str,
            reconnect_attempts: int = 5) -> Iterator[Dict[str, Any]]:
        """Submit a goal and yield events until the turn ends.

        Reconnects transparently on a dropped stream, resuming from the last
        seq actually processed -- so a network blip costs latency, not events.
        """
        started = self._post(f"/v1/sessions/{sid}/turns", {"goal": goal})
        after = int(started["stream"].split("after=")[-1])
        attempts = 0

        while True:
            try:
                for ev in self._stream(sid, after):
                    after = max(after, int(ev.get("seq", after)))
                    attempts = 0                 # progress resets the budget
                    yield ev
                    if ev["type"] in ("turn.completed", "turn.failed"):
                        return
                # Clean EOF without a terminal event: the run may still be
                # alive on the server. Check before deciding it's over.
                state = self.session(sid).get("state")
                if state in ("completed", "failed", "cancelled"):
                    return
            except (urllib.error.URLError, ConnectionError, TimeoutError) as exc:
                attempts += 1
                if attempts > reconnect_attempts:
                    raise HarnessError(
                        f"Lost the event stream after {attempts} attempts "
                        f"(last seq {after}). The turn may still be running; "
                        f"poll GET /v1/sessions/{sid}."
                    ) from exc
                time.sleep(min(2 ** attempts * 0.25, 5.0))

    def _stream(self, sid: str, after: int) -> Iterator[Dict[str, Any]]:
        url = f"{self.base}/v1/sessions/{sid}/events?after={after}"
        req = urllib.request.Request(url, headers={"Accept": "text/event-stream"})
        with urllib.request.urlopen(req, timeout=None) as resp:
            buf: List[str] = []
            for raw in resp:
                line = raw.decode("utf-8").rstrip("\n")
                if line.startswith(":"):
                    continue                     # comment / keepalive
                if line == "":
                    payload = None
                    for l in buf:
                        if l.startswith("data: "):
                            payload = l[6:]
                    buf = []
                    if payload:
                        try:
                            yield json.loads(payload)
                        except json.JSONDecodeError:
                            continue
                else:
                    buf.append(line)

    # ------------------------------------------------------------ one-shot
    def invoke(self, goal: str, granted_tools: List[str],
               agent_profile: str = "generalist",
               timeout_s: float = 120.0) -> Dict[str, Any]:
        """Blocking call. Only valid when no granted tool needs approval."""
        return self._post("/v1/invoke", {
            "caller": self.caller, "goal": goal, "agent_profile": agent_profile,
            "granted_tools": granted_tools, "timeout_s": timeout_s,
        })

    # --------------------------------------------------------- convenience
    def run_with_policy(self, sid: str, goal: str,
                        approve_when: Optional[Callable[[Dict[str, Any]], bool]] = None,
                        on_event: Optional[Callable[[Dict[str, Any]], None]] = None
                        ) -> Dict[str, Any]:
        """Run to completion, auto-resolving checkpoints via a caller policy.

        `approve_when` receives the checkpoint payload (tool, params,
        severity) and returns True to approve. Default policy DENIES, because
        an agent that auto-approves everything has removed the control it
        asked the harness to enforce.
        """
        result: Dict[str, Any] = {}
        for ev in self.run(sid, goal):
            if on_event:
                on_event(ev)
            if ev["type"] == "approval.requested":
                data = ev["data"]
                ok = bool(approve_when(data)) if approve_when else False
                self.approve(sid, data["checkpoint_id"], approved=ok)
            elif ev["type"] == "question.asked":
                self.answer(sid, ev["data"]["checkpoint_id"],
                            "No additional detail available from the calling agent.")
            elif ev["type"] in ("turn.completed", "turn.failed"):
                result = ev["data"]
        return result
