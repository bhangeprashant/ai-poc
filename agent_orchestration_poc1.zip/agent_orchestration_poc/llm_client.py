"""
Pluggable LLM client.

If ANTHROPIC_API_KEY is set in the environment, this calls the real Claude
API (structured-JSON prompting, matching the pattern in your Anthropic
API-in-artifacts notes). If no key is present, it falls back to a
deterministic offline heuristic so the whole pipeline is demoable without
any credentials -- useful for a POC walkthrough on a laptop before it's
wired into your Bedrock AgentCore / hosted Claude setup.

Swap `complete_json` for a call into your existing LLM router
(sdlc-platform's LLM router, or Bedrock AgentCore) when you move this out
of POC.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict


_ANTHROPIC_AVAILABLE = False
try:
    import anthropic  # type: ignore
    _ANTHROPIC_AVAILABLE = True
except ImportError:
    pass


# Model tiers -- the actual cost lever, not a cosmetic label. Every
# complete_json() caller in the original harness hardcoded one model for
# every step, which means a one-line classification and a multi-file code
# generation paid the same per-token rate. custom_agent_builder.py routes
# each phase to the cheapest tier that phase's difficulty justifies.
TIER_FAST = "claude-haiku-4-5-20251001"     # intake extraction, triage, validation checks
TIER_STANDARD = "claude-sonnet-4-6"          # spec/plan reasoning, synthesis
TIER_DEEP = "claude-opus-4-6"                # code generation, the one step worth paying for


def _extract_json(text: str) -> Dict[str, Any]:
    text = text.strip()
    text = re.sub(r"^```json\s*|\s*```$", "", text.strip(), flags=re.MULTILINE)
    text = re.sub(r"^```\s*|\s*```$", "", text.strip(), flags=re.MULTILINE)
    return json.loads(text)


def complete_json(system_prompt: str, user_prompt: str, mock_fn,
                  model: str = TIER_STANDARD) -> Dict[str, Any]:
    """Return a structured dict either from the real API or a mock fallback.

    `mock_fn` is a zero-arg callable that produces a plausible offline
    response for the specific agent calling this -- each agent in agents.py
    supplies its own, so the offline mode still demonstrates realistic
    per-agent reasoning instead of one generic canned answer.

    `model` defaults to TIER_STANDARD so every existing caller in this repo
    (agents.py, harness_loop.py) keeps its current behaviour unchanged --
    tiering is opt-in per call site, not a silent global switch.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")

    if api_key and _ANTHROPIC_AVAILABLE:
        try:
            client = anthropic.Anthropic(api_key=api_key)
            response = client.messages.create(
                model=model,
                max_tokens=1000,
                system=system_prompt + "\n\nRespond with ONLY valid JSON, no prose, no markdown fences.",
                messages=[{"role": "user", "content": user_prompt}],
            )
            text = "".join(
                block.text for block in response.content if getattr(block, "type", None) == "text"
            )
            return _extract_json(text)
        except Exception as exc:  # noqa: BLE001 - POC-level fallback
            return {**mock_fn(), "_llm_error_fell_back_to_mock": str(exc)}

    return mock_fn()
