"""
End-to-end demonstration: every persona template, built AND executed.

    python builder_gallery_demo.py

Builds each template through the full six-phase pipeline, then actually
imports and RUNS the generated code. Syntax-checking alone would have
missed the router's empty write-tool bug found earlier -- code that parses
and code that does its job are different claims, and only execution
distinguishes them.
"""

from __future__ import annotations

import ast
import importlib.util
import shutil
from collections import defaultdict
from typing import Any, Dict, List

from custom_agent_builder import AgentBrief, CustomAgentBuilder, TEMPLATES
from harness_context import SKILLS
from knowledge_graph import KG, seed_demo_estate

# Realistic sample payloads per pattern, so execution exercises the branch
# that matters rather than an empty dict that would pass regardless.
SAMPLE_INPUT = {
    "router": {"query": "The checkout page crashes when I click submit"},
    "extractor": {"text": "Customer: Acme Corp\nRequest: SSO support\n"
                           "Urgency: high\nSegment: enterprise\n"
                           "Budget: 50k\nDeadline: Q3\nRequirements: SAML, audit log\n"
                           "Contact: jane@acme.example"},
    "watcher": {"query": "open critical findings"},
    "digest": {"query": "payments-api"},
    "delegate": {"commits": ["feat: add dark mode", "fix: null pointer on login"]},
}


def build_one(builder: CustomAgentBuilder, tmpl: Dict[str, Any]) -> Dict[str, Any]:
    brief = AgentBrief(
        name=tmpl["id"], owner=f"{tmpl['persona'].lower().replace(' / ', '-')}-team",
        goal=tmpl["goal"], inputs=tmpl["inputs"], outputs=tmpl["outputs"],
        data_sensitivity=tmpl["data_sensitivity"],
        expected_volume=tmpl["expected_volume"], latency_need=tmpl["latency_need"],
        pattern=tmpl["pattern"], template_id=tmpl.get("template_id", ""),
        suggested_tools=tmpl.get("suggested_tools", []),
        threshold=tmpl.get("threshold", 0.0), direction=tmpl.get("direction", "above"),
        extract_fields=tmpl.get("extract_fields", []),
        rules=tmpl.get("rules", {}), metric_keys=tmpl.get("metric_keys", []),
    )
    result = builder.run(brief, "What is our data retention window")
    packet = builder.phase_review(result)

    row: Dict[str, Any] = {
        "id": tmpl["id"], "persona": tmpl["persona"], "label": tmpl["label"],
        "pattern": tmpl["pattern"], "code_complete": result.code_complete,
        "blocking": packet["blocking"], "tools": packet["granted_tools"],
        "validation": packet["validation"], "role": packet["role"],
        "cost_1k": packet["estimated_cost_per_1k_runs_usd"],
        "syntax_ok": False, "executed": False, "output": None, "error": "",
        "live_url": "",
    }

    path = f"utilities/{tmpl['id']}/main.py"
    try:
        code = open(path, encoding="utf-8").read()
        ast.parse(code)
        row["syntax_ok"] = True
    except Exception as exc:  # noqa: BLE001
        row["error"] = f"syntax: {exc}"
        return row

    # Execute for real -- the only check that distinguishes "parses" from
    # "works".
    try:
        spec = importlib.util.spec_from_file_location(f"gen_{tmpl['id']}", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        out = mod.run(dict(SAMPLE_INPUT.get(tmpl["pattern"], {})))
        row["executed"] = True
        row["output"] = out
    except Exception as exc:  # noqa: BLE001
        row["error"] = f"runtime: {type(exc).__name__}: {exc}"
        return row

    if not packet["blocking"]:
        try:
            card = builder.phase_go_live(result)
            row["live_url"] = card["url"]
        except Exception as exc:  # noqa: BLE001
            row["error"] = f"go-live: {exc}"
    return row


def main() -> None:
    SKILLS.reload()
    seed_demo_estate(KG)

    for tmpl in TEMPLATES:
        shutil.rmtree(f"utilities/{tmpl['id']}", ignore_errors=True)

    builder = CustomAgentBuilder()
    rows = [build_one(builder, t) for t in TEMPLATES]
    builder.broker.shutdown()

    by_persona: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        by_persona[r["persona"]].append(r)

    for persona, group in by_persona.items():
        print(f"\n{'='*78}\n  {persona.upper()}\n{'='*78}")
        for r in group:
            mark = "OK " if (r["code_complete"] and r["executed"] and not r["blocking"]) else "!! "
            print(f"\n  [{mark}] {r['label']}  ({r['pattern']})")
            print(f"        role={r['role']}  tools={r['tools']}")
            print(f"        code_complete={r['code_complete']}  syntax={r['syntax_ok']}  "
                  f"executed={r['executed']}  blocking={r['blocking']}")
            print(f"        validation={r['validation']}  est ${r['cost_1k']}/1k runs")
            if r["output"] is not None:
                out = str(r["output"])
                print(f"        live output: {out[:110]}{'…' if len(out) > 110 else ''}")
            if r["live_url"]:
                print(f"        LIVE: {r['live_url']}")
            if r["error"]:
                print(f"        ERROR: {r['error']}")

    total = len(rows)
    ok = sum(1 for r in rows if r["code_complete"] and r["executed"] and not r["blocking"])
    print(f"\n{'='*78}\n  SUMMARY\n{'='*78}")
    print(f"  {ok}/{total} built, executed, and went live with complete code")
    print(f"  categories covered: {len(by_persona)}")
    for r in rows:
        if not (r["code_complete"] and r["executed"] and not r["blocking"]):
            print(f"  NOT CLEAN: {r['id']} — {r['error'] or 'blocking'}")


if __name__ == "__main__":
    main()
