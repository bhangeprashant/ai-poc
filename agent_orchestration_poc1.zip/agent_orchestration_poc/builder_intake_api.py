"""
Agent builder intake — the surface a person actually uses.

Closes a gap that was real: `DISCOVERY_QUESTIONS` was a Python list and
`discover()` took a pre-filled dict. There was no way for a human to
supply anything, and the demo hardcoded an AgentBrief without ever
calling discover(). Describing that as a "wizard" was describing a data
structure, not a usable thing.

Two intake paths, ONE validated destination:

    text  ──┐
            ├──> AgentBrief ──> CustomAgentBuilder.run() ──> review packet
    voice ──┘    (validated)     (feasibility gate always runs)

The single destination is the point. A voice path that built its own
brief could drift from the text path's validation, and the phase that
can halt a bad build (phase_understand) would be reachable from one
entry point but not the other.

VOICE IS SCOPED TO ONE FIELD ON PURPOSE. Only `goal` is free text; the
other three questions are single-select. Dictating "internal" into a
three-option picker is strictly worse than tapping it -- slower, and it
adds a transcription error mode to a field that had none. Voice earns
its place on the one field where typing a paragraph is the actual
friction.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from custom_agent_builder import (
    AgentBrief, CustomAgentBuilder, DISCOVERY_QUESTIONS, TEMPLATES,
)
from harness_context import SKILLS
from knowledge_graph import KG, seed_demo_estate
from speech import transcribe, backend_status, STTUnavailable, STT_VOCABULARY

app = FastAPI(title="Agent Builder Intake", version="1.0")

_READY = False

# Keyed by build_id, holds the finished BuildResult from a completed
# /v1/builder/intake call. This is what makes go-live RESUME a reviewed
# build instead of re-running the whole pipeline: without it, go-live had
# to accept the same form fields again and build a second time, which
# means the artifact that ships is a fresh rebuild, not the one the
# reviewer actually looked at -- two runs of the same pipeline are not
# guaranteed identical (a model call, a KG update between runs, a
# different `now()` in a scheduled trigger all diverge them), so this
# was a real correctness gap, not just wasted spend.
#
# In-memory and unbounded -- fine for a demo, wrong for production. See
# the gaps section: this needs a TTL and, ideally, to survive a restart.
_BUILDS: Dict[str, Any] = {}


def _ensure_ready() -> None:
    global _READY
    if not _READY:
        SKILLS.reload()
        seed_demo_estate(KG)
        _READY = True


def _domain_hint() -> str:
    """Seed the STT decoder with THIS estate's real names, pulled from the
    knowledge graph rather than hardcoded.

    This matters more than model size for enterprise speech: a decoder
    that has never seen 'payments-api' or 'ledger-svc' produces confident,
    plausible, wrong tokens for them, and the resulting brief then names a
    service that does not exist -- which research would dutifully fail to
    find, sending the user to debug the wrong thing.
    """
    names: List[str] = []
    for node in KG.nodes.values():
        if node.kind in ("service", "spec"):
            names.append(node.name)
    return ", ".join(STT_VOCABULARY + sorted(set(names)))


class IntakeRequest(BaseModel):
    name: str
    owner: str
    goal: str
    inputs: List[str] = Field(default_factory=list)
    outputs: List[str] = Field(default_factory=list)
    data_sensitivity: str = "internal"
    expected_volume: str = "low"
    latency_need: str = "interactive"
    sample_query: str = "What is our data retention window"
    # Set by a template card; "custom" for a from-scratch build.
    pattern: str = "custom"
    template_id: str = ""
    suggested_tools: List[str] = Field(default_factory=list)
    threshold: float = 0.0
    direction: str = "above"
    extract_fields: List[str] = Field(default_factory=list)
    rules: Dict[str, List[str]] = Field(default_factory=dict)
    metric_keys: List[str] = Field(default_factory=list)


VALID = {
    "data_sensitivity": {"public", "internal", "sensitive"},
    "expected_volume": {"low", "medium", "high"},
    "latency_need": {"interactive", "batch"},
}


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {"ok": True, "speech": backend_status()}


@app.get("/v1/builder/questions")
def questions() -> Dict[str, Any]:
    """The wizard's own definition, served rather than duplicated in the
    HTML -- so adding a question is a one-place change and the UI cannot
    drift from what the builder actually reads."""
    _ensure_ready()
    return {"questions": DISCOVERY_QUESTIONS, "speech": backend_status()}


@app.post("/v1/builder/transcribe")
async def transcribe_goal(file: UploadFile = File(...)) -> Dict[str, Any]:
    """Voice -> text for the goal field ONLY.

    Returns the transcript for the user to review. It is never submitted
    automatically: STT mangles system names often enough that auto-submit
    would routinely start a six-phase build against a goal the user did
    not say.
    """
    _ensure_ready()
    raw = await file.read()
    try:
        out = transcribe(raw, filename=file.filename or "audio.webm",
                         hint=_domain_hint())
    except STTUnavailable as exc:
        # 503 not 500: this is a correctly-reported missing backend or a
        # too-long clip, not a server fault.
        raise HTTPException(503, str(exc))
    return {
        "text": out.get("text", ""),
        "low_confidence": out.get("low_confidence", False),
        "backend": out.get("backend"),
        "review_required": True,
        "note": "Check service names before submitting — speech models "
                "mis-transcribe internal names most often.",
    }


@app.get("/v1/builder/templates")
def templates() -> Dict[str, Any]:
    """The gallery a non-technical user actually starts from. Served
    rather than duplicated in the HTML for the same reason as questions:
    one place to add a persona template, and the UI can't drift from what
    the builder actually knows how to generate complete code for."""
    return {"templates": TEMPLATES}


@app.post("/v1/builder/intake")
def intake(req: IntakeRequest) -> Dict[str, Any]:
    """Both paths converge here. Validation is server-side because the
    HTML wizard is not the only possible caller -- a CLI or another agent
    can POST this, and neither should be able to skip the checks.

    Stores the finished result under a build_id and returns it in the
    packet, so go-live can resume THIS build rather than re-running the
    pipeline from the same form fields.
    """
    _ensure_ready()

    if not req.goal.strip():
        raise HTTPException(400, "goal is required — it's the one field the "
                                 "whole pipeline reasons from.")
    for field_name, allowed in VALID.items():
        val = getattr(req, field_name)
        if val not in allowed:
            raise HTTPException(
                400, f"{field_name}='{val}' is not one of {sorted(allowed)}")

    brief = AgentBrief(
        name=req.name, owner=req.owner, goal=req.goal.strip(),
        inputs=req.inputs, outputs=req.outputs,
        data_sensitivity=req.data_sensitivity,
        expected_volume=req.expected_volume,
        latency_need=req.latency_need,
        pattern=req.pattern, template_id=req.template_id,
        suggested_tools=req.suggested_tools,
        threshold=req.threshold, direction=req.direction,
        extract_fields=req.extract_fields,
        rules=req.rules, metric_keys=req.metric_keys,
    )

    builder = CustomAgentBuilder()
    try:
        result = builder.run(brief, req.sample_query)
        packet = builder.phase_review(result)
        packet["log"] = result.log
        packet["halted_early"] = not bool(result.spec_phases)

        build_id = "build_" + uuid.uuid4().hex[:16]
        _BUILDS[build_id] = result
        packet["build_id"] = build_id
        return packet
    finally:
        builder.broker.shutdown()


@app.post("/v1/builder/go-live/{build_id}")
def go_live(build_id: str) -> Dict[str, Any]:
    """Takes ONLY a build_id -- no form fields. Resumes the exact
    BuildResult that intake produced and the reviewer looked at, rather
    than accepting the same inputs again and building a second time.
    Separate endpoint from intake on purpose: reviewing and publishing
    are different acts, and collapsing them would let one POST put an
    unreviewed agent into production."""
    _ensure_ready()
    result = _BUILDS.get(build_id)
    if result is None:
        raise HTTPException(404, f"No build '{build_id}'. It may have already "
                                 "gone live, or the server restarted (builds "
                                 "are in-memory only in this demo).")

    builder = CustomAgentBuilder()
    try:
        packet = builder.phase_review(result)
        if packet["blocking"]:
            raise HTTPException(
                409, f"Refusing to go live — build is blocking. "
                     f"feasible={packet['feasible']}, "
                     f"validation={packet['validation']}, "
                     f"code_complete={packet['code_complete']}")
        card = builder.phase_go_live(result)
        # One-shot: a build_id that already shipped should not silently
        # ship again on a retried click.
        _BUILDS.pop(build_id, None)
        return {"card": card, "review": packet}
    finally:
        builder.broker.shutdown()


@app.get("/")
def ui() -> FileResponse:
    return FileResponse("static/builder_intake.html")
