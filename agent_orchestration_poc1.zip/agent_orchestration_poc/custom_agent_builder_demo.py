"""
Custom Agent Builder — end to end.

    python custom_agent_builder_demo.py
"""

from __future__ import annotations

import json

from harness_context import SKILLS
from knowledge_graph import KG, seed_demo_estate
from custom_agent_builder import CustomAgentBuilder, AgentBrief, BuildResult, DISCOVERY_QUESTIONS


def banner(n: int, title: str) -> None:
    print(f"\n{'='*72}\n  STAGE {n}  {title}\n{'='*72}")


def main() -> None:
    SKILLS.reload()
    seed_demo_estate(KG)

    banner(1, "Discover — structured intake, not a free-form brief")
    for q in DISCOVERY_QUESTIONS:
        print(f"   ? {q['question']}" + (f"  {q['options']}" if "options" in q else ""))
    brief = AgentBrief(
        name="vuln-digest-agent", owner="security-team",
        goal="Summarise Sonatype/Fortify findings on payments-api into a daily digest",
        inputs=["scanner findings"], outputs=["digest text"],
        data_sensitivity="internal", expected_volume="low", latency_need="batch",
    )
    print(f"\n   brief: {brief.to_prompt_block()}")

    b = CustomAgentBuilder()
    result = BuildResult(brief=brief)

    banner(2, "Research — what already exists (no model call)")
    res = b.phase_research(result)
    print(f"   services touched : {res.touched_services}")
    print(f"   similar agents   : {[a['name'] for a in res.similar_agents] or 'none'}")
    print(f"   duplicate risk   : {res.duplicate_risk}")

    banner(3, "Understand — analyse the brief AGAINST the research")
    u = b.phase_understand(result)
    print(f"   feasible    : {u.feasible}")
    print(f"   gaps        : {u.gaps or 'none'}")
    print(f"   risks       : {u.risks or 'none'}")
    print(f"   assumptions : {u.assumptions or 'none'}")
    if not u.feasible:
        print(f"\n   HALTED: {u.blocking_reason}")
        b.broker.shutdown()
        return

    banner(4, "Structure — organise into the spec BUILD consumes")
    st = b.phase_structure(result)
    for why in st.rationale:
        print(f"   {why}")

    banner(5, "Personalize — spec-kit's own phases, walked via A2A")
    b.phase_specify(result)
    for l in result.log:
        print(f"   {l}")

    banner(6, "Build — deep-tier code gen, KG-derived least-privilege grants")
    b.phase_build(result)
    print(f"   granted: {result.granted_tools}")

    banner(7, "Validate — fast-tier smoke test, auto-approved tools only")
    b.phase_validate(result, "What is our data retention window")
    print(f"   verdict: {result.validation_verdict}")

    banner(8, "Review — one screen, everything needed to say no")
    packet = b.phase_review(result)
    print(json.dumps(packet, indent=2))

    banner(9, "Go live — a real A2A AgentCard, discoverable immediately")
    if packet["blocking"]:
        print("   BLOCKED — not going live.")
    else:
        card = b.phase_go_live(result)
        print(f"   live at {card['url']}")
        print(f"   skills advertised: {card['skills'][0]['tags']}")

    banner(10, "Cost breakdown by phase and model tier")
    for c in result.costs:
        print(f"   {c.phase:20} {c.tier:28} ~${c.est_usd:.4f}/run")
    print(f"\n   total estimate: ~${result.total_est_usd:.4f}/run "
          f"(~${result.total_est_usd*1000:.2f} per 1,000 runs)")

    b.broker.shutdown()


if __name__ == "__main__":
    main()
