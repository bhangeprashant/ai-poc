# Agent Forge — dynamic multi-agent orchestration with a human-in-the-loop gate

A hosted agent page where a user submits their own `agent.md` + a query.
The system understands the request, plans single- vs multi-agent
execution, **stops for human approval**, then deploys the approved agents,
routes work between them over a handoff (A2A) protocol, and tears them
down.

## Run it

```bash
pip install -r requirements.txt
uvicorn api:app --reload --port 8080
```

Open `http://localhost:8080`. Works with **no cluster and no credentials**
(`simulated` backend + offline mock reasoning). Set `ANTHROPIC_API_KEY`
and every agent reasons with the real Claude API instead — no code change.

## The two-phase flow

```
POST /api/runs/plan  {agent_md, query, backend}
   │
   ├─ AgentSpec.parse(agent_md)
   ├─ UnderstandingAgent      domain, intent, complexity
   ├─ PlannerAgent            simple vs multi_agent, PlanStep[] (role + tools)
   ├─ plan_manifest()         the exact Deployment/Service objects
   └─ assess_risk()           per-tool severity + reasons
   │
   ▼
  ┌──────────────── APPROVAL GATE ────────────────┐
  │ state = awaiting_approval                     │
  │ NOTHING deployed. NO tool called yet.         │
  │ Human sees plan + manifest + risk flags and   │
  │ may drop agents / revoke tool grants.         │
  │ Low-risk runs auto-approve and skip the gate. │
  └───────────────────────────────────────────────┘
   │
   ▼
POST /api/runs/{id}/decide  {approved, reviewer, removed_roles, revoked_tools}
   │
   ├─ apply_reviewer_edits()  + RE-DERIVE the manifest from what was approved
   ├─ backend.deploy()        simulated | warm_pool | kubernetes
   ├─ OrchestratorAgent.run() dispatch steps over HandoffEnvelope
   └─ backend.teardown()      always, in a finally
```

## How agents actually get deployed

The key idea: **there is no per-role image.** `Dockerfile` builds ONE
`agent-runtime` image. It reads `AGENT_ROLE` / `AGENT_TOOLS` from env (set
by the manifest) or accepts them at runtime via `POST /configure`, and
becomes that agent. A jira agent and a compliance agent are the same
binary with different env vars — which is what makes creation seamless.

Build and push once:

```bash
docker build -t <acct>.dkr.ecr.<region>.amazonaws.com/agent-runtime:1.0.0 .
docker push  <acct>.dkr.ecr.<region>.amazonaws.com/agent-runtime:1.0.0
export AGENT_IMAGE=<acct>.dkr.ecr.<region>.amazonaws.com/agent-runtime:1.0.0
```

### Three backends (`DEPLOY_BACKEND`)

| Backend | What it does | Cold start | Use for |
|---|---|---|---|
| `simulated` | Generates the manifest, runs agents in-process | none | demos, local dev, CI |
| `warm_pool` | Leases an already-running generic pod, pushes `{role, tools}` to `/configure` | sub-second | the interactive agent page |
| `kubernetes` | Really applies Deployment+Service, polls until `Ready` | 10–30s | heavy / elevated-scope specialists |

`warm_pool` is the recommended default for user-facing runs — dynamic agent
creation happens at the *logical* level (role + tool parameterization),
not by creating infrastructure per request. Configure it with:

```bash
export DEPLOY_BACKEND=warm_pool
export WARM_POOL_ENDPOINTS=http://agent-runtime-0.agents:9000,http://agent-runtime-1.agents:9000
```

For `kubernetes`, the orchestrator pod needs a ServiceAccount bound to a
Role granting `create/delete` on `deployments` and `services` in the target
namespace, plus `pip install kubernetes`.

## Human-in-the-loop details

- **Risk policy** lives in one place: `TOOL_RISK` in `approvals.py`.
  `execution_harness_tool` is high, `jira_tool`/`git_tool` medium,
  read-only tools low. Unclassified tools default to medium — fail closed.
- **Auto-approve** (`AUTO_APPROVE_LOW_RISK=true`) only fires when the
  highest severity across the whole run is `low`. Everything that writes,
  executes code, or touches the cluster hits the gate.
- **Edits are honoured, not just recorded**: dropping an agent prunes its
  steps *and* any dangling `depends_on` referencing them, then the manifest
  is re-derived so what deploys equals what was approved.
- **Approvals expire** after `APPROVAL_TTL_SECONDS` (default 30 min), and a
  run can only be decided once.
- **Tools the author requested but the planner didn't map** are still
  granted an agent — otherwise a high-risk tool could be silently dropped
  and never appear in the risk assessment the human signs off on.

## Files

| File | Purpose |
|---|---|
| `models.py` | `AgentSpec` (agent.md parser), `HandoffEnvelope` (A2A), `Plan`/`PlanStep`, `ToolDefinition` |
| `tool_registry.py` | The skills list: Jira, git, compliance, knowledge search, execution harness |
| `llm_client.py` | Real Claude API if `ANTHROPIC_API_KEY`, else deterministic offline mock |
| `agents.py` | Understanding / Planner / Orchestrator / generic `ExecutorAgent` + `Local`/`Http` dispatchers |
| `approvals.py` | Risk scoring, pending-run store, reviewer-edit application |
| `deployment.py` | `plan_manifest()` + the three backends |
| `orchestrator_pipeline.py` | `plan_run()` / `execute_run()` — the two phases |
| `agent_runtime.py` | The generic agent server that ships in the container |
| `Dockerfile` | The single image all dynamic agents boot into |
| `api.py` | FastAPI: plan, pending queue, status, decide |
| `static/index.html` | Console: agent.md input, risk panel, approval gate, trace |

## Remaining seams to close for production

- **Approval store** is in-memory (`ApprovalStore` in `approvals.py`).
  Swap for DynamoDB/Redis so approvals survive restarts and work across
  orchestrator replicas. The class interface is all the rest depends on.
- **Handoff transport** is an in-process call inside `OrchestratorAgent.run()`
  for `simulated`, HTTP for the others. For durability/retry across pod
  restarts, publish `HandoffEnvelope` to SQS/EventBridge or Redis Streams —
  the envelope schema doesn't change.
- **Tool registry → your MCP servers**: point `run_tool()` at the in-house
  MCP servers instead of the mock handlers; `agents.py` needs no change.
- **LLM calls → Bedrock AgentCore**: replace the Anthropic branch in
  `llm_client.complete_json()`; all three agent types pick it up.
- **Scheduler** is sequential and dependency-respecting. Once steps are
  genuinely independent, `asyncio.gather` over the ready set.
- **Approval notifications**: the reviewer currently has to watch the UI.
  Wire `/api/runs/pending` to Slack/Teams with an approve link.
- **Audit**: the `trace` array is the audit record but is discarded when the
  process dies. Persist it alongside the run for BFSI evidence.

---

# Agent Console (chat landing page)

A second front door onto the same engine: a central-search-bar landing page
with personas, model selection, upload, dictation, multi-turn history, and
two collapsible panels.

```bash
pip install -r requirements.txt
uvicorn console_api:app --reload --port 8080
```

Open `http://localhost:8080`. The workflow-builder console from the first
POC still runs separately via `uvicorn api:app`.

## What each turn does

```
query (typed, dictated, or template)
   │
   ├─ QueryAnalyzerAgent   cleans speech transcripts, resolves "them"/"that"
   │                        against history, extracts entities
   ├─ IntentMapperAgent    routes to exactly one of:
   │                          direct_answer | single_tool
   │                          multi_agent   | document_generation
   ▼
ConsoleOrchestrator
   ├─ direct_answer         responder only, no systems touched
   ├─ single_tool           one registry tool, then synthesis
   ├─ multi_agent           delegates to the EXISTING agent farm
   │                        (PlannerAgent + OrchestratorAgent, unchanged)
   └─ document_generation   agent farm, then structured doc → Outputs panel
```

Every turn emits a **spine** — the ordered list of agents that fired, with
status and per-node timing. It renders under each answer and doubles as the
audit record of what was invoked on the user's behalf.

## Layout

- **Left panel (collapsible)** — conversation history, newest first, with
  turn counts. Click to reopen, × to delete.
- **Center** — landing hero with the central bar, persona chips, and
  persona-specific suggested prompts. After the first turn it becomes the
  message stream.
- **Right panel (collapsible)** — Memory (attached files + pinned facts),
  Tools (with risk badges), Skills (ecosystem connectors + status),
  Templates (click to load a prompt), Outputs (generated documents,
  downloadable).

## Console files

| File | Purpose |
|---|---|
| `console_core.py` | Personas, model catalog, connectors, templates, conversation/artifact stores |
| `chat_pipeline.py` | QueryAnalyzer, IntentMapper, ConsoleOrchestrator, document generator |
| `console_api.py` | FastAPI: bootstrap, conversations, chat, upload, memory, artifacts |
| `static/console.html` | The console UI |

## Notes and limits

- **Dictation** uses the browser's Web Speech API — Chrome/Edge only, and
  audio goes to the browser vendor. For enterprise, record with
  `MediaRecorder` and POST to a self-hosted Whisper behind the same
  endpoint. The analyzer cleans transcripts, but **check system names
  before sending** — that's why the transcript lands in the box for review
  rather than sending automatically.
- **Upload** stores a UTF-8 excerpt only. Wire the `file-reading` path for
  PDF/DOCX extraction.
- **Model selection** currently annotates the turn; it does not yet switch
  the underlying model. Route it through `llm_client.complete_json()` to
  make it functional.
- **Stores are in-memory.** Conversations vanish on restart — move to
  Postgres before anyone relies on history.
- **No approval gate on this path yet.** The console can invoke the agent
  farm directly, including write-scoped tools. Before multi-user, route
  console-initiated multi-agent runs through the same `approvals.py` gate
  the workflow console uses.

---

# Fixes and improvements (latest pass)

## Bugs found and fixed

| # | Bug | Impact | Fix |
|---|---|---|---|
| 1 | Uploaded files and pinned memory never reached any prompt — only filenames did | **Upload was decorative.** Attaching an incident report changed nothing about the answer | `build_context_block()` in `chat_pipeline.py` assembles files + memory into every answering prompt (direct, synthesis, and document generation) |
| 2 | `WarmPoolBackend._leased` was per-instance, but `get_backend()` builds a fresh instance per run | Two concurrent runs leased the **same pods**; the second `/configure` silently overwrote the first, so an agent would answer as the wrong role | Lease state moved to a module-level dict behind a lock, reserved atomically before any network call |
| 3 | `PERSONAS[conv.persona]` unguarded in `_invoke_agent_farm` | `KeyError` → HTTP 500 on any unknown persona | Validated in `run_turn()` against the catalog, and the lookup made defensive |
| 4 | Conversations created via `POST /api/conversations` kept the title "New conversation" forever | Sidebar filled with identical, unusable entries | Retitled from the first real question |
| 5 | No cap on attached context | One large upload silently blew the context window; the LLM call failed at request time | `MAX_CONTEXT_CHARS` budget, newest attachment first, explicit truncation markers |
| 6 | No upload size or count limit | Trivial memory-exhaustion DoS | 5MB per file, 10 files per conversation, clear 400s |
| 7 | No fan-out limit on console-initiated farm runs | One turn could spawn unbounded agents and cost | `MAX_FARM_STEPS` truncates and reports what was dropped on the spine |
| 8 | Failed warm-pool `/configure` stranded the reservation | Pods leaked from the pool until restart | `deploy()` tears down its own reservation on failure |
| 9 | Offline mocks ignored attached context | Fix #1 was invisible without an API key, so it looked broken in demos | Mocks now cite attachments, making the behaviour verifiable offline |

## Dictation: replaced Web Speech API

The Web Speech API was Chrome/Edge only and sent audio to the browser
vendor — unusable in a regulated environment. Replaced with
**MediaRecorder + server-side STT** (`speech.py`):

- **Browser coverage**: Chrome, Firefox, Safari 14.1+, Edge. The client
  negotiates a supported container (`audio/webm` on Chrome/Firefox,
  `audio/mp4` on Safari) and POSTs the blob to `/api/intake/transcribe`.
- **`faster_whisper` (default)** — self-hosted, CPU-capable. **Audio never
  leaves your infrastructure.** Needs `ffmpeg` in the image.
- **`transcribe`** — AWS Transcribe, if you'd rather not host the model.
- **`none`** — no backend configured. The mic dims, the tooltip explains
  why, and `/api/intake/transcribe` returns a 503 with instructions rather
  than failing silently.

Two details that matter more than model size:

- **Domain vocabulary.** `STT_VOCABULARY` in `speech.py` seeds the decoder
  with your system names. This is the highest-leverage accuracy knob for
  enterprise speech — a bigger model still mangles internal acronyms it has
  never seen. Extend it with your real service names.
- **The transcript lands in the input box, never auto-sends.** Low-confidence
  takes are flagged so the user checks names before sending.

Where Web Speech exists, it's still used — but only as a live preview while
recording, so the user sees words appear. The authoritative transcript
always comes from the server.

```bash
# self-hosted (recommended)
apt-get install -y ffmpeg
pip install faster-whisper
export STT_BACKEND=faster_whisper STT_MODEL=distil-large-v3

# or managed
export STT_BACKEND=transcribe AWS_TRANSCRIBE_BUCKET=my-stt-staging
```

## Still open

- **No approval gate on the console path.** The chat console can invoke the
  agent farm directly, including write-scoped tools. Route console
  multi-agent runs through `approvals.py` before multi-user.
- **Model selection still only annotates the turn.** Route it through
  `llm_client.complete_json()` to make it functional.
- **Stores are in-memory** — conversations and approvals vanish on restart.
- **Upload extracts UTF-8 only.** PDF/DOCX need a real extraction path.
- **`ApprovalStore` grows unbounded**; expired runs are marked but never
  evicted.

---

# UX pass — console.html

No backend changes; this only touches `static/console.html`. API contract, routes, and endpoints are unchanged, so nothing else in the repo needed to move.

## What changed

**Feedback and state**
- Replaced the static "thinking" placeholder with a shimmering skeleton row, so a turn feels like it's loading rather than stuck.
- Added a toast system (bottom-center, auto-dismiss) for transient confirmations — attached, transcribed, copied, deleted, failed — separate from the persistent `#hint` line, which is reserved for the routing explanation and recording status.
- Send button shows a spinner while a turn is in flight instead of just disabling.

**Interaction**
- Drag-and-drop file upload directly onto the composer, with a dashed-border drop zone that appears on drag.
- Keyboard shortcuts: `/` or `Cmd/Ctrl+K` focuses the composer from anywhere; `Esc` closes mobile panels. Shown inline as `<kbd>` hints under the composer.
- Conversation search/filter in the left rail.
- Copy-to-clipboard on every assistant response (appears on hover, keyboard-reachable).
- Custom-styled `<select>` controls (persona, model) replacing bare native chrome, plus a persona avatar in the topbar that updates live.

**Visual**
- Refined the existing schematic/instrument identity rather than replacing it: added an elevation scale (`--sh-sm/md/lg`), a consistent radius scale, and a proper motion easing curve used throughout instead of ad hoc transitions.
- Orchestration spine nodes now carry a small `TOOL` / `AGENT` / `PIPE` monospace tag — reads like PCB silkscreen labelling, in keeping with the schematic direction, and makes the trace scannable without color alone.
- Running spine nodes and the recording mic get a proper radar-ping ring instead of a flat opacity pulse.
- Connector status in the Skills tab shows a live pulsing dot for connected systems.
- Empty states got a small dashed-square mark instead of bare text, and consistent copy across all five tabs.
- Persona chips on the landing page stagger in on load; suggested prompts render as quoted examples.

**Accessibility**
- All icon buttons have `aria-label`s; the hint line is `aria-live="polite"` so screen readers announce routing/recording state changes.
- Focus rings preserved and consistent (`:focus-visible`, 2px signal-colored outline) — nothing here relies on hover alone.
- `prefers-reduced-motion` collapses all animation durations to near-zero, including the new shimmer, radar-pings, and toast transitions.

## Verify

```bash
uvicorn console_api:app --reload --port 8080
```

Backend is unchanged from the previous pass — same bootstrap, chat, upload, and transcribe endpoints. If you're diffing, `console.html` is the only file that moved.

---

# Harness Orchestrator

An agent-facing harness service: other agents open a session, submit a goal, and watch the run unfold over SSE in real time — resolving approval checkpoints mid-run.

Structurally modeled on the four lobes in the reference diagram, and on the same architectural idea as TrueForge (TrueFoundry's open-source harness) — a runtime layer around the model that runs the loop, manages context, enforces boundaries, and persists session state across reconnects. TrueForge is TypeScript; this is a native Python implementation reusing the tool registry, risk table, and LLM client already in this repo.

## Files

| File | Role |
|---|---|
| `harness_core.py` | Sessions, event types, resumable event bus |
| `harness_context.py` | **Skills** (procedures, constraints, heuristics) + **Memory** (working/episodic/semantic/personalized, compaction) |
| `harness_loop.py` | The loop: plan → checkpoint → act → evaluate → compact |
| `harness_api.py` | HTTP API + SSE (**Protocols**: agent-agent, agent-user, agent-tools) |
| `harness_client.py` | Python SDK for calling agents |
| `harness_example_caller.py` | Three worked integration patterns |
| `skills/<name>/SKILL.md` | Filesystem-discovered skill packs |

## Run

```bash
uvicorn harness_api:app --port 8080
python harness_example_caller.py
```

## The three things that are enforcement, not prompting

**1. Approval gates block the executing thread.** A write-scoped tool does not dispatch until the caller resolves the checkpoint. Verified: `tool.started` never appears before `approval.resolved` in the event sequence. Prompting a model to "ask before writing" is not a control — a model can decline to follow it.

**2. Tool grants are checked against the session, not the plan.** If the planner emits a call to a tool the session never received, dispatch is refused at the boundary. The plan is untrusted input.

**3. Step and wall-clock budgets are hard.** An agent loop without a ceiling is an unbounded bill and an unbounded outage.

## Real-time delivery to agents, not browsers

The caller is another agent, which changes the streaming design:

- **Every event carries a monotonic `seq`**; callers reattach with `?after=<seq>`. Verified: disconnecting mid-run and resuming yields no duplicates and no gaps.
- **Per-subscriber bounded queues.** A slow caller drops its own oldest events and gets a `stream.gap` marker — it never stalls the run or pins memory for other subscribers.
- **Terminal state is retrievable independently of the stream** (`GET /v1/sessions/{id}`), so a caller that missed everything still gets the result.

## Verdicts a calling agent can act on

The evaluator distinguishes outcomes that look alike but need different responses:

| Verdict | Meaning |
|---|---|
| `ok` | Grounded in tool evidence, no failures |
| `partial` | Some calls succeeded, some failed or were refused |
| `blocked` | **Every** attempted call was refused — a permission outcome, not a finding |
| `ungrounded` | No tool evidence backing the answer |

`blocked` matters: without it, a run where the caller denied everything returns a confident-sounding "nothing found", and the calling agent can't tell "nothing to find" from "I wasn't allowed to look" — only the second is fixed by granting or approving.

## Context engineering

- **Skills load on demand.** Only names + one-line summaries sit in the planning prompt; a skill's body is fetched when selected. Constraints are the exception — always injected *and* enforced in code.
- **Subagents return summaries only.** A subagent can burn ten steps of noisy output and hand back three lines, leaving the parent's working context clean.
- **Compaction folds working context into an episodic summary** at 80% of budget. Without it, every step re-sends every prior observation and token spend grows quadratically with step count.

## API

```
POST /v1/sessions                       open a session, declare tool grants
POST /v1/sessions/{id}/turns            submit a goal (returns immediately)
GET  /v1/sessions/{id}/events?after=N   SSE stream, resumable
POST /v1/sessions/{id}/checkpoints/{c}  resolve approval / answer
GET  /v1/sessions/{id}                  full state, stream-independent
POST /v1/sessions/{id}/memory           seed semantic/personalized memory
POST /v1/invoke                         blocking one-shot (read-only tools only)
GET  /v1/skills  |  /v1/tools  |  /healthz
```

`/v1/invoke` deliberately **refuses** tools that need approval — there is nobody to ask inside a single blocking request, so it errors rather than silently escalating privilege.

## Known limits before production

- **Thread-per-turn and thread-per-SSE-stream.** Uvicorn's default threadpool is 40, so concurrent capacity is roughly 20 simultaneous streamed runs. Move the loop to `asyncio` or a worker queue (Celery/Redis) before real load.
- **All state is in-memory.** Sessions, memory, and checkpoints vanish on restart — the reconnect story only survives client disconnects, not server ones. Postgres for sessions + Redis for the bus is the shape.
- **No authentication.** Any caller can claim any `caller` identity and grant itself any tool. Put mTLS or signed service tokens in front, and derive grants from the caller's identity rather than trusting the request body.
- **Credentials still resolve inside `run_tool()`.** The credential-broker split discussed earlier is not implemented.
- **Skill selection is lexical overlap**, not semantic — fine for a few dozen skills, weak past that.

---

# Sandbox pool — replacing per-user VDI / Sauce Labs with an autoscaled pool

`sandbox_pool.py` + `sandbox_api.py` — a pool of long-lived sandbox pods (browser sessions or code-exec sandboxes) that agents lease on demand, instead of provisioning a VDI or a Sauce Labs-style session per test run. `execution_harness_tool` in `tool_registry.py` now leases from this pool.

## The core design decision: scale on queue depth, not CPU

A browser/VDI session's cost is dominated by cold-start latency (seconds), not compute. By the time CPU crosses a threshold, requests have already been waiting. Queue depth is a leading indicator — it rises the instant demand exceeds capacity, before any pod is even under load. `sandbox_pool.py`'s docstring covers this in more depth.

## Two tiers

- **Warm floor** (`min_replicas`) — always-on pods, leased instantly, zero cold-start on the common path. This is what makes a burst feel free.
- **Reactive burst** (up to `max_replicas`) — new pods scale in from `(active + queued) / capacity_per_replica`, register themselves into the pool on boot, and get drained into first.

## What's enforced, verified by test

- **Backpressure, not infinite waiting.** A queue-full or timeout condition raises `Backpressure` (HTTP 503) with the current capacity in the message, rather than hanging the caller. Same philosophy as the harness's approval timeout.
- **FIFO drain order under concurrent load.** Tested: 5 concurrent requests against a 2-slot pool, 3 more slots register mid-burst → exactly 3 admitted (in arrival order), exactly 2 backpressure, zero orphaned leases.
- **Idle eviction never touches a busy pod**, and only fires after `idle_evict_after_s` past last activity, with separate up/down cooldowns so the pool doesn't flap.

**One real bug found and fixed during testing:** `_try_drain_queue` originally granted a lease without removing the request from the queue, so on the next loop iteration it re-examined the same head-of-queue entry — if capacity remained, it granted a *second*, orphaned lease to an already-satisfied request while every other queued request starved behind it. Fixed by making the pop-and-grant atomic under one lock (`_try_acquire_now_locked`). Verified: exactly 3 of 5 concurrent requests admitted when exactly 3 slots became available, not 1.

## Recommended production path: KEDA, not a Python-driven scaler

`sandbox_pool.py` computes a desired replica count and exposes it at `GET /v1/sandbox/metrics` in Prometheus format — it does **not** call the Kubernetes API itself by default. Point a KEDA `ScaledObject`'s Prometheus trigger at that metric and let KEDA own the actual scaling decision. See `k8s/sandbox-pool-keda.yaml` for a full reference: warm-floor Deployment, `postStart`/`preStop` self-registration hooks, the `ScaledObject` scaling on `sandbox_pool_queue_depth`, and a `PodDisruptionBudget` so a scale-down or node drain never removes the entire warm floor at once.

Rationale for KEDA over raw HPA: HPA scales well on CPU/memory; KEDA scales on external signals (Prometheus metric, queue length) and supports scale-to-zero, which matters for anything with a genuinely idle off-hours window. A `DirectKubernetesBackend` is included in `sandbox_pool.py` for teams not running KEDA, patching replica counts directly from Python — but the metrics-first path is the one that scales past a single team's usage.

## Isolation

One session per pod for browser/VDI work (matches Sauce Labs' model — one browser, one VM/container; a leaked cookie or crashed tab must never be visible to the next agent that leases the slot). A code-exec sandbox can set `capacity` higher per pod if the isolation bar is lower.

## Known gaps before production

- `execution_harness_tool`'s dispatch to the leased endpoint is still simulated — wire it to actually POST `{code, language}` to `lease.endpoint`'s `/execute` route once a real sandbox image is deployed (same shape as `agent_runtime.py`'s existing `/execute`).
- No priority classes — all callers queue FIFO. A production version would let a higher-priority caller (e.g., an interactive user-facing agent) jump ahead of a batch job.
- The pool manager itself (`sandbox-pool-manager` Deployment) should run as a small HA set, not autoscaled — it's cheap and must not be a single point of failure for every lease in the system.

---

# Mobile device execution — extending the sandbox pool

Real mobile devices break the autoscaling assumption the browser/code-exec pool relied on: **you cannot create a physical Pixel or iPhone on demand.** Three device classes, three different scaling stories:

| Class | Scaling | Notes |
|---|---|---|
| Android emulators | **Elastic** — same as browsers | Linux VMs with nested virtualization; autoscales via KEDA like the browser pool |
| iOS simulators | **Elastic, but constrained** | Apple only permits macOS virtualization on Apple hardware — EC2 Mac instances have a 24-hour minimum billing block, so scale-to-zero is expensive to abuse; cold start is minutes, not seconds, so the warm floor matters more here |
| Real devices | **Fixed inventory** | Capacity is physical hardware. The pool's job shifts from autoscaling to fair queueing plus a burst valve to a paid device cloud |

## What changed in `sandbox_pool.py`

- **Capability-based matching**, not just a flat `kind` string. `Replica.capabilities` carries `{platform, os_version, device_model, ...}`; `acquire(..., requirements={...})` matches on a subset of those, so a request for `{"platform": "ios", "device_model": "iPhone15Pro"}` only leases a replica that actually has that hardware.
- **`elastic: bool` per pool.** A fixed pool's `desired_replicas` never exceeds what's physically registered — "desired" becomes a capacity-planning signal ("procure more of this device"), not an instruction an autoscaler can act on. `_tick()` skips scaling entirely for fixed pools; there's nothing to scale.
- **`ExternalDeviceProvider`** — the overflow valve. When a fixed pool's queue is full or a request times out, it can fall back to a paid device cloud (BrowserStack/Sauce Labs/AWS Device Farm) instead of failing outright. `SimulatedExternalDeviceCloud` stands in for a real integration here; a production version calls that provider's session-creation API and returns a `Lease` with `external=True` pointing at the Appium/WebDriver endpoint it hands back.
- **Non-head-of-line-blocking drain.** A queued request for a scarce device (say, one specific iPhone model) must not stall a request behind it that a different, currently-free device could serve immediately. The drain loop scans past an unmatchable head-of-queue entry to satisfy what it can, each grant still atomic under the lock (same fix as the original burst bug — verified this didn't reintroduce it, see tests below).

## Recommended split: one pool per device class

Run separate `SandboxPoolManager` instances — `POOL_BROWSER`, `POOL_ANDROID_EMULATOR`, `POOL_IOS_SIMULATOR`, `POOL_REAL_DEVICE` — matching separate Kubernetes Deployments (or, for real devices, separate host-agent processes on the machines physically wired to the rack). Mixing elastic and fixed capacity in one pool makes the autoscale signal meaningless: `desired_replicas` can't mean both "spin up more pods" and "buy more phones" at once.

```python
POOL_ANDROID_EMULATOR = SandboxPoolManager(min_replicas=3, max_replicas=40, elastic=True)
POOL_IOS_SIMULATOR    = SandboxPoolManager(min_replicas=2, max_replicas=15, elastic=True,
                                            scale_up_cooldown_s=60)   # Mac cold-start is slow
POOL_REAL_DEVICE      = SandboxPoolManager(min_replicas=0, max_replicas=0, elastic=False,
                                            overflow_provider=SimulatedExternalDeviceCloud())
# max_replicas for the real-device pool = however many units are physically racked;
# update it when procurement changes, not via an autoscaler.
```

## Verified

- Capability match: a request for a specific `{platform, device_model}` only leases a matching replica; a device you don't own correctly raises `Backpressure` rather than matching on `kind` alone.
- Fixed pool never reports `desired_replicas` above what's registered.
- Overflow: with a 1-device fixed pool and `max_queue=0`, a second concurrent request correctly routes to the external provider (`lease.external == True`) instead of failing.
- Elastic pools (emulators) are unaffected — same autoscale behavior as the browser pool.
- The original burst-drain fix still holds with the new capability-aware logic (exact admission counts under concurrent load), **and** a head-of-line device request no longer blocks a different, immediately-satisfiable request behind it in the queue.

## Registering a device host agent

A real device needs a small host-agent process (on the machine it's USB-attached to, running Appium or a WebDriverAgent bridge) that calls `POST /v1/sandbox/register` with its capabilities on startup, and `POST /v1/sandbox/deregister/{id}` on clean shutdown:

```bash
curl -X POST http://sandbox-pool:8081/v1/sandbox/register \
  -H 'Content-Type: application/json' \
  -d '{"endpoint":"http://192.168.1.42:4723","capacity":1,"kind":"real_device",
       "capabilities":{"platform":"android","os_version":"14","device_model":"Pixel8"}}'
```

## Still open

- `ExternalDeviceProvider` is a stub. A real integration needs the provider's actual session-creation API, credential handling (their API keys, not device-lab credentials), and cost tracking — overflow sessions are typically billed per-minute and materially more expensive than owned hardware.
- No device health/liveness loop — a device that crashes or gets unplugged stays registered until its host agent notices and deregisters. A heartbeat with automatic eviction on missed pings would close that gap.
- No cost-aware routing between iOS simulator vs. real device vs. external cloud for a request that could be satisfied by any of the three — right now the caller picks the pool.

---

# Team-published utilities — hosting custom Python automation

`utility_registry.py` — teams turn their own Python into a callable harness tool without a platform-team PR for every new automation. Merged into `tool_registry.py`'s `list_tools()`/`run_tool()`, so the planner sees a published utility exactly like a built-in tool.

## Two paths, two trust defaults — deliberately not configurable per-call

| Path | How | Execution | Risk |
|---|---|---|---|
| **Filesystem** | `utilities/<name>/{utility.yaml, main.py}`, merged via normal PR | `trusted: true` in the manifest → **in-process**, no sandbox; `false` → sandboxed | Manifest declares it (`low`/`medium`/`high`) |
| **Uploaded** | `POST /v1/utilities` with code inline, no review step | **Always sandboxed** | **Always `high`**, regardless of what the payload claims |

The asymmetry is the point. A filesystem utility earned a lower risk tier and possibly in-process execution because a PR review is a real trust boundary — someone other than the author looked at the code. An upload endpoint has no such boundary, so letting the uploader self-declare "trust me, this is low risk" would just be arbitrary code execution with extra steps. Verified: uploading a utility that claims to be safe still comes back `risk: high, trusted: false`, and every call requires an approval checkpoint regardless of the tool being explicitly granted to the session — same as any other high-risk tool. A team that wants the lower tier promotes the utility by committing it to the filesystem path instead.

Also verified: an uploaded name cannot shadow an existing filesystem-managed utility — you can't launder a reviewed tool's identity through the self-service path.

## Getting started

```bash
# scaffold a starting point
curl -X POST http://harness:8080/v1/utilities/scaffold \
  -d '{"name":"vendor-risk-scan","owner":"security-team","description":"..."}'
# edit utilities/vendor-risk-scan/main.py, open a PR
# once merged:
curl -X POST http://harness:8080/v1/utilities/reload
```

or self-service, no PR, no filesystem access needed:

```bash
curl -X POST http://harness:8080/v1/utilities \
  -d '{"name":"quick-script","owner":"sre-team","code":"def run(params):\n    return {...}"}'
# -> registered, sandboxed, high risk, requires approval every call
```

## Manifest (`utility.yaml`)

```yaml
name: vendor-risk-scan
version: "1.0"
description: Cross-checks a vendor list against the compliance blocklist.
owner: security-team
trusted: false        # true only for pure functions with zero untrusted-input exec/eval/subprocess risk
risk: medium           # low | medium | high -- feeds the SAME approval gate as built-in tools
entrypoint: main:run
requirements:
  - requests>=2.31
input_schema:
  vendor_names: {type: array, required: true}
```

`main.py` exports one function matching `entrypoint` (`module:function`), taking a `dict` and returning one:

```python
def run(params: dict) -> dict:
    ...
    return {"flagged": [...]}
```

## Execution paths

- **Trusted (in-process)** — the module is imported and the function called directly in the harness process. Fast, no sandbox overhead. Reachable ONLY for filesystem utilities that declare `trusted: true` — this is a real privilege; the example utility (`changelog-formatter`) shows the bar: a pure function, no exec/eval/subprocess/file-write, safe to run with the harness's own credentials.
- **Sandboxed** — leased from the sandbox pool under `kind="python_utility"`, the same mechanism `execution_harness_tool` already uses, so a utility gets the same isolation and the same autoscaled capacity as everything else in that pool. A production dispatch POSTs `{code, entrypoint, params, requirements}` to the leased pod, which installs `requirements.txt` into a fresh venv before calling the entrypoint — simulated here, same as `execution_harness_tool`.

## API

```
GET    /v1/utilities              list published utilities (filesystem + uploaded)
POST   /v1/utilities              self-service upload -- always sandboxed, always high risk
DELETE /v1/utilities/{name}       remove an UPLOADED utility (filesystem ones: delete the dir + reload)
POST   /v1/utilities/reload       rescan the filesystem directory (wire to a git webhook)
POST   /v1/utilities/scaffold     generate a utility.yaml + main.py starting point
```

## Verified

- Filesystem discovery picks up a new `utility.yaml`/`main.py` pair without code changes.
- Trusted in-process execution runs the actual function and returns its result.
- Missing required `input_schema` fields are caught before the utility runs, not inside it.
- A low-risk, trusted, filesystem-reviewed utility runs with **zero** approval checkpoints (`AUTO_APPROVE_LOW` applies to utilities exactly as it does to built-in tools).
- A high-risk uploaded utility raises an approval checkpoint on every call, even when explicitly granted to the session — confirmed via the full harness loop, not just the registry in isolation.
- `list_tools()`/`is_known_tool()` correctly cover both built-ins and utilities — an earlier pass at this only checked the built-in registry, which would have made every utility dispatch fail with `unknown_tool` despite being listed and grantable. Caught and fixed before shipping, not discovered by a user.

## Known gaps before production

- Sandboxed dispatch is simulated, same caveat as `execution_harness_tool` — needs a real `/execute` endpoint on the `python_utility`-kind sandbox pods that installs `requirements.txt` and calls the entrypoint.
- No dependency vetting — a filesystem utility's `requirements` list is trusted as-is once merged; a malicious or vulnerable package added in a PR is only as safe as your code review, same as any dependency in the main repo.
- No per-utility rate limiting or cost accounting — a runaway utility can be called as often as any built-in tool.
- Uploaded utilities are in-memory only (`UtilityRegistry._uploaded`) and vanish on restart — persist to a database before relying on this for anything long-lived.

---

# Running Spec Kit inside the harness — no Copilot dependency

**Short answer: yes.** GitHub Spec Kit was never tied to Copilot models. Verified by actually installing `specify-cli` and running `specify init --integration generic` — the generated command files are plain markdown with no agent or vendor named anywhere in them, and the scaffolding scripts are plain bash. Spec Kit's own docs confirm it: 30+ supported agent integrations as of v0.11, plus a `generic` mode for bringing your own.

## What Spec Kit actually is, once you look inside it

Two halves, cleanly separated:

- **Reasoning** — `/speckit.constitution`, `/speckit.specify`, `/speckit.clarify`, `/speckit.plan`, `/speckit.tasks`, `/speckit.analyze`, `/speckit.checklist`, `/speckit.implement`, `/speckit.converge` — each is a markdown prompt template. Whatever LLM reads it does the actual thinking. Nothing in the frontmatter or body names Copilot, Claude, or any other vendor.
- **Mechanics** — `.specify/scripts/bash/{create-new-feature,setup-plan,setup-tasks,check-prerequisites}.sh` — plain bash that creates branches, scaffolds directories, and resolves templates. No model involved at all.

That split maps onto the harness's own architecture almost exactly:

| Spec Kit half | Harness layer |
|---|---|
| Markdown reasoning templates | **Skills** (`skills/speckit.<phase>/SKILL.md`) |
| Bash scaffolding scripts | **Utility** (`utilities/speckit-cli/`), dispatched sandboxed |
| Project constitution | A `constraint`-kind skill — same enforcement path as any other harness constraint |

## What's actually in the repo

- `skills/speckit.<phase>/SKILL.md` × 10 — generated by running the real `specify init --integration generic` and copying its output verbatim into harness-schema frontmatter. The body is GitHub's actual prompt engineering, unedited. `speckit.constitution` is classified `kind: constraint` rather than `procedure` — its whole job is "non-negotiable project principles," which is exactly what the harness's constraint mechanism already models, so it gets the same always-injected, always-enforced treatment as any other constraint.
- `utilities/speckit-cli/` — wraps spec-kit's real bash scripts (bundled verbatim under `dotspecify/`) behind a harness utility. `trusted: false`, `risk: medium` — it writes files and creates branches in a real repo, so it runs sandboxed and sits behind the same approval gate as any other write-capable tool.

## Verified, not asserted

- **The real scripts actually work**, run directly: `create-new-feature.sh` against a scratch git repo produced a numbered branch name and a real `spec.md` at the path spec-kit itself expects — not a simulation of the mechanism, the actual mechanism.
- **Discovery**: `SKILLS.reload()` picks up all 10 phases; `speckit.constitution` correctly lands as a constraint, the rest as procedures.
- **Full harness loop**: a session granted only `speckit-cli` correctly raises a **medium**-severity approval checkpoint (matching the manifest), blocks dispatch until resolved, then routes through the sandbox pool exactly like any other utility.
- **Schema validation catches a bad call honestly**: the offline planner mock (no API key in this sandbox) calls tools with a generic `{query: ...}` shape; the utility's own `input_schema` correctly rejected the missing `phase`/`repo_dir` and the run reported `partial` rather than silently succeeding. With a real model behind `llm_client.py`, the planner reads the tool's actual schema from `list_tools()` and supplies real params — confirmed separately by calling `dispatch_tool` directly with correctly-shaped params, which completed cleanly through the full approval-gate-then-sandbox-lease path.

## What this buys you over running Spec Kit through an editor

- **The harness's LLM backend is whatever you've wired into `llm_client.py`** — your internal gateway, a specific model, whatever. Spec Kit itself never talks to a model; it only supplies text and scripts. There was never a Copilot dependency to remove — you're just supplying the reasoning from a different place.
- **Every write action Spec Kit's `implement` phase would take is now approval-gated**, not just editor-trusted. That's new: Spec Kit inside an editor runs at whatever trust level you gave the editor's agent. Inside the harness, `speckit-cli`'s medium risk means every scaffolding call pauses for a real decision.
- **A calling agent can drive the whole spec → plan → tasks → implement flow programmatically** via the harness's session/event-stream API, watching each phase happen in real time and resolving checkpoints — not something an editor-bound workflow supports.

## Known gaps

- Only the four scriptable phases (`specify`, `plan`, `tasks`, `check`) are wired into `speckit-cli`'s dispatcher. The reasoning-only phases (`clarify`, `analyze`, `implement`, `converge`, `checklist`) are pure skill-guided model output with no deterministic script backing them — that's correct per Spec Kit's own design, not a gap, but worth knowing before expecting `speckit-cli` to run `implement`.
- `speckit.taskstoissues` references GitHub's MCP server tools (`list_issues`, `issue_write`) in its own frontmatter — that's an optional connector dependency, not a model dependency, and isn't wired into this harness's tool registry yet.
- The sandbox dispatch for `speckit-cli` is still simulated inside the harness (same caveat as every other sandboxed tool in this repo) — the real script execution was proven by calling it directly, not through the harness's current sandbox stub.

---

# Agent farms — top 5 use cases, implemented

`farm_core.py` + `farm_scenarios.py`. Run all five: `python farm_scenarios.py`, or one: `python farm_scenarios.py 3`.

A single agent needs a loop and a gate. A **farm** needs three things a single agent never does, and those three things are what make the harness worth having at multi-agent scale:

1. **One approval plane.** With 20 agents running, nobody sits on 20 event streams resolving checkpoints by hand.
2. **Fair access to scarce capacity.** A 200-run batch regression must not starve the one interactive agent a human is waiting on.
3. **Cross-agent attribution.** When something writes to production, "an agent did it" is not an answer.

The farm layer **only decides and observes**. Agents still go through `HarnessRun`, still hit the same gate, still lease from the same pool — the farm never becomes a way around controls the harness already enforces.

## The PolicyBroker

Declarative rules, first match wins. The critical property: **the default is escalate, never approve.** A broker that auto-approves what it doesn't recognise is the gate removed with extra steps.

Verified: unknown caller/tool/severity combinations at `medium` and `high` all resolve to `escalate`; a `deny` rule placed before a broad `approve` rule correctly wins. Escalated checkpoints park in `pending_escalations` and the agent **stays blocked** — an unresolved high-risk action stalls rather than proceeding.

## The five scenarios

| # | Scenario | What it proves | Result |
|---|---|---|---|
| 1 | **Release readiness gate** | 4 specialists, one decision plane | 2 auto-approved, 1 policy-denied, 1 escalated to a named human — all in one audit trail |
| 2 | **Cross-repo SDD rollout** | Shared skills + enforced constitution across N repos | 3 repos, all 10 speckit skills + 4 constraints applied identically to every agent |
| 3 | **Incident triage swarm** | Context isolation + honest aggregation | 3 investigators `ok`, 1 policy-denied → farm verdict **`blocked`**, not `ok` |
| 4 | **Mobile regression fleet** | Contention for fixed physical capacity | 6 agents, 2 devices → 4 served by rack, 2 overflowed to cloud, **0 hangs** |
| 5 | **Shared utility plane** | Risk tier travels with the tool | Low-risk reviewed utility runs friction-free; uploaded utility gated **even for its author** |

### Scenario 3 is the one to look at

Three investigators succeeded and one was policy-denied, so the farm reports **`blocked`** rather than `ok`. A farm that averaged to "mostly fine" would be claiming incident coverage it does not have. `aggregate()` enforces this: a farm result is only as trustworthy as its weakest member.

### Scenario 5's real point

The `sre_team` agent calling `adhoc-log-parser` — a utility that team uploaded itself — still hit an escalation, because uploads are forced to `high` risk by the registry regardless of author. **Authorship is not authorisation.**

## Per-agent grants, not one broad grant

`FarmCoordinator.dispatch()` gives each agent its **own** session with its **own** tool grants. A QA agent that needs read access does not inherit write scope because a sibling agent needed it. Scenario 1 shows this concretely: `security_agent` holds `execution_harness_tool` and is denied it by policy, while `qa_agent` never had it to begin with.

## A reporting bug found and fixed during testing

Scenario 5 initially reported `auto-approved: 0`, which read as a broken rule. It wasn't: a low-risk reviewed utility never reaches the broker at all — the harness auto-approves at dispatch via `AUTO_APPROVE_LOW`, so no checkpoint is ever raised. Counting broker approvals alone misreported the friction-free path as a missing approval. Fixed to report gating status per utility (`_requires_approval`) rather than inferring it from broker traffic. Worth flagging because the same mistake in a real dashboard would make a working control look broken — and someone would "fix" it by loosening the policy.

## Known gaps

- **No priority classes in the pool yet.** Scenario 4 queues FIFO; a real farm wants the interactive agent ahead of the batch job. The pool's queue is the right place for it, unimplemented.
- **The broker polls** (150ms) rather than subscribing to the event stream. Fine at this scale, wasteful at hundreds of sessions — it should consume `approval.requested` events directly.
- **Escalations have no timeout or notification path.** A parked checkpoint blocks its agent indefinitely with nobody told. Needs to page someone and expire.
- **`aggregate()` is verdict-only.** It doesn't weigh which hypothesis went unchecked — in scenario 3, losing the exec investigator may matter far more or far less than losing the KB search, and the farm can't currently tell.

---

# Spec Kit agents in a farm

`farm_speckit.py` + `farm_speckit_demo.py`. Run: `python farm_speckit_demo.py`

## Spec Kit is already an agent graph — it says so itself

Every generated spec-kit command carries handoff frontmatter using spec-kit's own key, `agent:`:

```yaml
handoffs:
  - label: Create Tasks
    agent: speckit.tasks     # spec-kit's word, not ours
    send: true               # automatic edge — no human in between
```

Read that out of all ten phases and you get a routing table:

```
constitution ──> specify ──> plan ══> tasks ══> analyze
                   │           │        │
                   └> clarify  └> checklist  └> implement

══>  auto_send: true   (advances freely)
──>  auto_send: false  (a human or policy decides)
```

**My first conversion dropped this.** Stripping spec-kit's frontmatter to fit the harness skill schema threw away the `handoffs:` block — harmless when one agent drives all phases in sequence, but in a farm that block *is* the routing table. Recovered it into the skill frontmatter; `load_handoff_graph()` now reads the topology back out.

## Why phase-per-agent beats one agent running all phases

An editor runs every spec-kit phase as one agent in one session. A farm can separate three things that collapse together there:

**1. Least privilege per phase.** The grants genuinely differ, and an editor agent holds their union for the whole session:

| Phase | Grants |
|---|---|
| `specify` / `plan` / `tasks` | `speckit-cli`, `knowledge_search_tool` |
| `analyze` / `checklist` | `knowledge_search_tool` **only** |
| `implement` | `git_tool`, `execution_harness_tool`, `jira_tool` |

A spec-writing agent physically cannot execute code. Verified in pattern B: write-capable tools held by any critic — **none**.

**2. Independent review.** `analyze` and `checklist` critique what `specify`/`plan` produced. Run as one agent, the reviewer critiques its own reasoning with every prior justification still in context. As separate farm agents with separate sessions, the critic sees the artifacts, not the rationale that produced them — and is read-only by grant, so a reviewer cannot edit what it reviews.

**3. Fan-out.** One approved plan drives N repos, each with its own implement agent, own checkpoints, own failure surface.

## The three patterns, run for real

| Pattern | Result |
|---|---|
| **A. Handoff-driven pipeline** | Followed spec-kit's auto edges `plan ══> tasks ══> analyze`, then **stopped before `implement`** — spec-kit marks that edge non-automatic, and the farm honours it |
| **B. Parallel independent critics** | `analyze` + `checklist` ran concurrently in separate sessions, both `ok`, both holding zero write-capable tools |
| **C. Fan-out across 3 repos** | 3 parallel escalations → 2 approved, 1 rejected → 2 repos `ok`, 1 `blocked`, farm aggregate honestly `blocked` |

Pattern A's stop is the interesting one: the pipeline advances only across edges spec-kit itself marked `send: true`, and halts at `tasks --> implement`. Spec-kit marked that edge non-automatic because a human is meant to decide whether a plan becomes code. The farm reads that from the artifact rather than from a rule we invented.

Pattern C shows per-repo isolation: rejecting `notify-worker` left the other two completing `ok`. The farm aggregate is `blocked` rather than "2 of 3 fine" — one repo genuinely did not ship, and averaging that away would misreport the rollout.

## A narration bug caught in testing

Pattern C originally printed "every repo hit the execution-harness denial." The audit said otherwise: all three **escalated** on `git_tool`, which falls through to human review — the deny rule for `execution_harness_tool` never fired because the planner reached for git first. The demo also never resolved the escalations, so all three sat `awaiting_approval` and the aggregate was `unknown`. Fixed both: the demo now resolves escalations as an on-call reviewer would, and the narration describes what actually happened. Worth flagging because a demo that narrates a control firing when it didn't is worse than no demo — it builds confidence in an enforcement path nobody exercised.

## Known gaps

- `run_from()` follows only the **first** auto edge at each node. `plan` has two outgoing edges (`tasks` auto, `checklist` gated); a fuller implementation would fan out across all auto edges concurrently rather than walking a single chain.
- Gated edges stop the pipeline entirely rather than raising a checkpoint the broker can resolve. Routing decisions should go through the same approval plane as tool calls — right now they are a hard stop.
- `PHASE_GRANTS` is hand-authored. It should be derived from what each phase's SKILL.md actually needs, or at minimum validated against it, so a phase that starts needing a new tool fails loudly rather than silently under-granted.

---

# Centralised hybrid knowledge graph + using the whole tool registry

`knowledge_graph.py` (hybrid retrieval + graph) and `tool_broker.py` (registry → grants). Demo: `python farm_kg_demo.py`

Mirrors the retrieval stack already in use — semantic chunks in a vector store plus BM25, fused with RRF, over a code/dependency graph. Swap `_vector_score` and the node loader for real ChromaDB / codegraph calls and everything else stands.

## Why a farm needs the graph specifically

Three jobs no single agent has:

### 1. Grant derivation replaces the hand-authored table

`PHASE_GRANTS` in `farm_speckit.py` is hand-written. That works for ten phases and dies at ~50 services × a growing registry — the matrix rots one of two ways: agents get over-granted "to be safe" (least privilege gone) or under-granted (every run fails on a missing tool).

The broker derives instead, from three inputs: what the registry offers (`list_tools()`, **including team-published utilities**, so a new utility is discoverable the moment it lands), what the goal is about (hybrid search resolves free text to real services/specs), and what those services are wired to (`uses_tool` edges).

Then it **intersects with a role ceiling**:

```
derived_grants = (tools the work needs) ∩ (tools this role may ever hold)
```

The intersection matters. Derivation alone would let a goal mentioning "run the tests" pull `execution_harness_tool` into a spec-writing agent — the graph would happily supply it. Derivation decides what's *needed*; the ceiling decides what's *allowed*. Roles are few and change slowly; services and tools are many and change constantly, so the hand-authored boundary lives on roles, not on (phase × service).

Verified — same goal, different roles, and a different goal resolving elsewhere entirely:

| Goal | Role | Granted |
|---|---|---|
| refund reversal | reviewer | `knowledge_search_tool` |
| refund reversal | implementer | `git_tool`, `jira_tool`, `knowledge_search_tool` |
| MFA step-up | implementer | `execution_harness_tool`, `git_tool`, `knowledge_search_tool` |

### 2. Blast radius becomes risk

The registry says `git_tool` is medium, always. But a git write to a leaf service is not the same action as one to an auth service 14 services depend on. The graph knows the difference:

| Target | Dependents | Effective severity | Policy outcome |
|---|---|---|---|
| `notify-worker` | 0 | medium | approve |
| `payments-api` | 2 | medium | approve |
| `auth-svc` | 4 | **high** | **escalate to human** |

Same tool, same registry entry, different real risk. A static table can't express this — it either gates every git write (nobody ships) or gates none (auth-svc goes unguarded). Read-only tools are explicitly **not** escalated: reading a hub service is still just a read.

### 3. Findings shared across agents, with provenance

One agent's discovery shouldn't leave siblings to rediscover it. `record_finding()` writes findings as graph nodes attributed to the run and agent that produced them, so they rank alongside specs and services in retrieval — and a later agent can weigh them, because the source travels along. A finding with no provenance is an unsourced claim.

## Two bugs found by testing, not by reading

**Blast radius direction.** `blast_radius()` walks *incoming* `depends_on` edges: if B depends on A, changing A reaches B. Getting this backwards is the classic error and it fails silently in the worst direction — reporting a leaf service as high-impact and an auth service as safe. Verified explicitly: `auth-svc` → 4 dependents, `notify-worker` → 0.

**RRF over-resolution widened grants.** `derive_grants` first took the top-k fused hits directly, and the subject list came back with a duplicate plus two services the goal never mentioned. Cause: RRF is rank-based and compresses scores — the 4th hit scored 0.0313 against the 1st at 0.0328, near-identical despite being irrelevant in a 5-node graph. **Ranking without a relevance floor silently inflated the candidate tool set, which silently widened the grant.** Fixed by carrying raw `bm25_score`/`vector_score` through the fused result and filtering subjects at 25% of the top lexical score; spec→service expansion bypasses the floor since those are structurally implied. Worth flagging: this is a security-relevant bug that presents as a cosmetic one — the demo still "worked," it just quietly granted more than it should.

## Known gaps

- `_vector_score` is token-overlap cosine, a deliberately weak proxy so the fusion path is testable without a model. Real embeddings change result quality substantially; the RRF code doesn't change.
- The relevance floor (0.25 of top BM25) is a tuned constant on a 5-node demo graph. On a real estate it needs validating against known-good resolutions, not assuming.
- `ROLE_CEILINGS` is still hand-authored — deliberately, since roles are the slow-changing axis, but it's the one table that must stay correct for the intersection to mean anything.
- Graph is in-memory and seeded from a demo fixture. The real integration point is `seed_demo_estate()` → codegraph/ChromaDB loaders.
- Blast radius counts dependents but doesn't weight them. Reaching 4 batch consumers is not the same as reaching 1 customer-facing payment path.

---

# A2A protocol — spec-kit agents as discoverable, delegatable A2A agents

`a2a_bridge.py`. A2A (Agent2Agent, Linux Foundation, v1.0 2026) standardises three things — AgentCards for discovery, Tasks with a defined lifecycle, and Messages/Artifacts over JSON-RPC + SSE. The harness already has close analogues of all three; this is the translation layer, not a reimplementation.

## The mapping is close enough that it's barely a mapping

```
Harness SessionState          A2A TaskState
---------------------          -------------
idle                       ->  submitted
running                    ->  working
awaiting_approval          ->  input-required   <-- same concept
awaiting_answer            ->  input-required   <-- same concept
completed                  ->  completed
failed                     ->  failed
cancelled                  ->  canceled
```

`awaiting_approval -> input-required` is the actual payoff. A2A defines `input-required` as a first-class state specifically for "the task needs something from the caller before it can continue" — precisely what an approval checkpoint already is. **An external A2A client, built on any framework that speaks the protocol, sees a standards-compliant signal to intervene, not a harness-specific concept it has to special-case.**

## Spec Kit phases become individually addressable A2A agents

`agent_card_for_phase()` builds a real AgentCard sourced from the phase's actual `SKILL.md` (not a hand-written description that can drift) plus a `next_agents` field read from spec-kit's own recovered handoff graph, carried in the card's `extensions` slot:

```json
"extensions": [{
  "uri": "urn:speckit:handoffs",
  "params": {"next_agents": [{"agent": "speckit.tasks", "automatic": true}]}
}]
```

This is the actual answer to "can I use spec-kit for A2A": **a coordinator that has never heard of spec-kit can still discover the next hop** by reading the card of the agent it just finished talking to, the same way it discovers anything else about an agent it just met. `next_hop()` does exactly that lookup — no spec-kit-specific knowledge required on the caller's side.

## Verified: a real multi-agent chain, driven entirely by cards, not a hardcoded sequence

```
[0] speckit.plan     -> completed  (contextId=ctx_be7a2e72)
[1] speckit.tasks    -> completed  (contextId=ctx_be7a2e72)
[2] speckit.analyze  -> completed  (contextId=ctx_be7a2e72)
    no automatic next hop from speckit.analyze — coordinator decides
    (spec-kit marked this edge non-automatic)
```

Three separate agents, one shared `contextId` (A2A's own field name) correlating the whole flow, and the chain **stopped exactly where spec-kit itself marks the edge as needing a decision** — read off the card, not a rule invented for this bridge.

## Streaming rides the harness's existing resumable bus

`stream_task()` wraps `EventBus.stream()` — the same seq-based, reconnect-safe stream proven earlier in this repo — and translates harness events into A2A's two streaming kinds (`status-update`, `artifact-update`). Internal events with no A2A equivalent (`plan.drafted`, `step.started`) are dropped rather than forced into a shape the protocol doesn't define; a real A2A client wouldn't know what to do with them anyway.

## A real race, found by testing a chain, not a single call

A single send-then-resolve call looked correct in isolation. Chaining three agents exposed a genuine TOCTOU: `resolve_input_required` raised `ValueError` when a client's poll caught a transiently stale `input-required` read microseconds before the *previous* resolution's background thread finished advancing the task to `completed`. Traced it precisely — debug output showed the session already at `completed` with zero unresolved checkpoints at the exact moment the bridge insisted the task was still `input-required`.

This isn't a test artifact to route around — it's a normal A2A scenario. A client that polled `tasks/get`, saw `input-required`, and is now sending its follow-up is *racing the task's own progress by construction*. Fixed by making `resolve_input_required` idempotent: if nothing is left to resolve, it returns the task's current state rather than raising, and only surfaces a real error when the task genuinely never had a checkpoint to resolve. Re-ran the three-agent chain after the fix — clean, no exceptions, correct terminal states throughout.

## Known gaps

- No JSON-RPC 2.0 transport wrapper yet — `send_message`/`get_task`/etc. are the right shapes but aren't exposed over HTTP as A2A's spec requires (POST to the AgentCard's `url`, `application/json`, SSE for streaming methods). That's a thin FastAPI layer away, not a redesign.
- `cancel_task()` marks the session cancelled but has no way to actually stop the background thread mid-run — honest gap, not silently pretended-around.
- No `AgentCardSignature` (JWS-signed cards per the spec) — fine for an internal farm, necessary before any external org's agents are meant to trust these cards.
- `securitySchemes` in the card is an empty stub — real auth (OAuth2/mTLS per A2A's model) isn't wired in.

---

# Automated vulnerability remediation (A2A + Spec Kit)

`vuln_remediation.py` + `vuln_remediation_demo.py`. Run: `python vuln_remediation_demo.py`

```
clone → fetch findings → TRIAGE (FP first) → baseline → per-finding spec-kit
      → validate → regression gate → HUMAN REVIEW → branch/commit/push → rescan
```

New registry tools: `security_scanner_tool` (Fortify SSC / Sonatype IQ fetch + rescan, **low** risk — read-only), `test_runner_tool` (**low**), `repo_tool` (**high**).

## Four decisions worth defending

### 1. Triage runs first, as a separate read-only agent

Scanners over-report. Feeding raw findings into the implement loop burns the expensive stage on noise and — worse — produces "fixes" for things that were never broken: churn in security-sensitive code with zero security benefit. Triage is the cheapest discriminating step, so it goes first, and it holds **no write tools**, so it cannot start fixing what it is supposed to be judging.

FP rules are deterministic and auditable, not prompts. A rule that can be stated exactly shouldn't be model reasoning.

**But a deterministic FP rule firing on a `critical` finding does not auto-dismiss.** The rule may well be right; the cost of being wrong is a shipped critical vulnerability that *looks like success*. Those route to a human instead. Verified: same `test-scope-credential` rule auto-dismisses at `high` and escalates at `critical`.

### 2. Regression is diffed against a pre-fix baseline, not asserted

"No regression" is unfalsifiable without knowing what passed before. `stage_baseline()` runs **before any code changes**, and `stage_validate()` **refuses to run at all** without one rather than reporting a comforting number:

```
RuntimeError: No baseline captured. Refusing to report on regressions without
a pre-fix comparison — 'no regression' would be unfalsifiable.
```

`test_runner_tool` returns per-test outcomes, not a pass/fail summary, because a bare "4 of 5 passed" cannot tell you whether *the same* 4 passed. Verified both directions: a pre-existing failure does **not** block the pipeline; a pass→fail flip **does**, even with the suite mostly green.

### 3. Human review gates the push, not the commit

Committing locally is recoverable. Pushing publishes the fix **and, by implication, the vulnerability** to everyone with read access, before the fix is deployed. That's the irreversible step, so that's where the human goes. `repo_tool` is rated on its **worst** action (push), not its average — a clone and a push do not belong in the same risk tier.

### 4. A fix is done when the scanner agrees, not when tests pass

Tests passing means nothing broke. Only the rescan can say the vulnerability is gone. `stage_rescan()` cross-checks which findings the scanner actually resolved against which ones were meant to be fixed, and reports `still_open` explicitly.

## Verified — both paths

**Blocking path** (the demo's default): 5 findings → 2 dismissed as FPs, 3 actionable → specs drafted → regression detected (`SerializationTest.testJacksonRoundTrip` flipped pass→fail) → **publish unreachable**, stages 8–9 never execute, reviewer rejects. This is the correct outcome — a pipeline that pushed here would ship a regression.

**Clean path**: identical baseline and post-fix results → non-blocking → branch created → commit `f9e8d7c` → pushed to `origin/security/remediation-batch-1` → rescan `verified=True, still_open=none`.

Five safety properties tested independently of the demo, since the demo's own path exercised only some of them: critical-FP escalation, non-critical FP dismissal, pre-existing failure tolerance, pass→fail detection, and baseline refusal.

## Known gaps

- **`repo_tool` should be split.** Clone/branch/commit/push share one tool and therefore one risk tier, forcing the whole thing to `high`. Splitting `repo_read_tool` from `repo_publish_tool` would let clone auto-approve while push stays gated. Noted rather than silently rated as if already done.
- **The implement stage drafts specs but does not patch code.** `stage_remediate` runs `speckit.specify` per finding; wiring `speckit.plan → tasks → implement` with real file edits is the next step. The regression gate and publish stages are built and tested against that future output.
- **FP rules are two hand-written heuristics.** Real triage needs reachability analysis (is the sink actually reachable from an untrusted source?) and historical dismissal data — the KG is the right home for both.
- **Rescan trusts the scanner's `resolved_findings` response.** A real implementation should diff full finding sets across scans, since a scanner that simply failed to run would report zero new findings and look identical to success.
- The scanner tool returns fixture data. Real Fortify SSC (`/api/v1/projectVersions/{id}/issues`) and Sonatype IQ (`/api/v2/applications/{app}/reports`) calls go in `_security_scanner_handler`; the normalised shape it returns is already what the pipeline consumes.

---

# Architect Agent — multi-agent HLD/LLD/diagram generation from a real repo

`architect_agent.py` + `architect_orchestrator.py` + `architect_agent_demo.py`. Run: `python architect_agent_demo.py <repo_path> <repo_name>`

Takes a repo, ingests it for real (AST-parsed code + markdown docs, not fixtures), and produces HLD, LLD, a draw.io diagram, a mermaid UML diagram, and an HTML diagram — all generated by sub-agents under one orchestrator, with live streaming progress over the harness's own `EventBus`, ending in one downloadable zip.

```
Orchestrator
 ├─ CodeIngestAgent    -- ast-walks the repo: real modules, classes, functions, import edges
 ├─ DocIngestAgent     -- ingests README/markdown as searchable KG nodes
 ├─ ArchitectureAnalystAgent -- clusters modules into components from the real graph
 ├─ HLDAgent           -- one synthesis doc for the whole system
 ├─ LLDAgent × N        -- one doc PER COMPONENT, in parallel
 └─ DiagramAgent       -- draw.io + mermaid UML + HTML, from the SAME graph as the docs
```

## Why the docs and diagrams can't disagree

Every artifact — HLD, LLD, the `.drawio`, the mermaid UML, the HTML — is built from **one `KnowledgeGraph` instance**, read four different ways. A diagram that contradicts the doc next to it is the single most common failure of hand-maintained architecture documentation. That can't happen here because there's only one source of truth.

## Component clustering went through two wrong versions before this one — found by running it, not by reasoning about it

**v1 — prefix split** (module name up to its first underscore): produced 22 near-meaningless "components" — `agent`, `agents`, `api`, `chat`, `console` as separate one-file components. Wrong in a way only visible from the actual edges: `console_api` depends on `approvals`, `chat_pipeline`, `speech`, *and* `tool_registry`, but prefix-splitting kept all of those as disconnected components. A diagram hiding real coupling is worse than no diagram — it looks authoritative while being wrong.

**v2 — plain connected-components** over every `depends_on` edge: overcorrected. A handful of widely-imported modules (`harness_core`: fan-in 9, `tool_registry`: 8, `models`: 6) bridge almost the entire graph transitively, collapsing 34 of 36 modules into one blob.

**v3 (shipped)** — excludes high fan-in modules (≥4 dependents) from the clustering edges entirely, grouping them into their own `core` component instead. That's not a workaround, it's an honest architectural claim: this repo genuinely has a shared foundation layer. Result on this repo: **9 components** — `core` (11 modules, blast radius 20), `agents` (the real Phase-4 console/chat/speech/tool cluster, correctly merged), `vuln_remediation`, `architect_agent`, `farm_kg_demo`, and four small standalone entry points, `harness_client` correctly isolated with zero dependencies — matching the isolation this repo's own README already documents about it.

## Verified, not asserted

- Ran against this repo itself: 37 modules, 87 dependency edges, 13 docs ingested, 9 components, all 9 LLDs generated in parallel with zero failures.
- `.drawio` output checked for referential integrity (every edge's source/target resolves) — 9 vertices, 7 edges, zero broken refs.
- `architecture.html` screenshotted, not just read — renders cleanly, no overlaps.
- Live progress genuinely streams over `EventBus`, the same resumable seq-numbered stream used for every other agent run in this repo — not a separate progress mechanism built just for this.

## Known gaps

- LLD/HLD narrative text uses the offline mock when no API key is set (same pattern as every other generator in this repo) — the mock's phrasing is serviceable but plain; a real model produces meaningfully better prose from the same grounded data.
- Component naming (`name_cluster`) picks the highest-degree module in a cluster as its label — reasonable, but a real name a human would choose (e.g. "Console Frontend") isn't derivable from the graph alone.
- No incremental re-run — a second build on a changed repo starts from scratch rather than diffing against the previous graph.
- Doc-to-component association (`doc_refs`) is a crude substring match on the component name against doc text; real linkage would need the same hybrid search already built in `tool_broker.py`, not applied here yet.

---

# Custom Agent Builder — recommend, let the user override, orchestrator finalizes

`agent_builder.py` + `agent_builder_api.py` + `agent_builder.html`. Run: `uvicorn agent_builder_api:app --port 8080`, open `/`.

For a farm with a large tool catalog and a real knowledge base, hand-authoring which tools/KB access/execution capability each new custom agent gets doesn't scale — the same problem `tool_broker.py` solved for grant derivation, applied one step earlier: **before the agent exists at all.**

```
User describes a goal (free text)
        │
        ▼
RECOMMENDER   -- searches the tool catalog + KG, proposes tools / KB / execution
        │         with a stated confidence and a reason for each
        ▼
THE USER      -- sees every recommendation as an editable checkbox/toggle,
        │         pre-ticked but never locked
        ▼
ORCHESTRATOR  -- takes the CONFIRMED selection, computes runtime approval
                 gating, sandbox routing, final grant list
```

**Three actors, three different jobs, on purpose.** The recommender's output never becomes the orchestrator's input directly — the user's confirmed selection sits between them. A recommendation the user never saw or could veto isn't customization, it's the system deciding with extra steps.

## Two real bugs found by testing the recommender against an obviously-wrong goal, not by reading it

**No stopword filtering in the shared KG's BM25.** Asked it to recommend tools for *"Compose a birthday poem for my coworker"* — it confidently returned `test_runner_tool`, `compliance_tool`, and **`repo_publish_tool` (high risk)**. Traced it token by token: the only words shared between the goal and `test_runner_tool`'s description were `"a"` and `"for"` — pure function words. Fixed by adding stopword filtering to `knowledge_graph.py`'s tokenizer (used by every consumer — `tool_broker.py`, `architect_agent.py` — not just this), plus an absolute BM25 floor as defense-in-depth on top of the existing relative-to-top floor, since a relative floor alone has a hole when the top score itself is noise.

**The same fix also repaired a false negative.** `jira_tool` wasn't being recommended for a goal that literally said "check jira" — the tokenizer kept `"jira_tool"` as one indivisible token, so it never matched the query word `"jira"`. Now splits underscored identifiers into component words at index time, so both exact-identifier and natural-language search work against the same index.

**Substring language detection.** A goal mentioning "commit the fix" got `C` detected as a requested language, because `"c" in goal_text` matches the letter inside "commit". Fixed with word-boundary tokenization.

## What's genuinely still a limitation, not a bug

Lexical matching has no negation handling. *"Just search jira, nothing about code"* still recommends `execution_harness_tool`, because its description contains the word "code" and BM25 can't tell "about code" from "nothing about code" apart. Documented rather than patched — a real fix means routing goal interpretation through `llm_client.complete_json` (the same offline-mock-with-real-API-fallback pattern every other generator in this repo already uses), not another keyword special case.

## Verified

- Real goal → real, correctly-risk-tagged tools (`jira_tool` medium, `execution_harness_tool` high) with visible per-tool rationale.
- Unrelated goal → **zero** tools recommended, explicit warning shown, rather than a confident wrong guess.
- Orchestrator finalize: unknown/deleted tools are dropped and reported, not silently ignored; gated-vs-auto-approved split matches the harness's own severity table exactly — this form cannot loosen it.
- Full 4-step wizard screenshotted end to end: describe → tools (search + pre-ticked suggestions) → KB/execution toggles with confidence banners → review with per-tool gating badges → success.

## Known gaps

- Tool catalog here is the repo's real ~11 tools; the UI (search, scroll, badges) is built to the shape a 200+ catalog needs, not tested at that scale.
- No persistence — `finalize()` returns a manifest; wiring it to actually call `SESSIONS.create()` / register a `FarmAgent` is the next step, not yet done.
- KB/harness detection is pure lexical heuristic, same limitation as above — negation and implication aren't understood.

---

# Worked example — a Jira + Confluence + GitLab agent

`release_notes_agent_demo.py`. Run: `python release_notes_agent_demo.py`

Concrete enterprise case: *"For the payments-api 2.14 release: pull the Jira tickets in the release, cross-check them against merged GitLab merge requests, and publish a release notes page to the Confluence ENG space."*

Three systems, five tools, three risk tiers — built through the agent builder, then **actually executed** through the harness with real gating.

## The tools, split read-vs-publish

| Tool | Risk | Why |
|---|---|---|
| `jira_tool` | medium | Read + comment on tickets |
| `confluence_read_tool` | low | Wiki search, runbook read |
| `confluence_publish_tool` | **high** | Org-wide instantly, notifies watchers, **no review step between write and visibility** |
| `gitlab_read_tool` | low | MRs, pipelines, commits |
| `gitlab_publish_tool` | **high** | Opens MRs, tags releases |

Confluence publish is rated **above** a code push, deliberately: a git commit gets reviewed before anyone sees it, a published wiki page does not.

## The bug this example exposed

`gitlab_publish_tool` was ranked **first** and pre-ticked for a goal that only says *"cross-check against merged merge requests"* — reading, not writing. Cause: its description contains "merge request" and "release", both prominent in the goal, so pure lexical similarity scored the write tool above the read tool.

**Similarity to a tool's description is not evidence its write capability is wanted.** Silently pre-ticking write access is the highest-consequence failure this form can have — a user skimming checkboxes grants it without noticing.

Fixed in three passes, each caught by testing rather than reading:

1. **Write-intent gating** — a high-risk tool is only pre-ticked if the goal contains an actual write verb. Failed immediately: `"merged"` contains `"merge"`, so a read-shaped goal registered as write intent (the same substring-vs-word-boundary bug as `"c"` in `"commit"` earlier).
2. **Word-boundary matching + dropped ambiguous verbs** — `"merge"`, `"tag"`, `"comment"` are nouns as often as verbs in this domain. Still failed: goal-level intent is too coarse, so one `"publish"` anywhere turned on *every* high-risk tool including GitLab's.
3. **Per-system proximity** — a write verb only counts for a tool if that tool's system terms appear within ~80 chars after it, which is where a verb's object sits in an imperative clause.

Verified across four goal shapes: Confluence-only write ticks only Confluence; GitLab-only ticks only GitLab; both-writes ticks both; read-only ticks neither.

Also fixed: the catalog rendered in raw registry order, burying the relevant tools below unrelated ones — tolerable at 15 tools, unusable at 200. Suggested tools now sort to the top.

## What the run actually does

```
reads (auto-approved)  jira_tool → gitlab_read_tool → confluence_read_tool
cross-check            2 merged MRs matched to PROJ-101 / PROJ-142
                       1 open MR flagged (PROJ-155, unmerged at cut)
HUMAN GATE             confluence_publish_tool (high) — escalated, blocks
publish                page 901288, 34 watchers notified
```

Verified: all three reads complete **before** any checkpoint appears, and `published yet: False` while the gate is open. The audit trail shows `jira_tool (medium) = approve [jira-medium]` and `confluence_publish_tool (high) = escalate [default]`.

The generated page cross-references every MR to its Jira ticket and includes a **"NOT included — still open at cut"** section. That section is the point: a release note that silently omits unmerged work reads as complete, which is the failure that actually bites.

## Known gaps

- Write-intent detection is proximity heuristics on English text. It fails toward *not* pre-ticking, which is the safe direction, but the honest fix is an LLM parse of the goal — the pattern already exists in `llm_client.complete_json`, just not wired here.
- `TOOL_SYSTEM_TERMS` is hand-maintained per write-capable tool. A new publish tool with no entry falls back to goal-level intent.
- Tool handlers return fixture data shaped like the real APIs (`/rest/api/content`, `/api/v4/projects/:id/merge_requests`). Swapping in real REST calls is a handler change only.

---

# Custom Agent Builder — client need to live agent

`custom_agent_builder.py` + `custom_agent_builder_demo.py`. Run: `python custom_agent_builder_demo.py`

Mirrors the shape of the n8n proposal-automation reference (Research → Understand → Personalize → Structure → Automate), but the thing produced is an **agent**, not a document — and it's built entirely on this repo's actual harness/farm/speckit/A2A/KG machinery, not a new workflow engine.

```
DISCOVER   short structured intake, cheapest model tier
   |       -> AgentBrief (compact — nobody re-reads raw conversation again)
SPECIFY    speckit.specify -> plan -> tasks -> analyze, via the A2A bridge
   |       ("personalized" the way spec-kit personalizes any feature)
BUILD      ONE deep-tier call generates the code; grants DERIVED from the
   |       knowledge graph, never hand-written
VALIDATE   smoke test via the real harness loop, cheapest tier,
   |       scoped to auto-approved tools only
REVIEW     one screen: tools, cost estimate, validation verdict
   |
GO LIVE    registers a real A2A AgentCard — discoverable immediately
```

## Every phase states its model tier and why

Added three tiers to `llm_client.py` (`TIER_FAST`/`TIER_STANDARD`/`TIER_DEEP`), backward-compatible — every existing caller in the repo keeps its current behaviour since `model` defaults to `TIER_STANDARD`. This is the actual cost lever, not a label:

| Phase | Tier | Why |
|---|---|---|
| Discover | — (structured Q&A, no model call) | Extraction has a cost only when there's ambiguity to resolve. A 4-field wizard has none. |
| Specify/Plan/Tasks/Analyze | Standard | Real synthesis, not classification — earns more than fast, doesn't need deep. |
| Build | **Deep** | The one phase where a weaker model produces code that looks plausible and is wrong. The only phase worth paying for. |
| Validate | Fast | "Did it run and return something grounded" is a classification of a result, not new reasoning. |

Measured on the demo run: **$0.047/run**, of which **49%** is the single Build call. Everything else — four spec-kit phases plus validation — is the other half. That ratio is the point: cost concentrates where difficulty concentrates, not uniformly across every phase.

## Grants are derived, never hand-written

`phase_build` calls `tool_broker.derive_grants(role, brief.goal)` — the same KG-driven least-privilege mechanism built earlier in this repo. The role ceiling (`author` vs `implementer`) caps what the generated agent can ever hold, independent of what the brief's goal text happens to mention. Verified: `implementer` + a payments-api goal resolves to exactly the tools that service is wired to in the graph, nothing more.

## UX: a wizard, not an essay

`DISCOVERY_QUESTIONS` is four targeted questions (one free-text goal, three single-select), not an open text box. This is the 'Understand' step from the reference, done by asking rather than inferring — cheaper to process (no extraction step) and removes the risk of the model guessing at a requirement nobody stated.

## Two real bugs found by running the pipeline, not by reading it

**The spec chain stopped after one phase.** `phase_specify` originally assumed `specify → plan` was an automatic handoff edge and followed only `auto_send` edges. Checked spec-kit's actual graph rather than the assumption: `specify → plan` is marked **non-automatic** in spec-kit's own frontmatter — it's a point spec-kit intends a human to steer from. Fixed by walking `specify → plan → tasks` as this builder's own explicit sequence (one review gate for the whole build, not four), while still following spec-kit's real automatic edge (`tasks → analyze`) via `next_hop()` rather than hardcoding it — a future spec-kit graph change is still picked up automatically.

**Validation hung until timeout, reporting a false "unknown."** The smoke-test session was granted the full tool set including `git_tool` (high risk). The harness planner picked it, raised an approval checkpoint, and nothing in the validation phase resolves checkpoints — so the session sat at `awaiting_approval` for the full timeout. Fixed by scoping validation to the **auto-approved subset** of granted tools only: a smoke test's job is "does this run and produce something grounded," not exercising write-path approval, which is what the live agent's own gate is for. Also fixed the failure mode itself — a timeout now reports `timed_out (awaiting_approval)` and `validated=False` explicitly, rather than silently returning `unknown` from an empty result.

## Verified — full run

```
grants derived: ['git_tool', 'jira_tool', 'knowledge_search_tool']
validation verdict=ok
LIVE: True → https://harness.internal/a2a/vuln-digest-agent
```

`phase_go_live` refuses to run at all when `validated=False` — checked explicitly, not just documented.

## A note on workspace hygiene

This repo's working directory contained `agent_builder.py`, `architect_agent.py`, and related files with no record of being built in this project's history — evidently left over from something else sharing this filesystem. They weren't touched, read for design ideas, or built upon; `custom_agent_builder.py` is named distinctly specifically to avoid any confusion with unfamiliar code of unverified origin.

## Known gaps

- `phase_build` generates one function body from a single deep-tier call. A real build would iterate (generate → test → refine), which costs more but catches what one shot misses.
- Cost estimates are rough token counts (`chars // 4`), not measured usage — good enough to catch a wildly under/over-scoped agent before go-live, not a bill. See `claude_api_vs_copilot_cost_model.xlsx` for the fuller model.
- `phase_go_live` registers a card but doesn't add the new agent to a `PolicyBroker`'s rules — it's discoverable via A2A but not yet part of an automated farm's routing.
- No rework loop for a `blocked` review packet — same gap as the vulnerability remediation pipeline's quarantine path.

---

# Custom Agent Builder — verification against the five reference phases

Audited the first version against the reference's five phases. **Two of the five were not actually built:**

| Reference phase | First version | Now |
|---|---|---|
| **RESEARCH** | *nothing* | `phase_research` — KG hybrid search + duplicate detection |
| **UNDERSTAND** | `discover()` copied a dict into a dataclass; a docstring called it "the Understand step" | `phase_understand` — real analysis that **can block** |
| **PERSONALIZE** | `phase_specify` (spec-kit) | unchanged |
| **STRUCTURE** | implicit inside `phase_build` | `phase_structure` — explicit, with rationale |
| **AUTOMATE** | `phase_go_live` | unchanged |

The UNDERSTAND gap is the one worth naming plainly: the original docstring argued the wizard *was* the understanding step "done by asking rather than guessing." That was a rationalization for a function that performed zero analysis. Nothing could ever come back infeasible, and no gap was surfaced before code generation.

## RESEARCH — finds reasons *not* to build

The most expensive outcome in an agent builder is shipping the fourth agent that does what three existing ones already do. Nobody notices until the registry is unmanageable, and by then each has its own grants, cost, and failure surface.

`phase_research` queries the KG (services, specs, prior findings) and the utility registry, then scores term overlap against every published agent. **Deliberately makes no model call** — this is retrieval and set comparison, and paying a model to redo what hybrid search already did is the reflexive spend that makes these pipelines expensive for no accuracy gain.

## UNDERSTAND — can halt the pipeline

Deterministic checks run first (a rule that can be stated exactly should not be a prompt), then a Standard-tier call for the judgement that genuinely needs reasoning. A deterministic block is **never** overridden by the model's opinion:

```python
u.feasible = u.feasible and bool(out.get("feasible", True))
```

**Verified — a near-duplicate halts before any generation spend:**
```
research: 1 service(s), 1 similar agent(s), duplicate_risk=likely
HALTED at understand: An agent named 'vuln-digest-agent' already covers this goal.
reached build? False          spec phases run? []
```

Gaps and risks are surfaced but do **not** auto-block — they're for the human to weigh. Only infeasibility or failed validation blocks. Verified: `sensitive` + `batch` raises a risk and forces `role=author`, but stays feasible.

## STRUCTURE — decisions become visible and reviewable

Previously implicit in `phase_build`, so a reviewer couldn't see *why* an agent got its role, trigger, or memory tier. Now explicit with rationale, and no model call — every decision follows by rule:

```
role=implementer — unattended batch work needs to act, not just draft
trigger=scheduled (daily) from volume=low
memory=semantic — recurring runs need to know what they already reported
tools derived from KG, capped by 'implementer' ceiling
```

`phase_build` now **consumes** these grants rather than re-deriving them. Re-deriving let build silently disagree with what the review packet displayed — a reviewer would approve one grant set and a different one would ship.

## A footgun fixed after it bit twice

`AgentBrief` had eight same-typed string fields. A positional call that transposes two assigns silently, and the pipeline then researches, specifies, and builds against the wrong goal with **no error anywhere** — the failure looks like "the knowledge graph found nothing," which sends you debugging the wrong component entirely.

That happened twice while testing this module. Fixed with `@dataclass(kw_only=True)`, making the mistake unrepresentable rather than merely documented:

```
AgentBrief('n','o','g',...)  ->  TypeError: takes 1 positional argument but 9 were given
```

## Cost profile after the additions

$0.0518/run across ten stages. Research and Structure add **zero** model cost. Understand adds one Standard call — and it's the phase most likely to *save* the entire remaining pipeline by halting early, which is the opposite of the usual "add a phase, add cost" tradeoff.

| Phase | Tier | Cost |
|---|---|---|
| Research, Structure | *none* | $0.0000 |
| Understand | Standard | $0.0047 |
| Specify/Plan/Tasks/Analyze | Standard | $0.0233 |
| Build | **Deep** | $0.0229 |
| Validate | Fast | $0.0007 |

## Still open

- Duplicate detection is term-overlap on name + description. Semantic similarity against agent *specs* would catch a duplicate worded differently — the KG already has the embedding path for it.
- `phase_understand`'s deterministic rules are four hand-written checks. They should grow from real rejected-build history.
- A blocked build has no rework loop — same gap as the remediation pipeline's quarantine path.

---

# Agent builder intake — text and voice

`builder_intake_api.py` + `static/builder_intake.html`

```bash
pip install fastapi uvicorn python-multipart
python -m uvicorn builder_intake_api:app --port 8110
# open http://127.0.0.1:8110/
```

Closes a real gap: `DISCOVERY_QUESTIONS` was a Python list and `discover()` took a pre-filled dict. There was no way for a human to supply anything — the demo hardcoded an `AgentBrief` and never called `discover()` at all. Calling that a "wizard" was describing a data structure, not a usable thing.

## Two paths, one validated destination

```
text  ──┐
        ├──> AgentBrief ──> CustomAgentBuilder.run() ──> review packet
voice ──┘    (validated)     (feasibility gate always runs)
```

The single destination is the point. A voice path that built its own brief could drift from the text path's validation, and `phase_understand` — the phase that can halt a bad build — would be reachable from one entry point but not the other. Validation is **server-side** because the HTML wizard isn't the only possible caller; a CLI or another agent can POST the same endpoint and neither should be able to skip the checks.

## Voice is scoped to one field, deliberately

Only `goal` is free text. The other three questions are single-select. Dictating "internal" into a three-option picker is strictly worse than tapping it — slower, and it adds a transcription error mode to a field that had none. Voice earns its place on the one field where typing a paragraph is the actual friction.

Two details that matter more than the model:

- **The transcript never auto-submits.** It lands in the field for review. STT mis-transcribes internal service names often enough that auto-submit would routinely start a six-phase build against a goal the user didn't say.
- **The decoder is seeded from the knowledge graph, not a hardcoded list.** `_domain_hint()` pulls every service and spec name out of the KG and passes it as the STT hint. A decoder that has never seen `payments-api` produces a confident, plausible, wrong token for it — and the resulting brief then names a service that doesn't exist, which research dutifully fails to find, sending the user to debug the wrong component.

When no STT backend is installed the mic **disables itself and says why**, rather than failing on click.

## Verified over HTTP

| Test | Result |
|---|---|
| Bad option value | `400 data_sensitivity='top-secret' is not one of [...]` |
| Empty goal | `400 goal is required` |
| New agent build | `blocking: false`, validation `ok`, role `implementer`, trigger `scheduled daily` |
| Same goal again | `halted_early: true`, `duplicate_risk: likely`, spec phases `[]` |
| Go-live, clean | `200` → `https://harness.internal/a2a/vuln-digest-agent` |
| Go-live, duplicate | `409 Refusing to go live — build is blocking` |

**The duplicate halt is measurably real, not just a flag:** `$51.76` per 1k runs for the full build vs **`$4.74`** for the halted one. It stopped before spending anything on spec generation or the Opus-tier codegen — which is exactly what a research phase is for.

Also driven end-to-end in a real browser (Playwright): 8 option pills render, mic self-disables with an explanation, form submits, and the review packet renders research → understanding → structure with rationale in one scroll.

## Still open

- **Free-form voice into structured fields.** Right now voice fills `goal` only; the other three stay as taps. If intake ever becomes fully conversational, `phase_understand` has to do real extraction (sensitivity, volume, latency out of a paragraph) — which is the ambiguity the structured wizard exists to avoid. That's a genuine trade: voice is faster to give, more expensive and less reliable to parse.
- **No STT backend installed here**, so the voice path is verified only to the point of correct degradation. `pip install faster-whisper` + `apt-get install ffmpeg` exercises it fully.
- `go-live` re-runs the whole build rather than resuming the reviewed one — correct but wasteful, and it means the thing that goes live is a *rebuild* of what was reviewed, not the reviewed artifact itself. Should take a build id.

---

# Review pass — persona templates, real code generation, and go-live persistence

Three things fixed, one enhancement added.

## 1. Code was a stub — now three patterns generate genuinely complete code

`phase_build` previously always fell back to a `# TODO: implementation` stub in offline mode. That directly broke the "no VS Code" promise: a non-technical reviewer approving that build would be shipping something a developer still has to finish, with no way to tell from the review packet.

Three mechanical patterns now generate **complete, runnable code with zero model calls**:

| Pattern | What it does | Used by |
|---|---|---|
| `digest` | Fetch from every granted read tool, combine into one text digest | Vuln digest, Account brief, Weekly KPI digest |
| `router` | Fetch, classify by an inspectable keyword rule, act via the write tool | Feature triager, Ticket router |
| `delegate` | Call an existing, already-reviewed utility | Changelog writer |

A `code_complete` flag travels through the whole pipeline into the review packet, and **an incomplete build now blocks go-live** — a stub going live isn't a lower-confidence agent, it's a non-functional one:

```python
"blocking": (not r.validated) or (u and not u.feasible) or (not r.code_complete),
```

Verified by executing the generated code directly, not just checking it parses:
```python
mod.run({'query': 'The app crashes when I click submit'})
→ {'classification': 'bug', 'source': 'knowledge_search_tool', 'routed_to': 'jira_tool'}
```

**A real correctness bug turned up doing that**, not from reading the code: `WRITE_TOOL` came back empty for the Product template. Its goal ("classify incoming feature requests") never names a specific backend service, so KG-based grant derivation resolved zero subjects and granted only the fallback read tool — the router's whole promise was "classify **and file a ticket**," and half of it silently couldn't run. Root cause: KG derivation works well for goals naming a concrete service (`payments-api`), and under-grants generic cross-functional asks that don't. Fixed with a `suggested_tools` floor on the brief — unioned with KG-derived tools, then still cut to the role ceiling, so it raises the floor without ever raising the ceiling:

```python
candidates = set(decision.granted) | set(r.brief.suggested_tools)
s.tools = sorted(t for t in candidates if t in ROLE_CEILINGS[s.role] and t in catalog)
```

That fix then exposed a second, smaller one: `phase_understand` had already flagged "the agent would have nothing to call" *before* structure ran the rescue, and nothing reconciled the two — a reviewer would see that gap sitting directly above "Can access: jira_tool, knowledge_search_tool" in the same screen, which reads as the pipeline contradicting itself. Fixed by having `phase_structure` retract and rephrase the stale gap once it resolves it.

## 2. Go-live re-ran the whole pipeline — now it resumes the reviewed build

Flagged as an open gap last time and fixed properly. `intake` stores the finished `BuildResult` under a `build_id`; `go-live` takes **only** that id — no form fields — and resumes the exact build a reviewer looked at, rather than rebuilding from the same inputs a second time. Two runs of the same pipeline aren't guaranteed identical (a model call, a KG update between runs, a different `now()` in a scheduled trigger all diverge them), so this was a correctness gap, not just wasted spend.

Also fixed: a used `build_id` is popped after go-live, so retrying the same id returns `404` instead of silently shipping twice.

```
intake  → build_id: build_98383d9b...
go-live/build_98383d9b...  → 200, live
go-live/build_98383d9b...  → 404 (already shipped)
```

## 3. Persona template gallery — the actual answer to "no VS Code"

`GET /v1/builder/templates` serves six examples spanning **Dev, Product, Sales, Support/CS, and Dashboard/Analytics** — the gallery is now the landing view, with "start from scratch" as the secondary path rather than the only one. A blank form assumes you already know what "trigger" or "role" means; a gallery lets someone say "that one, but for my team" and tweak wording instead of authoring a spec from nothing.

Each template's `pattern` is chosen so its build produces complete code with no model call — the gallery and the honesty flag are the same mechanism, not two separate features bolted together.

Driven end to end in a real browser: 6 cards render → click "Feature request triager" → form pre-fills → submit → **"Ready. This can go live now — no code to write or review."** → Go Live → `https://harness.internal/a2a/product-triager`.

## Verified, full regression

All six templates, after every fix, in one run: `code_complete=True`, `blocking=False`, and zero contradictory gaps, across every persona.

## Still open

- Voice path is verified only to the point of correct degradation (no STT backend installed here); `pip install faster-whisper` + ffmpeg exercises it fully.
- Custom (non-template) goals still fall back to the model call, and offline that's still the honest stub — `code_complete=False`, correctly blocking. A live API key changes this to a real deep-tier generation, "recommend a developer skims it once."
- Builds are in-memory only; a server restart between intake and go-live loses the build (`404`, not silent data loss — but still a real limitation before this is anything but a demo).
- The router pattern's keyword rules are three hand-written categories. Fine for a first pass, needs to grow from real ticket data per deployment.

---

# Full gallery demonstration — 13 use cases across 5 categories

`builder_gallery_demo.py` — builds every template through the six-phase pipeline, then **imports and executes the generated code**, then takes it live.

```
13/13 built, executed, and went live with complete code
```

| Category | Use cases |
|---|---|
| **Dev / Security** | Vulnerability digest · Critical findings watchdog |
| **Dev** | Release changelog writer |
| **Product** | Feature request triager · Feedback field extractor · Sprint outcome digest |
| **Sales** | Account brief · Inbound lead qualifier · RFP requirement extractor |
| **Support / CS** | Ticket router · Backlog watchdog |
| **Dashboard / Analytics** | Weekly KPI digest · Metric anomaly watch |

Two new patterns were needed to cover them without falling back to a model call: **`watcher`** (threshold breach → alert) and **`extractor`** (labelled-line field extraction). Five patterns now: `digest`, `router`, `delegate`, `watcher`, `extractor`.

## Executing the code found three bugs that syntax-checking could not

This is the whole reason the demo runs the generated code rather than just parsing it.

### 1. The watcher fired a confident false alert

`_extract_number` grabbed "the first number anywhere in the payload" — which picked up a **search relevance score of 0.82**, compared it against a threshold of 40, and reported `breached: True, alerted: True`. A monitoring agent that invents a metric is worse than one that admits it can't find one: the first gets trusted and is wrong.

Fixed to **fail closed** — only counts values under explicitly count-like keys (or the length of a returned collection), and returns `status: "undetermined"` with a pointer to fix `METRIC_KEYS` rather than comparing against a fabricated number. `metric_keys` is now per-template (`critical_count`, `backlog`, `conversion`).

### 2. The sales lead qualifier classified a lead as a "bug"

The router template hardcoded `bug / feature / question` for **every** router, so the inbound lead qualifier confidently applied a bug-tracker taxonomy to sales leads. Plausible output, completely wrong categories.

Rules are now per-template: leads get `hot / nurture / unqualified`, support tickets get `urgent / billing / howto`. Visible in the final run — off-taxonomy input now returns `uncategorised` instead of a confident mislabel.

### 3. A name collision silently produced a build that wrote nothing

`scaffold_utility` raises when the target directory exists. `phase_build` let that propagate, and the caller saw a "file not found" much later — sending you to look in the wrong place entirely. Swallowing it would have been worse: the build would report success having written no code, and go-live would publish whatever happened to already be at that path.

Now caught and turned into a blocking failure with an actionable message. Verified with a same-name-different-goal case, since duplicate detection (which fires first and is the better guard) masks the same-goal case.

## What the executed output actually shows

```
extractor  → {'record': {'budget': '50k', 'deadline': 'Q3',
                         'requirements': 'SAML, audit log'}, 'complete': True}
delegate   → {'changelog': '## Features\n- feat: add dark mode\n## Fixes\n- ...'}
watcher    → {'value': 1.0, 'threshold': 3, 'breached': False, 'status': 'ok'}
router     → {'classification': 'uncategorised', 'routed_to': 'jira_tool'}
```

Real records, real grouped changelog, real threshold comparisons — not stubs.

## Still open

- **Watchers read `metric_keys` from a demo tool payload.** Against a real scanner or metrics API those key names need setting per deployment; the `undetermined` status is what surfaces a mismatch rather than hiding it.
- **Router rules are keyword lists.** They return `uncategorised` rather than guessing, which is the right failure — but nuanced text needs either better rules or a model call, and that's a per-deployment tuning job.
- **Cost estimate is identical ($28.86/1k) across templates** because every build runs the same phase sequence. Real per-template variance only shows up once token counts come from measured usage rather than `chars // 4`.
- Builds remain in-memory; a restart between intake and go-live loses the build.
