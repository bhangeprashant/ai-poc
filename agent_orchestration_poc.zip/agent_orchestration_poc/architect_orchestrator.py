"""
ArchitectOrchestrator — drives every sub-agent, streams live progress over
the harness's own EventBus, and packages everything into one downloadable
zip.

    from architect_agent_orchestrator import ArchitectOrchestrator
    orch = ArchitectOrchestrator()
    for ev in orch.run_streaming("/path/to/repo", "my-service"):
        print(ev.data["stage"], ev.data["msg"])
    # orch.result has hld_path, lld_paths, drawio_path, uml_path, html_path, zip_path
"""

from __future__ import annotations

import os
import threading
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional

from harness_core import EventBus, EventType, SessionState
from knowledge_graph import KnowledgeGraph
from architect_agent import (
    CodeIngestAgent, DocIngestAgent, ArchitectureAnalystAgent,
    HLDAgent, LLDAgent, DiagramAgent, Component, emit,
)


@dataclass
class ArchitectResult:
    repo_name: str
    components: List[Component] = field(default_factory=list)
    hld_path: str = ""
    lld_paths: Dict[str, str] = field(default_factory=dict)
    drawio_path: str = ""
    uml_path: str = ""
    html_path: str = ""
    zip_path: str = ""
    stats: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)


class ArchitectOrchestrator:
    def __init__(self) -> None:
        self.bus = EventBus("architect_" + uuid.uuid4().hex[:8])
        self.result: Optional[ArchitectResult] = None
        self._kg = KnowledgeGraph()

    def run_streaming(self, repo_path: str, repo_name: str,
                      out_dir: str = "/tmp/architect_out",
                      max_components: Optional[int] = None
                      ) -> Iterator[Any]:
        """Starts the build on a worker thread, yields live progress events
        as they happen -- same resumable pattern as every other harness run
        in this repo. Caller drains this generator to see progress; the
        final ArchitectResult lands on self.result once the stream ends."""
        started = threading.Event()

        def worker() -> None:
            started.set()
            try:
                self._build(repo_path, repo_name, out_dir, max_components)
            except Exception as exc:  # noqa: BLE001
                emit(self.bus, "error", f"Build failed: {exc}")
                self.bus.emit(EventType.TURN_FAILED, {"error": str(exc)})
            else:
                self.bus.emit(EventType.TURN_COMPLETED, {"ok": True})

        t = threading.Thread(target=worker, daemon=True, name="architect-build")
        t.start()
        started.wait(2)

        for ev in self.bus.stream(after_seq=0):
            yield ev
            if ev.type in (EventType.TURN_COMPLETED.value, EventType.TURN_FAILED.value):
                break

    def _build(self, repo_path: str, repo_name: str, out_dir: str,
              max_components: Optional[int]) -> None:
        os.makedirs(out_dir, exist_ok=True)
        bus, kg = self.bus, self._kg
        result = ArchitectResult(repo_name=repo_name)

        emit(bus, "orchestrator", f"Starting architecture build for '{repo_name}'")

        # ---- stage 1: ingestion, code + docs IN PARALLEL -- two agents,
        # independent inputs, no reason to serialise them.
        ingest_out: Dict[str, Any] = {}
        def do_code():
            ingest_out["code"] = CodeIngestAgent().run(repo_path, kg, bus)
        def do_docs():
            ingest_out["docs"] = DocIngestAgent().run(repo_path, kg, bus)
        t1, t2 = threading.Thread(target=do_code), threading.Thread(target=do_docs)
        t1.start(); t2.start()
        t1.join(); t2.join()
        result.stats["modules"] = len(ingest_out.get("code", {}).get("modules", {}))
        result.stats["docs"] = ingest_out.get("docs", 0)

        if result.stats["modules"] == 0:
            emit(bus, "orchestrator", "No Python modules found — nothing to architect", level="error")
            result.errors.append("no_modules_found")
            self.result = result
            return

        # ---- stage 2: analysis
        components = ArchitectureAnalystAgent().run(kg, bus)
        if max_components:
            components = sorted(components, key=lambda c: -c.dependents)[:max_components]
        result.components = components

        # ---- stage 3: HLD (single synthesis step)
        hld_text = HLDAgent().run(repo_name, components, kg, bus)
        hld_path = os.path.join(out_dir, "HLD.md")
        with open(hld_path, "w", encoding="utf-8") as fh:
            fh.write(hld_text)
        result.hld_path = hld_path

        # ---- stage 4: LLD, ONE PER COMPONENT, IN PARALLEL --
        # one component's LLD failing must not block the others.
        lld_sections: Dict[str, str] = {}
        lld_errors: List[str] = []
        lock = threading.Lock()

        def do_lld(c: Component) -> None:
            try:
                text = LLDAgent().run(c, kg, bus)
                with lock:
                    lld_sections[c.name] = text
            except Exception as exc:  # noqa: BLE001
                with lock:
                    lld_errors.append(f"{c.name}: {exc}")
                emit(bus, "lld", f"LLD failed for {c.name}: {exc}", level="error")

        threads = [threading.Thread(target=do_lld, args=(c,)) for c in components]
        for th in threads:
            th.start()
        for th in threads:
            th.join(timeout=30)

        lld_path = os.path.join(out_dir, "LLD.md")
        with open(lld_path, "w", encoding="utf-8") as fh:
            fh.write(f"# Low-Level Design — {repo_name}\n\n")
            for c in components:  # fixed order, not thread-finish order
                fh.write(lld_sections.get(c.name, f"## {c.name}\n\n_generation failed_\n") + "\n\n")
        result.lld_paths = {"combined": lld_path}
        result.errors.extend(lld_errors)
        emit(bus, "lld", f"LLD complete — {len(lld_sections)}/{len(components)} component(s) documented")

        # ---- stage 5: diagrams, sourced from the SAME graph as the docs
        diagrams = DiagramAgent().run(repo_name, components, kg, bus, out_dir)
        result.drawio_path = diagrams["drawio"]
        result.uml_path = diagrams["uml"]
        result.html_path = diagrams["html"]

        # ---- stage 6: package
        emit(bus, "package", "Packaging downloadable bundle")
        zip_path = os.path.join(out_dir, f"{repo_name}-architecture.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for label, path in [("HLD.md", result.hld_path), ("LLD.md", lld_path),
                                ("architecture.drawio", result.drawio_path),
                                ("uml.md", result.uml_path),
                                ("architecture.html", result.html_path)]:
                if path and os.path.isfile(path):
                    zf.write(path, arcname=label)
        result.zip_path = zip_path
        emit(bus, "package", f"Bundle ready: {os.path.basename(zip_path)}")

        self.result = result
