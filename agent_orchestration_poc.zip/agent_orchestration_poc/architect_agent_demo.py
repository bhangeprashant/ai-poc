"""
Architect Agent — CLI entry point.

    python architect_agent_demo.py <repo_path> <repo_name> [max_components]

Takes a repo path from the user, runs the full multi-agent build with live
progress printed as it streams, and leaves a downloadable zip plus the
individual artifacts in the output directory.
"""

from __future__ import annotations

import sys
import time

from architect_orchestrator import ArchitectOrchestrator

STAGE_LABEL = {
    "orchestrator": "ORCH",
    "ingest.code": "CODE",
    "ingest.docs": "DOCS",
    "analyze": "ANLZ",
    "hld": "HLD ",
    "lld": "LLD ",
    "diagram": "DGRM",
    "package": "PKG ",
    "error": "ERR ",
}


def run(repo_path: str, repo_name: str, out_dir: str = "/tmp/architect_out",
       max_components: int | None = None) -> ArchitectOrchestrator:
    print(f"Architect Agent — building for '{repo_name}' from {repo_path}\n")
    orch = ArchitectOrchestrator()
    t0 = time.time()

    for ev in orch.run_streaming(repo_path, repo_name, out_dir, max_components):
        d = ev.data
        stage = d.get("stage")
        if stage:
            label = STAGE_LABEL.get(stage, stage[:4].upper())
            elapsed = time.time() - t0
            print(f"  [{elapsed:5.1f}s] {label} │ {d.get('msg', '')}")
        elif ev.type == "turn.failed":
            print(f"\n  BUILD FAILED: {d.get('error')}")

    r = orch.result
    print(f"\nDone in {time.time()-t0:.1f}s.\n")

    if not r or r.errors and not r.zip_path:
        print("No usable artifacts produced.", r.errors if r else "")
        return orch

    print(f"Components identified : {len(r.components)}")
    print(f"  {', '.join(c.name for c in r.components)}")
    print()
    print("Artifacts:")
    for label, path in [("HLD", r.hld_path), ("LLD", r.lld_paths.get("combined", "")),
                        ("draw.io", r.drawio_path), ("UML (mermaid)", r.uml_path),
                        ("HTML diagram", r.html_path), ("Bundle (zip)", r.zip_path)]:
        print(f"  {label:16} {path}")
    if r.errors:
        print(f"\nNon-fatal issues: {r.errors}")
    return orch


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python architect_agent_demo.py <repo_path> <repo_name> [max_components]")
        sys.exit(1)
    repo_path, repo_name = sys.argv[1], sys.argv[2]
    max_c = int(sys.argv[3]) if len(sys.argv) > 3 else None
    run(repo_path, repo_name, max_components=max_c)
