"""
Worked example — a real cross-tool enterprise agent.

    python release_notes_agent_demo.py

Goal: for a release, pull the Jira tickets, cross-check them against merged
GitLab merge requests, and publish a release-notes page to Confluence.

Three systems, five tools, three risk tiers. Shows the whole path:
build the agent through the recommender/finalizer, then actually RUN it
through the harness with real approval gating -- not a mockup of the flow,
the flow.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, List

from agent_builder import AgentRecommender, AgentOrchestratorFinalizer
from farm_core import PolicyBroker, PolicyRule, APPROVE, DENY
from harness_core import SESSIONS, SessionState
from harness_loop import HarnessRun
from tool_registry import run_tool

GOAL = ("For the payments-api 2.14 release: pull the Jira tickets in the release, "
        "cross-check them against merged GitLab merge requests, and publish a "
        "release notes page to the Confluence ENG space.")


def hdr(t: str, why: str = "") -> None:
    print(f"\n{'='*74}\n  {t}\n{'='*74}")
    if why:
        print(f"  {why}\n")


def main() -> None:
    # ---------------------------------------------------------- 1. build
    hdr("1. Recommender analyses the goal",
        "Searches the whole catalog. Note which tools it pre-ticks and which\n"
        "  it deliberately leaves off.")
    rec = AgentRecommender()
    r = rec.recommend(GOAL)
    print(f"  Suggested name : {r.suggested_name}")
    print(f"  Profile        : {r.suggested_profile}\n")
    for t in r.tools:
        mark = "[x]" if t.preselect else "[ ]"
        print(f"  {mark} {t.name:26} {t.risk:6}  {t.rationale[:60]}")
    for w in r.warnings:
        print(f"\n  ! {w}")

    # ------------------------------------------------- 2. user confirms
    hdr("2. User reviews and confirms",
        "The user accepts the pre-ticked set and ALSO ticks confluence_publish_tool,\n"
        "  because publishing is genuinely the point of this agent.")
    confirmed = [t.name for t in r.tools if t.preselect]
    if "confluence_publish_tool" not in confirmed:
        confirmed.append("confluence_publish_tool")
    # The user does NOT want this agent opening merge requests.
    confirmed = [t for t in confirmed if t != "gitlab_publish_tool"]
    for t in confirmed:
        print(f"  + {t}")
    print("\n  Explicitly NOT granted: gitlab_publish_tool "
          "(this agent reports on MRs, it does not open them)")

    # ------------------------------------------------ 3. orchestrator
    hdr("3. Orchestrator finalizes",
        "Computes what actually gates at runtime. This step cannot loosen the\n"
        "  harness's own risk table -- it only reports it.")
    fin = AgentOrchestratorFinalizer()
    d = fin.finalize("release-notes-agent", "engineer", confirmed,
                     kb_enabled=False, kb_scope=[],
                     harness_enabled=False, languages=[])
    print(f"  granted        : {d.granted_tools}")
    print(f"  auto-approved  : {d.auto_approved}")
    print(f"  gated at runtime:")
    for g in d.gated_at_runtime:
        print(f"      {g['tool']:26} {g['severity']}")
    for n in d.notes:
        print(f"  note: {n}")

    # ---------------------------------------------------- 4. run it
    hdr("4. Run the agent — real cross-tool calls, real gating",
        "A policy broker auto-approves reads and the medium-risk Jira call, but\n"
        "  routes the Confluence publish to a human. Watch the ordering.")

    broker = PolicyBroker(rules=[
        PolicyRule("reads", APPROVE, max_severity="low",
                   reason="Read-only lookups across Jira/GitLab/Confluence."),
        PolicyRule("jira-medium", APPROVE, tools=["jira_tool"], max_severity="medium",
                   reason="Reading and commenting on tickets is pre-authorised for this agent."),
        # confluence_publish_tool (high) matches nothing -> escalates.
    ])
    session = SESSIONS.create("release-notes-agent", "engineer", d.granted_tools, {})
    broker.watch(session)
    run = HarnessRun(session, GOAL, "turn_release_notes")

    results: Dict[str, Any] = {}

    def do_work() -> None:
        # --- read phase: three systems, no human needed
        results["jira"] = run.dispatch_tool("jira_tool", {
            "action": "search", "query": "fixVersion = 2.14 AND project = PROJ"})
        results["gitlab"] = run.dispatch_tool("gitlab_read_tool", {
            "action": "list_merge_requests", "project": "payments-api"})
        results["confluence_read"] = run.dispatch_tool("confluence_read_tool", {
            "query": "release process payments-api", "space": "ENG"})

        # --- cross-check: pure reasoning over what came back, no tool needed
        mrs = results["gitlab"].get("merge_requests", [])
        merged = [m for m in mrs if m["state"] == "merged"]
        open_mrs = [m for m in mrs if m["state"] != "merged"]
        results["crosscheck"] = {"merged": merged, "still_open": open_mrs}

        body = render_release_notes(merged, open_mrs)
        results["body"] = body

        # --- publish phase: high risk, must wait for a human
        results["publish"] = run.dispatch_tool("confluence_publish_tool", {
            "action": "create_page", "space": "ENG",
            "title": "payments-api 2.14 — Release Notes", "body": body})

    worker = threading.Thread(target=do_work, daemon=True)
    worker.start()

    # Watch the gate: reads should complete before any checkpoint appears.
    time.sleep(0.8)
    open_cps = [c for c in session.checkpoints.values() if not c.resolved]
    print(f"  reads completed  : jira={'jira' in results} "
          f"gitlab={'gitlab' in results} confluence={'confluence_read' in results}")
    print(f"  published yet    : {'publish' in results}  <- must be False")
    print(f"  open checkpoints : {[c.payload.get('tool') for c in open_cps]}")

    for cp in open_cps:
        print(f"\n  HUMAN GATE: {cp.prompt}")
        print(f"    tool={cp.payload.get('tool')} severity={cp.payload.get('severity')}")
        print("    reviewer: APPROVED")
        cp.resolve(approved=True, by="release-manager@example.com")

    worker.join(timeout=15)

    # ---------------------------------------------------- 5. output
    hdr("5. Result")
    jira_n = len(results.get("jira", {}).get("results", []))
    cc = results.get("crosscheck", {})
    print(f"  Jira tickets pulled     : {jira_n}")
    print(f"  Merged MRs cross-checked: {len(cc.get('merged', []))}")
    print(f"  Open MRs flagged        : {len(cc.get('still_open', []))} "
          f"{[m['iid'] for m in cc.get('still_open', [])]}")
    pub = results.get("publish", {})
    print(f"  Confluence page         : {pub.get('url')}")
    print(f"  Watchers notified       : {pub.get('watchers_notified')}")

    print("\n  --- generated page body ---")
    for line in results.get("body", "").splitlines():
        print(f"  {line}")

    print(f"\n  Audit: {broker.audit_summary()}")
    for a in broker.audit:
        print(f"    {a.caller} -> {a.tool} ({a.severity}) = {a.decision} [{a.rule}]")
    broker.shutdown()


def render_release_notes(merged: List[Dict[str, Any]],
                         open_mrs: List[Dict[str, Any]]) -> str:
    """Cross-references GitLab MRs to their Jira ticket. The open-MR section
    exists because a release note that silently omits unmerged work is the
    failure mode that actually bites -- it reads as complete."""
    lines = ["h1. payments-api 2.14 — Release Notes", "", "h2. Included changes", ""]
    for m in merged:
        lines.append(f"* [{m['jira_ref']}] {m['title']} "
                     f"(MR !{m['iid']}, {m['approvals']} approval(s), @{m['author']})")
    if open_mrs:
        lines += ["", "h2. NOT included — still open at cut", ""]
        for m in open_mrs:
            lines.append(f"* [{m['jira_ref']}] {m['title']} "
                         f"(MR !{m['iid']}, unmerged, {m['approvals']} approval(s))")
    lines += ["", "_Generated by release-notes-agent. "
              "Jira and GitLab cross-checked at build time._"]
    return "\n".join(lines)


if __name__ == "__main__":
    main()
