"""
Human-in-the-loop approval gate.

The pipeline deliberately halts between PLAN and DEPLOY. Nothing is
deployed and no tool is called until a human approves the proposed
agent topology.

What the reviewer gets:
  - the plan (roles, steps, dependencies)
  - the exact deployment manifest that will be applied
  - a risk assessment with per-flag severity and the reason for each
  - the ability to *edit* before approving: drop an agent, revoke a
    tool grant, or force a different backend

Auto-approve policy: runs whose highest risk severity is "low" can be
auto-approved when AUTO_APPROVE_LOW_RISK is enabled -- this is what
makes it feel "seamless" for routine queries while still hard-gating
anything that writes, executes code, or touches elevated scope.
"""

from __future__ import annotations

import os
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


AUTO_APPROVE_LOW_RISK = os.environ.get("AUTO_APPROVE_LOW_RISK", "true").lower() == "true"
APPROVAL_TTL_SECONDS = int(os.environ.get("APPROVAL_TTL_SECONDS", "1800"))


class RunState(str, Enum):
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    DEPLOYING = "deploying"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


# --------------------------------------------------------------------------
# Risk assessment
# --------------------------------------------------------------------------

# Tool -> (severity, why). Drives what the reviewer sees and whether the
# run is eligible for auto-approval. Tune this table to your own control
# framework; it is the single place risk policy lives.
TOOL_RISK: Dict[str, tuple] = {
    "knowledge_search_tool": (Severity.LOW, "Read-only semantic search over internal KB"),
    "compliance_tool": (Severity.LOW, "Read-only policy evaluation, no mutation"),
    "jira_tool": (Severity.MEDIUM, "Can write comments and transition tickets"),
    "git_tool": (Severity.MEDIUM, "Reads source history; may expose repo contents"),
    "execution_harness_tool": (Severity.HIGH, "Executes arbitrary code in the sandbox"),
    "security_scanner_tool": (Severity.LOW, "Read-only fetch of SAST/SCA findings and rescan status"),
    "test_runner_tool": (Severity.LOW, "Runs the existing test suite; no source mutation"),
    # Split from a single repo_tool so the two halves carry honest tiers.
    # Rating a clone at push severity meant every read needed a human,
    # which trains reviewers to rubber-stamp the gate that also guards
    # real pushes.
    "repo_read_tool": (Severity.LOW, "Clone and inspect only; cannot publish"),
    "repo_publish_tool": (Severity.HIGH, "Push to shared remote — irreversible and publicly visible"),
    # Confluence: read is harmless, publish is org-wide and immediate. A
    # published page notifies every space watcher and, unlike a git commit,
    # has no review step between write and visibility — so it is rated
    # ABOVE a code push, not below it.
    "confluence_read_tool": (Severity.LOW, "Read-only wiki search and page read"),
    "confluence_publish_tool": (Severity.HIGH, "Publishes org-wide instantly and notifies watchers; no review step between write and visibility"),
    "gitlab_read_tool": (Severity.LOW, "Read-only merge request, pipeline, and commit inspection"),
    "gitlab_publish_tool": (Severity.HIGH, "Opens merge requests and tags releases on shared projects"),
}

_SEVERITY_ORDER = {Severity.LOW: 0, Severity.MEDIUM: 1, Severity.HIGH: 2}


@dataclass
class RiskFlag:
    severity: Severity
    code: str
    message: str


def assess_risk(agents_planned: List[Dict[str, Any]], backend: str,
                constraints: List[str]) -> Dict[str, Any]:
    flags: List[RiskFlag] = []

    all_tools = sorted({t for a in agents_planned for t in a.get("tools", [])})
    for tool in all_tools:
        severity, why = TOOL_RISK.get(tool, (Severity.MEDIUM, "Unclassified tool — treated as medium by default"))
        flags.append(RiskFlag(severity, f"tool:{tool}", why))

    if len(agents_planned) > 3:
        flags.append(RiskFlag(
            Severity.MEDIUM, "fanout",
            f"{len(agents_planned)} agents will be created in a single run",
        ))

    if backend == "kubernetes":
        flags.append(RiskFlag(
            Severity.MEDIUM, "backend:kubernetes",
            "Creates real Deployment/Service objects in the cluster",
        ))

    if not constraints:
        flags.append(RiskFlag(
            Severity.MEDIUM, "no_constraints",
            "agent.md declared no constraints — no guardrails were supplied by the author",
        ))

    highest = Severity.LOW
    for f in flags:
        if _SEVERITY_ORDER[f.severity] > _SEVERITY_ORDER[highest]:
            highest = f.severity

    return {
        "highest_severity": highest.value,
        "auto_approvable": highest == Severity.LOW and AUTO_APPROVE_LOW_RISK,
        "flags": [{"severity": f.severity.value, "code": f.code, "message": f.message} for f in flags],
    }


# --------------------------------------------------------------------------
# Pending run store
# --------------------------------------------------------------------------

@dataclass
class PendingRun:
    run_id: str
    state: RunState
    created_at: float
    spec: Dict[str, Any]
    understanding: Dict[str, Any]
    plan: Dict[str, Any]
    manifest: Dict[str, Any]
    risk: Dict[str, Any]
    backend: str
    trace: List[Dict[str, Any]]
    decision: Optional[Dict[str, Any]] = None
    result: Optional[Dict[str, Any]] = None

    def is_expired(self) -> bool:
        return (
            self.state == RunState.AWAITING_APPROVAL
            and time.time() - self.created_at > APPROVAL_TTL_SECONDS
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "state": self.state.value,
            "created_at": self.created_at,
            "agent_spec": self.spec,
            "understanding": self.understanding,
            "plan": self.plan,
            "deployment_manifest": self.manifest,
            "risk": self.risk,
            "backend": self.backend,
            "decision": self.decision,
            "result": self.result,
            "trace": self.trace,
        }


class ApprovalStore:
    """In-memory pending-run store.

    Swap for DynamoDB/Redis in the cluster so approvals survive restarts
    and work across replicas of the orchestrator -- the interface below is
    all the rest of the code depends on.
    """

    def __init__(self) -> None:
        self._runs: Dict[str, PendingRun] = {}
        self._lock = threading.Lock()

    def create(self, **kwargs: Any) -> PendingRun:
        run_id = uuid.uuid4().hex[:12]
        run = PendingRun(run_id=run_id, state=RunState.AWAITING_APPROVAL,
                         created_at=time.time(), **kwargs)
        with self._lock:
            self._runs[run_id] = run
        return run

    def get(self, run_id: str) -> Optional[PendingRun]:
        with self._lock:
            run = self._runs.get(run_id)
        if run and run.is_expired():
            run.state = RunState.EXPIRED
        return run

    def list_pending(self) -> List[Dict[str, Any]]:
        with self._lock:
            runs = list(self._runs.values())
        return [
            {
                "run_id": r.run_id,
                "state": r.state.value,
                "agent": r.spec.get("name"),
                "agents_planned": len(r.manifest.get("services", [])),
                "highest_severity": r.risk.get("highest_severity"),
                "created_at": r.created_at,
            }
            for r in runs
            if r.state == RunState.AWAITING_APPROVAL and not r.is_expired()
        ]


STORE = ApprovalStore()


# --------------------------------------------------------------------------
# Applying a reviewer's edits
# --------------------------------------------------------------------------

def apply_reviewer_edits(plan: Dict[str, Any], edits: Dict[str, Any]) -> tuple:
    """Return (edited_plan, change_log) after applying human edits.

    Supported edits:
      removed_roles:  [str]              drop these agents entirely
      revoked_tools:  {role: [tool,...]} strip specific tool grants
    """
    change_log: List[str] = []
    removed_roles = set(edits.get("removed_roles", []))
    revoked = edits.get("revoked_tools", {})

    steps = []
    for step in plan.get("steps", []):
        if step["agent_role"] in removed_roles:
            change_log.append(f"Removed agent '{step['agent_role']}' (step {step['step_id']})")
            continue

        role_revoked = set(revoked.get(step["agent_role"], []))
        if role_revoked:
            kept = [t for t in step["tools"] if t not in role_revoked]
            stripped = sorted(set(step["tools"]) - set(kept))
            if stripped:
                change_log.append(
                    f"Revoked {stripped} from '{step['agent_role']}'"
                )
            step = {**step, "tools": kept}

        steps.append(step)

    # any dependency pointing at a removed step is dropped so the
    # scheduler doesn't deadlock on it
    surviving = {s["step_id"] for s in steps}
    for step in steps:
        pruned = [d for d in step.get("depends_on", []) if d in surviving]
        if len(pruned) != len(step.get("depends_on", [])):
            change_log.append(f"Pruned dangling dependency on step {step['step_id']}")
        step["depends_on"] = pruned

    return {**plan, "steps": steps}, change_log
