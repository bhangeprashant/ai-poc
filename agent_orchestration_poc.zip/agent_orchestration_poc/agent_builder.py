"""
Custom Agent Builder — recommend, let the user override, then the
orchestrator decides how it actually runs.

Three actors, three different jobs, on purpose:

  RECOMMENDER   Reads the user's free-text goal against the tool catalog
                (all 200+ registered tools, built-in and team-published)
                and the knowledge graph, and proposes a minimal starting
                point: which tools, whether KB access is warranted, whether
                execution/compilation is needed and in what language.
                Every recommendation carries WHY, and a CONFIDENCE the
                caller can act on -- "no relevant tool cleared the bar" is
                a real, distinct answer from "here are three weak
                guesses," and collapsing them into "here's my best guess
                regardless" is how these systems end up silently wrong.

  THE USER      Sees the recommendation as an editable form, not a
                decision already made. Every checkbox is pre-ticked
                according to the recommendation, not locked to it.

  ORCHESTRATOR  Takes whatever the user actually confirmed and does the
                governance work a user shouldn't have to think about:
                which of the confirmed tools will actually require
                approval at runtime (same severity table every other
                tool call in this repo is gated by -- a custom agent
                does not get a quieter risk model than a built-in one),
                which sandbox pool kind the chosen languages route to,
                and the final grant list, deduplicated and sorted.

At no point does the recommender's OUTPUT become the orchestrator's INPUT
directly -- the user's confirmed selection sits between them. A
recommendation the user never saw or could veto is not customization,
it's the system deciding for them with extra steps.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from approvals import TOOL_RISK, Severity
from knowledge_graph import KnowledgeGraph, KG, Node
from tool_registry import list_tools

RELEVANCE_FLOOR = 0.28   # fraction of the top BM25 score a tool must clear
                         # to be recommended at all -- see tool_broker.py's
                         # identical fix: RRF/BM25 ranks compress, so taking
                         # "top K" unconditionally recommends irrelevant
                         # tools whenever the catalog is small relative to K.
ABSOLUTE_BM25_FLOOR = 1.0   # defense in depth: the relative floor alone has
                            # a hole when EVERY candidate is weakly noisy --
                            # the top score is then noise too, and "28% of
                            # noise" still admits noise. A real match's
                            # shared-vocabulary BM25 score clears this by a
                            # wide margin (jira_tool: 7.7 against "jira");
                            # residual stopword/short-token overlap after
                            # filtering does not.

LANGUAGES = [
    {"id": "python", "label": "Python", "sandbox": "python_utility"},
    {"id": "javascript", "label": "JavaScript / TypeScript", "sandbox": "node_utility"},
    {"id": "java", "label": "Java", "sandbox": "jvm_utility"},
    {"id": "go", "label": "Go", "sandbox": "go_utility"},
    {"id": "rust", "label": "Rust", "sandbox": "rust_utility"},
    {"id": "c", "label": "C", "sandbox": "native_utility"},
    {"id": "cpp", "label": "C++", "sandbox": "native_utility"},
    {"id": "csharp", "label": "C#", "sandbox": "dotnet_utility"},
    {"id": "ruby", "label": "Ruby", "sandbox": "ruby_utility"},
    {"id": "php", "label": "PHP", "sandbox": "php_utility"},
    {"id": "kotlin", "label": "Kotlin", "sandbox": "jvm_utility"},
    {"id": "swift", "label": "Swift", "sandbox": "native_utility"},
    {"id": "scala", "label": "Scala", "sandbox": "jvm_utility"},
    {"id": "shell", "label": "Shell / Bash", "sandbox": "shell_utility"},
    {"id": "sql", "label": "SQL", "sandbox": "sql_utility"},
]
LANGUAGE_ALIASES = {
    "js": "javascript", "ts": "javascript", "typescript": "javascript",
    "golang": "go", "c++": "cpp", "c#": "csharp", "dotnet": "csharp",
    ".net": "csharp", "bash": "shell", "sh": "shell", "postgres": "sql",
    "mysql": "sql", "plsql": "sql",
}

EXEC_KEYWORDS = ["compile", "compilation", "run code", "execute", "unit test",
                 "build", "test suite", "integration test", "script", "pipeline run"]

# Verbs that indicate the user actually wants to CHANGE something, as
# opposed to merely mentioning the noun a write tool happens to operate on.
#
# Deliberately excludes words that are ambiguous between verb and noun in
# this domain: "merge" appears in "merge request" (a noun phrase, usually
# being read), "comment" in "comment thread", "tag" in "git tag". Including
# them made a purely read-shaped goal register as write intent. Where a
# word is genuinely ambiguous, the multi-word form is listed instead
# ("open a", "create a") so the verb position is unambiguous. Missing a
# write intent is recoverable -- the user just ticks the box. Falsely
# detecting one silently pre-grants write access, which is not.
WRITE_INTENT_VERBS = [
    "publish", "create", "open a", "post a", "write", "update", "edit",
    "push", "commit", "file a", "raise a", "submit", "deploy",
    "close the", "assign", "delete", "upload", "tag the release",
]

# Which system each write-capable tool belongs to, and the words that
# indicate the goal is talking about THAT system. Goal-level write intent
# alone is too coarse: a goal saying "publish a page to Confluence" set
# write intent True and therefore pre-ticked gitlab_publish_tool as well,
# even though nothing in the goal asks to open a merge request. Intent has
# to be matched to the system it was expressed about.
TOOL_SYSTEM_TERMS: Dict[str, List[str]] = {
    "confluence_publish_tool": ["confluence", "wiki", "page", "space", "runbook"],
    "gitlab_publish_tool": ["gitlab", "merge request", "mr", "pipeline", "branch"],
    "repo_publish_tool": ["repo", "repository", "git", "branch", "commit"],
    "jira_tool": ["jira", "ticket", "issue", "defect", "story"],
}


def _has_write_intent(goal_l: str) -> bool:
    """Word-boundary matched, not substring.

    Substring matching fails here in exactly the way it failed for
    single-letter language ids: "merged" (a read-shaped past participle
    describing MRs that already landed) contains "merge", so a purely
    read-shaped goal registered as write intent and pre-ticked
    gitlab_publish_tool anyway -- defeating the whole guard. Multi-word
    phrases are checked against the raw text; single words against
    tokenized word boundaries.
    """
    import re as _re
    words = set(_re.findall(r"[a-z]+", goal_l))
    for v in WRITE_INTENT_VERBS:
        if " " in v:
            if v in goal_l:
                return True
        elif v in words:
            return True
    return False


def _write_intent_for_tool(goal_l: str, tool_name: str) -> bool:
    """Does the goal express a write action AGAINST THIS TOOL'S SYSTEM?

    Checking "write verb present" AND "system mentioned anywhere" is still
    too loose: the goal "cross-check against merged GitLab merge requests,
    and publish a page to Confluence" mentions GitLab AND contains
    "publish", so gitlab_publish_tool passed that test -- despite the only
    write verb belonging to Confluence.

    So proximity matters, not co-occurrence. A write verb counts for a
    tool only if one of that tool's system terms appears within a short
    window after it -- which is where the object of a verb sits in an
    imperative English clause ("publish a release notes page to the
    Confluence space"). Not linguistically exact, and it says so in the
    limitations: the honest fix is an LLM parse of the goal, which this
    repo already has a pattern for. But it is a real improvement over
    co-occurrence, and it fails toward NOT pre-ticking, which is the safe
    direction for a write grant.
    """
    if not _has_write_intent(goal_l):
        return False
    terms = TOOL_SYSTEM_TERMS.get(tool_name)
    if not terms:
        return True

    import re as _re
    WINDOW = 80   # chars after the verb -- roughly one clause
    for v in WRITE_INTENT_VERBS:
        for m in _re.finditer(_re.escape(v), goal_l):
            seg = goal_l[m.end(): m.end() + WINDOW]
            if any(t in seg for t in terms):
                return True
    return False


@dataclass
class ToolSuggestion:
    name: str
    description: str
    risk: str
    origin: str
    score: float
    rationale: str
    preselect: bool = True   # high-risk tools default OFF unless the goal
                             # shows real write intent -- see _recommend_tools


@dataclass
class Recommendation:
    goal: str
    suggested_name: str
    suggested_profile: str
    tools: List[ToolSuggestion] = field(default_factory=list)
    kb_required: bool = False
    kb_confidence: str = "none"          # none | low | medium | high
    kb_scope: List[str] = field(default_factory=list)
    kb_rationale: str = ""
    harness_required: bool = False
    harness_confidence: str = "none"
    harness_languages: List[str] = field(default_factory=list)
    harness_rationale: str = ""
    warnings: List[str] = field(default_factory=list)


class AgentRecommender:
    """Analyses a free-text goal against the live tool catalog and KG.
    Read-only -- recommending is not deciding, and this class never
    grants anything."""

    def __init__(self, kg: Optional[KnowledgeGraph] = None):
        self.kg = kg or KG
        self._ensure_tool_nodes()

    def _ensure_tool_nodes(self) -> None:
        """Tool descriptions need to be searchable the same way services
        and docs are -- otherwise 'recommend tools for this goal' has
        nothing to search against but a hand-written keyword list, which
        is exactly the brittleness this whole harness has been avoiding
        everywhere else.

        Always overwrites rather than skip-if-exists: seed_demo_estate()
        pre-creates placeholder tool nodes (text like "registry tool
        jira_tool") for whichever tools its demo services reference, and a
        skip-if-exists guard here left that placeholder in place instead of
        the real registry description -- jira_tool ended up effectively
        undescribed for search purposes. The registry is the source of
        truth for what a tool does; this always wins.
        """
        for t in list_tools():
            nid = f"tool:{t['name']}"
            self.kg.add_node(Node(nid, "tool", t["name"], t.get("description", ""),
                                  {"origin": t.get("origin", "built_in")}))

    def _tool_risk(self, name: str) -> str:
        if name in TOOL_RISK:
            return TOOL_RISK[name][0].value
        from utility_registry import UTILITIES
        u = UTILITIES.get(name)
        return u.risk if u else "medium"

    def _recommend_tools(self, goal: str, top_k: int = 8) -> List[ToolSuggestion]:
        hits = self.kg.hybrid_search(goal, kinds=["tool"], top_k=top_k)
        if not hits:
            return []
        top_bm25 = max(h["bm25_score"] for h in hits) or 0.0
        top_vec = max(h["vector_score"] for h in hits) or 0.0
        goal_l = goal.lower()

        out = []
        for h in hits:
            # A tool clears the bar on EITHER signal, not just BM25 -- a
            # goal phrased as pure paraphrase (no shared vocabulary at all)
            # would otherwise never surface a genuinely relevant tool.
            lex_ok = (top_bm25 > 0 and h["bm25_score"] >= top_bm25 * RELEVANCE_FLOOR
                     and h["bm25_score"] >= ABSOLUTE_BM25_FLOOR)
            vec_ok = top_vec > 0 and h["vector_score"] >= top_vec * RELEVANCE_FLOOR
            if not (lex_ok or vec_ok):
                continue
            name = h["name"]
            risk = self._tool_risk(name)

            # Lexical similarity to a tool's DESCRIPTION is not evidence
            # that its WRITE capability is wanted. gitlab_publish_tool's
            # description contains "merge request" and "release", so a goal
            # saying "cross-check against merged merge requests for the
            # release" scored it ABOVE gitlab_read_tool -- ranking a write
            # tool first for a purely read-shaped request. Pre-ticking that
            # is the worst failure this form can have, because a user
            # skimming checkboxes grants write access without noticing.
            #
            # So: a high-risk tool is only PRE-SELECTED when the goal shows
            # actual write intent. Otherwise it still appears in the list
            # (the user may genuinely want it) but unticked, with the
            # mismatch stated.
            preselect = True
            note = f"matched on {'/'.join(h['matched_by'])} against the stated goal"
            if risk == "high" and not _write_intent_for_tool(goal_l, name):
                preselect = False
                note = ("matched on wording, but the goal states no write action "
                        "against this system — left unselected; tick it only if "
                        "this agent really needs to change something here")

            out.append(ToolSuggestion(
                name=name, description=h["text"], risk=risk,
                origin=h["attrs"].get("origin", "built_in"),
                score=round(h["rrf_score"], 4),
                rationale=note, preselect=preselect,
            ))
        return out

    def _recommend_kb(self, goal: str) -> tuple:
        hits = self.kg.hybrid_search(goal, kinds=["service", "spec", "doc"], top_k=6)
        if not hits:
            return False, "none", [], "No service, spec, or doc in the knowledge base matched this goal."
        top = max(h["bm25_score"] for h in hits) or 0.0
        strong = [h for h in hits if top > 0 and h["bm25_score"] >= top * 0.6]
        weak = [h for h in hits if h not in strong and top > 0 and h["bm25_score"] >= top * RELEVANCE_FLOOR]
        if strong:
            names = [h["name"] for h in strong]
            return True, "high", names, (
                f"Goal closely matches existing knowledge: {', '.join(names)}. "
                "This agent should ground its answers in it rather than reason from scratch.")
        if weak:
            names = [h["name"] for h in weak]
            return True, "low", names, (
                f"Weak overlap with {', '.join(names)} — worth reviewing, not a strong signal. "
                "Confirm manually rather than trusting this alone.")
        return False, "none", [], "Nothing in the knowledge base cleared the relevance floor."

    def _recommend_harness(self, goal: str, tools: List[ToolSuggestion]) -> tuple:
        goal_l = goal.lower()
        kw_hit = any(k in goal_l for k in EXEC_KEYWORDS)
        tool_hit = any(t.name in ("execution_harness_tool", "test_runner_tool")
                       or "code-exec" in t.rationale for t in tools)

        langs = []
        # Word-boundary matching, not substring -- a single-letter language
        # id like "c" is a substring of "commit", "script", "execute",
        # nearly any English sentence. Caught by testing a goal that
        # legitimately mentions "commit the fix" and watching "c" get
        # detected as a requested language purely from that word.
        import re as _re
        words = set(_re.findall(r"[a-z0-9+#.]+", goal_l))
        for alias, canon in LANGUAGE_ALIASES.items():
            if alias in words and canon not in langs:
                langs.append(canon)
        for lang in LANGUAGES:
            if lang["id"] in words and lang["id"] not in langs:
                langs.append(lang["id"])

        if not (kw_hit or tool_hit or langs):
            return False, "none", [], (
                "No execution, compilation, or test-running language detected in the goal. "
                "Defaulting to no sandbox — the user can still enable one manually.")
        confidence = "high" if (kw_hit and (tool_hit or langs)) else "medium" if (kw_hit or tool_hit) else "low"
        rationale = "Goal references code execution"
        if langs:
            rationale += f" in {', '.join(langs)}"
        rationale += ". A sandbox will be required at runtime for any write-scoped execution call."
        if not langs:
            rationale += " No specific language detected — ask the user to confirm one."
        return True, confidence, langs, rationale

    def recommend(self, goal: str, name_hint: str = "") -> Recommendation:
        goal = (goal or "").strip()
        if not goal:
            return Recommendation(goal="", suggested_name="", suggested_profile="generalist",
                                  warnings=["Empty goal — nothing to analyse. "
                                           "Describe what the agent needs to do."])

        tools = self._recommend_tools(goal)
        kb_req, kb_conf, kb_scope, kb_why = self._recommend_kb(goal)
        harness_req, harness_conf, langs, harness_why = self._recommend_harness(goal, tools)

        warnings = []
        if not tools:
            warnings.append("No tool in the catalog cleared the relevance floor for this goal. "
                            "This may be a pure-reasoning agent, or the goal may need to be "
                            "more specific — search manually before assuming none apply.")
        high_risk = [t for t in tools if t.risk == "high"]
        if high_risk:
            warnings.append(f"{len(high_risk)} recommended tool(s) are high-risk and will "
                            f"require approval on every call regardless of what's selected here: "
                            f"{', '.join(t.name for t in high_risk)}.")

        profile = "engineer" if harness_req else ("qa" if any(
            "search" in t.name or "compliance" in t.name for t in tools) else "generalist")

        return Recommendation(
            goal=goal,
            suggested_name=name_hint or self._name_from_goal(goal),
            suggested_profile=profile,
            tools=sorted(tools, key=lambda t: -t.score),
            kb_required=kb_req, kb_confidence=kb_conf, kb_scope=kb_scope, kb_rationale=kb_why,
            harness_required=harness_req, harness_confidence=harness_conf,
            harness_languages=langs, harness_rationale=harness_why,
            warnings=warnings,
        )

    @staticmethod
    def _name_from_goal(goal: str) -> str:
        words = [w.strip(".,!?").lower() for w in goal.split()[:6]]
        stop = {"a", "an", "the", "to", "for", "of", "and", "that", "this", "with"}
        words = [w for w in words if w and w not in stop][:4]
        return "-".join(words) + "-agent" if words else "custom-agent"


# ================================================================ finalize ==

@dataclass
class OrchestratorDecision:
    name: str
    profile: str
    granted_tools: List[str] = field(default_factory=list)
    gated_at_runtime: List[Dict[str, str]] = field(default_factory=list)
    auto_approved: List[str] = field(default_factory=list)
    kb_enabled: bool = False
    kb_scope: List[str] = field(default_factory=list)
    sandbox_required: bool = False
    sandbox_kinds: List[str] = field(default_factory=list)
    unknown_tools: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


class AgentOrchestratorFinalizer:
    """Takes the USER'S confirmed selection -- not the recommendation --
    and does the governance work: which tools actually gate at runtime,
    which sandbox pool the chosen languages route to, and produces the
    final, deduplicated grant manifest. Nothing here can loosen what the
    harness's own risk table already enforces; a tool the user selects
    that is high-risk is high-risk here too, no exceptions negotiated in
    this form."""

    def finalize(self, name: str, profile: str, selected_tools: List[str],
                kb_enabled: bool, kb_scope: List[str],
                harness_enabled: bool, languages: List[str]) -> OrchestratorDecision:
        known = {t["name"] for t in list_tools()}
        valid = [t for t in selected_tools if t in known]
        unknown = [t for t in selected_tools if t not in known]

        gated, auto = [], []
        for t in valid:
            sev = self._severity(t)
            if sev == "low":
                auto.append(t)
            else:
                gated.append({"tool": t, "severity": sev})

        sandbox_kinds = []
        if harness_enabled:
            for lang in languages:
                match = next((l for l in LANGUAGES if l["id"] == lang), None)
                if match and match["sandbox"] not in sandbox_kinds:
                    sandbox_kinds.append(match["sandbox"])
            if not sandbox_kinds:
                sandbox_kinds = ["python_utility"]  # safe default, not a silent no-op

        notes = []
        if kb_enabled and not kb_scope:
            notes.append("Knowledge base enabled with no scope selected — this agent will "
                         "search the full KB rather than a narrowed subset. Consider scoping it.")
        if harness_enabled and not languages:
            notes.append("Execution enabled with no language selected — defaulted to "
                         f"{sandbox_kinds[0]}. Confirm this is correct before deploying.")
        if unknown:
            notes.append(f"{len(unknown)} selected tool(s) no longer exist in the registry "
                         f"and were dropped: {unknown}")
        if gated:
            notes.append(f"{len(gated)} tool(s) will require approval on every call at "
                         f"runtime — this form does not and cannot bypass that.")

        return OrchestratorDecision(
            name=name, profile=profile, granted_tools=sorted(valid),
            gated_at_runtime=gated, auto_approved=sorted(auto),
            kb_enabled=kb_enabled, kb_scope=kb_scope,
            sandbox_required=harness_enabled, sandbox_kinds=sandbox_kinds,
            unknown_tools=unknown, notes=notes,
        )

    @staticmethod
    def _severity(name: str) -> str:
        if name in TOOL_RISK:
            return TOOL_RISK[name][0].value
        from utility_registry import UTILITIES
        u = UTILITIES.get(name)
        return u.risk if u else "high"
