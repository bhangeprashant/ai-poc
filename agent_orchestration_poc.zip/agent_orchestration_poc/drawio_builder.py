"""Small builder for mxGraph (draw.io) XML — avoids hand-typing coordinates."""

_id_counter = [0]

def new_id(prefix="c"):
    _id_counter[0] += 1
    return f"{prefix}{_id_counter[0]}"


class Diagram:
    def __init__(self, name):
        self.name = name
        self.id = new_id("d")
        self.cells = []  # list of xml strings

    def rect(self, x, y, w, h, label, fill="#FFFFFF", stroke="#4B34C4",
             font="#141A23", rounded=True, dashed=False, fontsize=13,
             bold=False, fontstyle=None, align="center"):
        cid = new_id("v")
        style = (f"rounded={1 if rounded else 0};whiteSpace=wrap;html=1;"
                 f"fillColor={fill};strokeColor={stroke};fontColor={font};"
                 f"fontSize={fontsize};align={align};verticalAlign=middle;"
                 f"arcSize=10;strokeWidth=1.5;")
        if dashed:
            style += "dashed=1;"
        if bold:
            style += "fontStyle=1;"
        label = (label.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                 .replace('"', "&quot;").replace("\n", "&#10;"))
        self.cells.append(
            f'<mxCell id="{cid}" value="{label}" style="{style}" vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
        return cid

    def diamond(self, x, y, w, h, label, fill="#FBF1DE", stroke="#95650A", fontsize=12):
        cid = new_id("v")
        style = (f"rhombus;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};"
                 f"fontSize={fontsize};fontColor=#141A23;strokeWidth=1.5;")
        self.cells.append(
            f'<mxCell id="{cid}" value="{label}" style="{style}" vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
        return cid

    def circle(self, x, y, d, label, fill="#EFEBFB", stroke="#4B34C4", fontsize=13, bold=True):
        cid = new_id("v")
        style = (f"ellipse;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};"
                 f"fontSize={fontsize};fontColor=#141A23;strokeWidth=1.5;"
                 f"{'fontStyle=1;' if bold else ''}")
        self.cells.append(
            f'<mxCell id="{cid}" value="{label}" style="{style}" vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="{d}" height="{d}" as="geometry"/></mxCell>')
        return cid

    def note(self, x, y, w, h, label, fill="#EEF0F4", stroke="#B7BFCB", fontsize=11):
        cid = new_id("v")
        style = (f"rounded=1;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};"
                 f"fontSize={fontsize};fontColor=#4B5768;align=left;verticalAlign=top;"
                 f"spacing=8;arcSize=6;dashed=1;")
        label = label.replace("&", "&amp;").replace("<","&lt;").replace(">","&gt;").replace(chr(34),"&quot;")
        self.cells.append(
            f'<mxCell id="{cid}" value="{label}" style="{style}" vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
        return cid

    def edge(self, src, dst, label="", color="#4B34C4", dashed=False, style_extra="",
             exitX=None, exitY=None, entryX=None, entryY=None):
        cid = new_id("e")
        style = (f"edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;strokeColor={color};"
                 f"strokeWidth=1.5;fontColor=#141A23;fontSize=11;endArrow=block;"
                 f"endFill=1;jettySize=auto;{style_extra}")
        if dashed:
            style += "dashed=1;"
        if exitX is not None:
            style += f"exitX={exitX};exitY={exitY};exitDx=0;exitDy=0;"
        if entryX is not None:
            style += f"entryX={entryX};entryY={entryY};entryDx=0;entryDy=0;"
        label = label.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        self.cells.append(
            f'<mxCell id="{cid}" value="{label}" style="{style}" edge="1" parent="1" '
            f'source="{src}" target="{dst}"><mxGeometry relative="1" as="geometry"/></mxCell>')
        return cid

    def edge_free(self, x1, y1, x2, y2, color="#B7BFCB", dashed=True):
        cid = new_id("e")
        style = (f"edgeStyle=none;html=1;strokeColor={color};strokeWidth=1.2;"
                 f"endArrow=none;dashed={1 if dashed else 0};")
        self.cells.append(
            f'<mxCell id="{cid}" style="{style}" edge="1" parent="1">'
            f'<mxGeometry relative="1" as="geometry">'
            f'<mxPoint x="{x1}" y="{y1}" as="sourcePoint"/>'
            f'<mxPoint x="{x2}" y="{y2}" as="targetPoint"/>'
            f'</mxGeometry></mxCell>')
        return cid

    def xml(self, w=1700, h=1300):
        body = "\n".join(self.cells)
        return f'''<diagram name="{self.name}" id="{self.id}">
<mxGraphModel dx="900" dy="700" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="{w}" pageHeight="{h}" math="0" shadow="0">
<root>
<mxCell id="0"/>
<mxCell id="1" parent="0"/>
{body}
</root>
</mxGraphModel>
</diagram>'''


def write_mxfile(diagrams, path):
    body = "\n".join(d.xml() for d in diagrams)
    xml = f'<mxfile host="app.diagrams.net" agent="harness-docgen" version="24.0.0">\n{body}\n</mxfile>'
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(xml)
    return path
