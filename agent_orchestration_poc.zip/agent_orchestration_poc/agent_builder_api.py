"""
Agent Builder API.

  GET  /v1/builder/languages          the 15 supported execution languages
  GET  /v1/builder/tools              full catalog (built-in + published)
  POST /v1/builder/recommend          {goal} -> Recommendation
  POST /v1/builder/finalize           {confirmed selection} -> OrchestratorDecision
"""

from __future__ import annotations

from typing import Any, Dict, List

from fastapi import FastAPI
from pydantic import BaseModel, Field

from agent_builder import AgentRecommender, AgentOrchestratorFinalizer, LANGUAGES
from tool_registry import list_tools

app = FastAPI(title="Agent Builder", version="1.0")

from fastapi.responses import FileResponse

@app.get("/")
def index():
    return FileResponse("agent_builder.html")
RECOMMENDER = AgentRecommender()
FINALIZER = AgentOrchestratorFinalizer()


class RecommendRequest(BaseModel):
    goal: str
    name_hint: str = ""


class FinalizeRequest(BaseModel):
    name: str
    profile: str = "generalist"
    selected_tools: List[str] = Field(default_factory=list)
    kb_enabled: bool = False
    kb_scope: List[str] = Field(default_factory=list)
    harness_enabled: bool = False
    languages: List[str] = Field(default_factory=list)


@app.get("/v1/builder/languages")
def languages() -> Dict[str, Any]:
    return {"languages": LANGUAGES}


@app.get("/v1/builder/tools")
def tools() -> Dict[str, Any]:
    return {"tools": list_tools()}


@app.post("/v1/builder/recommend")
def recommend(req: RecommendRequest) -> Dict[str, Any]:
    r = RECOMMENDER.recommend(req.goal, req.name_hint)
    return {
        "goal": r.goal, "suggested_name": r.suggested_name,
        "suggested_profile": r.suggested_profile,
        "tools": [{"name": t.name, "description": t.description, "risk": t.risk,
                   "origin": t.origin, "score": t.score, "rationale": t.rationale,
                   "preselect": t.preselect}
                  for t in r.tools],
        "kb": {"required": r.kb_required, "confidence": r.kb_confidence,
               "scope": r.kb_scope, "rationale": r.kb_rationale},
        "harness": {"required": r.harness_required, "confidence": r.harness_confidence,
                    "languages": r.harness_languages, "rationale": r.harness_rationale},
        "warnings": r.warnings,
    }


@app.post("/v1/builder/finalize")
def finalize(req: FinalizeRequest) -> Dict[str, Any]:
    d = FINALIZER.finalize(req.name, req.profile, req.selected_tools,
                           req.kb_enabled, req.kb_scope,
                           req.harness_enabled, req.languages)
    return {
        "name": d.name, "profile": d.profile, "granted_tools": d.granted_tools,
        "gated_at_runtime": d.gated_at_runtime, "auto_approved": d.auto_approved,
        "kb_enabled": d.kb_enabled, "kb_scope": d.kb_scope,
        "sandbox_required": d.sandbox_required, "sandbox_kinds": d.sandbox_kinds,
        "unknown_tools": d.unknown_tools, "notes": d.notes,
    }
