"""
Architect Agent — a multi-agent system that turns a repo into architecture
artifacts: HLD, LLD, a draw.io diagram, a UML class diagram, and an HTML
diagram, with live progress and a downloadable bundle at the end.

  Orchestrator
   ├─ CodeIngestAgent    -- walks the repo with ast, builds the KG (real
   │                        modules/classes/functions/imports, not fixtures)
   ├─ DocIngestAgent     -- ingests README/docs as searchable KG nodes
   ├─ ArchitectureAnalystAgent -- groups modules into components, computes
   │                        blast radius per component from the graph
   ├─ HLDAgent           -- one high-level design doc
   ├─ LLDAgent × N        -- one low-level design doc PER COMPONENT, in
   │                        parallel -- the fan-out pattern from farm_core,
   │                        applied to document generation instead of tool
   │                        calls
   └─ DiagramAgent       -- draw.io XML + mermaid UML + HTML, all sourced
                            from the SAME graph the docs came from, so the
                            diagrams and the docs cannot silently disagree

Every stage emits progress through the harness's own EventBus (harness_core.py)
-- the same resumable, seq-numbered stream already used for agent-to-agent
runs elsewhere in this repo. A caller (this demo, or a real UI) attaches to
one stream and watches the whole build happen.

Design decisions worth stating:

1. INGESTION IS READ-ONLY AND REAL. CodeIngestAgent parses actual Python
   with `ast` -- real classes, real functions, real import edges. Blast
   radius on the generated diagrams is the same blast_radius() already
   used to gate risk elsewhere in this repo, computed from a graph built
   from the actual codebase, not asserted.

2. LLD FANS OUT PER COMPONENT, HLD DOES NOT. One component's LLD failing
   to generate should not block the others -- same reasoning as
   per-finding validation in the remediation pipeline. HLD is a single
   synthesis step because "the system, as a whole" is not a
   parallelizable unit.

3. DIAGRAMS AND DOCS SHARE ONE SOURCE. The .drawio file, the mermaid UML,
   the HTML diagram, and both markdown docs are all built from the same
   KnowledgeGraph instance. A diagram that disagrees with the doc next to
   it is the single most common failure mode of hand-maintained
   architecture documentation -- this cannot happen here because there is
   only one graph, read four different ways.
"""

from __future__ import annotations

import ast
import os
import threading
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from harness_core import EventBus, EventType, HarnessEvent
from knowledge_graph import KnowledgeGraph, Node
from llm_client import complete_json
import drawio_builder as dio

PROGRESS = "progress"   # custom event type carried in HarnessEvent.data


def emit(bus: EventBus, stage: str, msg: str, **extra: Any) -> None:
    bus.emit(EventType.MESSAGE_DELTA, {"stage": stage, "msg": msg, **extra})


# ============================================================== ingestion ==

SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", "utilities"}


class CodeIngestAgent:
    """Walks the repo with `ast`. Builds real module/class/function nodes
    and real import-derived depends_on edges -- the same edge type
    blast_radius() already walks elsewhere in this codebase."""

    def run(self, repo_path: str, kg: KnowledgeGraph, bus: EventBus) -> Dict[str, Any]:
        emit(bus, "ingest.code", f"Scanning {repo_path} for Python modules")
        py_files = []
        for root, dirs, files in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for f in files:
                if f.endswith(".py"):
                    py_files.append(os.path.join(root, f))

        modules: Dict[str, Dict[str, Any]] = {}
        for path in py_files:
            mod_name = os.path.splitext(os.path.relpath(path, repo_path))[0].replace(os.sep, ".")
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    src = fh.read()
                tree = ast.parse(src, filename=path)
            except (SyntaxError, UnicodeDecodeError) as exc:
                emit(bus, "ingest.code", f"Skipped {mod_name}: {exc}", level="warn")
                continue

            classes, functions, imports = [], [], set()
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    methods = [n.name for n in node.body if isinstance(n, ast.FunctionDef)]
                    classes.append({"name": node.name, "methods": methods,
                                    "doc": ast.get_docstring(node) or ""})
                elif isinstance(node, ast.FunctionDef) and node.col_offset == 0:
                    functions.append({"name": node.name,
                                      "doc": ast.get_docstring(node) or ""})
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.add(alias.name.split(".")[0])
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imports.add(node.module.split(".")[0])

            modules[mod_name] = {"path": path, "classes": classes,
                                 "functions": functions, "imports": imports,
                                 "loc": len(src.splitlines())}

        # nodes first, so edges can resolve local (in-repo) imports
        for mod_name, m in modules.items():
            summary = f"{len(m['classes'])} class(es), {len(m['functions'])} function(s), {m['loc']} LOC"
            kg.add_node(Node(f"module:{mod_name}", "module", mod_name,
                             summary + "\n" + " ".join(c["doc"] for c in m["classes"]),
                             {"path": m["path"], "loc": m["loc"],
                              "classes": [c["name"] for c in m["classes"]],
                              "functions": [f["name"] for f in m["functions"]]}))
            for c in m["classes"]:
                kg.add_node(Node(f"class:{mod_name}.{c['name']}", "class", c["name"],
                                 c["doc"], {"module": mod_name, "methods": c["methods"]}))
                kg.add_edge(f"module:{mod_name}", f"class:{mod_name}.{c['name']}", "defines")

        local_modules = set(modules.keys())
        edge_count = 0
        for mod_name, m in modules.items():
            for imp in m["imports"]:
                # only wire edges for imports that resolve to another module
                # actually in this repo -- an import of `os` isn't part of
                # the architecture, an import of a sibling module is.
                target = next((lm for lm in local_modules
                              if lm == imp or lm.endswith("." + imp)), None)
                if target and target != mod_name:
                    kg.add_edge(f"module:{mod_name}", f"module:{target}", "depends_on")
                    edge_count += 1

        emit(bus, "ingest.code",
             f"Ingested {len(modules)} module(s), {edge_count} dependency edge(s)")
        return {"modules": modules, "edge_count": edge_count}


class DocIngestAgent:
    """Ingests README/markdown as searchable, citable KG nodes -- so HLD
    generation can draw on what the repo already says about itself,
    not just what the code implies."""

    def run(self, repo_path: str, kg: KnowledgeGraph, bus: EventBus) -> int:
        emit(bus, "ingest.docs", "Scanning for README / markdown docs")
        count = 0
        for root, dirs, files in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for f in files:
                if f.lower().endswith(".md"):
                    path = os.path.join(root, f)
                    try:
                        with open(path, "r", encoding="utf-8") as fh:
                            text = fh.read()
                    except UnicodeDecodeError:
                        continue
                    rel = os.path.relpath(path, repo_path)
                    kg.add_node(Node(f"doc:{rel}", "doc", rel, text[:4000],
                                     {"path": path, "chars": len(text)}))
                    count += 1
        emit(bus, "ingest.docs", f"Ingested {count} document(s)")
        return count


# ============================================================== analysis ==

@dataclass
class Component:
    name: str
    modules: List[str]
    classes: List[str]
    dependents: int          # blast radius: who breaks if this component changes
    depends_on: List[str]
    doc_refs: List[str]


class ArchitectureAnalystAgent:
    """Groups modules into components by CONNECTED COMPONENTS of the real
    dependency graph, not by filename convention.

    First version was plain prefix-splitting (module name up to its first
    underscore). Wrong in a way only visible from the actual edges:
    console_api depends on approvals, chat_pipeline, speech, AND
    tool_registry, but prefix-splitting kept "console", "approvals",
    "chat", "speech", "tool" as four separate, disconnected components --
    an architecture diagram that hides real coupling is worse than none,
    because it looks authoritative while being wrong.

    Second version was plain union-find over every depends_on edge. Also
    wrong, in the opposite direction: a handful of widely-imported shared
    modules (harness_core, tool_registry, models -- fan-in 6 to 9) bridge
    almost the entire graph transitively, so everything except two
    unrelated leaf files collapsed into one 34-module blob. Real-world
    dependency graphs almost always have this hub structure, and naive
    connected-components is exactly the wrong tool for it.

    Fix: exclude high fan-in HUB modules from the edges used for
    clustering, so a shared utility can't bridge two otherwise-unrelated
    feature areas into one false component. Hubs are grouped into their
    own "core" component instead -- which is an honest architectural
    claim (this repo genuinely has a shared foundation layer), not a
    workaround. Every other component's depends_on list still shows its
    real edges into core.
    """

    HUB_FAN_IN = 4   # a module ≥4 others depend on is infrastructure, not a feature

    def run(self, kg: KnowledgeGraph, bus: EventBus) -> List[Component]:
        emit(bus, "analyze", "Clustering modules by real dependency structure")
        modules = [n for n in kg.nodes.values() if n.kind == "module"]
        mod_names = [m.name for m in modules]

        fan_in: Dict[str, int] = {m: 0 for m in mod_names}
        all_edges: List[Tuple[str, str]] = []
        for m in mod_names:
            for e in kg.out[f"module:{m}"]:
                if e.rel == "depends_on":
                    other = kg.nodes[e.dst].name
                    if other in fan_in:
                        fan_in[other] += 1
                        all_edges.append((m, other))

        hubs = {m for m in mod_names if fan_in[m] >= self.HUB_FAN_IN}
        non_hub = [m for m in mod_names if m not in hubs]

        parent = {m: m for m in non_hub}

        def find(x: str) -> str:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb

        peer_edges = [(a, b) for a, b in all_edges if a not in hubs and b not in hubs]
        for a, b in peer_edges:
            union(a, b)

        clusters: Dict[str, List[str]] = {}
        for m in non_hub:
            clusters.setdefault(find(m), []).append(m)

        def name_cluster(mods_in_cluster: List[str]) -> str:
            if len(mods_in_cluster) == 1:
                return mods_in_cluster[0]
            degree = {m: 0 for m in mods_in_cluster}
            for a, b in peer_edges:
                if a in degree:
                    degree[a] += 1
                if b in degree:
                    degree[b] += 1
            return max(mods_in_cluster, key=lambda m: degree[m])

        components: List[Component] = []

        if hubs:
            core_classes = []
            for m in hubs:
                core_classes.extend(kg.nodes[f"module:{m}"].attrs.get("classes", []))
            reached = set()
            for m in hubs:
                r = kg.blast_radius(f"module:{m}")
                reached.update(mm for mm in r["dependents"] if mm not in hubs)
            components.append(Component("core", sorted(hubs), sorted(set(core_classes)),
                                        len(reached), [], []))

        for root, mods in clusters.items():
            name = name_cluster(sorted(mods))
            classes = []
            depends_on: set = set()
            in_cluster = set(mods)
            for mod in mods:
                node = kg.nodes[f"module:{mod}"]
                classes.extend(node.attrs.get("classes", []))
                for e in kg.out[f"module:{mod}"]:
                    if e.rel == "depends_on":
                        target_mod = kg.nodes[e.dst].name
                        if target_mod in hubs:
                            depends_on.add("core")
                        elif target_mod not in in_cluster and target_mod in parent:
                            depends_on.add(name_cluster(sorted(clusters[find(target_mod)])))

            reached = set()
            for mod in mods:
                r = kg.blast_radius(f"module:{mod}")
                for dep_mod in r["dependents"]:
                    if dep_mod not in in_cluster:
                        reached.add(dep_mod)
            doc_refs = [n.name for n in kg.nodes.values() if n.kind == "doc"
                       and name.split("_")[0].lower() in n.text.lower()][:2]

            components.append(Component(name, sorted(mods), sorted(set(classes)),
                                        len(reached), sorted(depends_on), doc_refs))

        components.sort(key=lambda c: (c.name != "core", -len(c.modules), c.name))
        emit(bus, "analyze",
             f"Identified {len(components)} component(s) ({len(hubs)} shared-infra module(s) "
             f"grouped as 'core') from {len(peer_edges)} peer edge(s): "
             + ", ".join(c.name for c in components[:8])
             + (f" (+{len(components)-8} more)" if len(components) > 8 else ""))
        return components


# ================================================================== HLD ===

class HLDAgent:
    """One synthesis step for the whole system -- not parallelizable, since
    'the system as a whole' isn't a per-unit thing to fan out over."""

    def run(self, repo_name: str, components: List[Component],
           kg: KnowledgeGraph, bus: EventBus) -> str:
        emit(bus, "hld", "Drafting high-level design")

        comp_lines = "\n".join(
            f"- **{c.name}** — {len(c.modules)} module(s), depends on: "
            f"{', '.join(c.depends_on) or 'nothing internal'}, "
            f"{c.dependents} downstream dependent(s)"
            for c in components)

        def mock() -> Dict[str, Any]:
            return {"overview": (
                f"{repo_name} is organised into {len(components)} components. "
                f"The highest-reach component is "
                f"{max(components, key=lambda c: c.dependents).name if components else 'n/a'}, "
                "meaning changes there carry the widest blast radius across the system."
            )}

        out = complete_json(
            "You are drafting a High-Level Design document from a real dependency "
            "graph extracted from source code. Ground every claim in the component "
            "list given -- do not invent components or relationships.",
            f"Repo: {repo_name}\nComponents:\n{comp_lines}\n\n"
            "Return JSON: {\"overview\": str}",
            mock)

        lines = [
            f"# High-Level Design — {repo_name}", "",
            "## Overview", out.get("overview", ""), "",
            "## Components", "",
            "| Component | Modules | Depends on | Downstream dependents |",
            "|---|---|---|---|",
        ]
        for c in components:
            lines.append(f"| {c.name} | {len(c.modules)} | "
                         f"{', '.join(c.depends_on) or '—'} | {c.dependents} |")
        lines += ["", "## Change-risk ordering",
                  "Components ranked by blast radius — the same metric this "
                  "repo's approval broker uses to escalate risk:", ""]
        for c in sorted(components, key=lambda c: -c.dependents):
            lines.append(f"1. **{c.name}** — {c.dependents} dependent component(s)")

        doc = "\n".join(lines)
        emit(bus, "hld", f"HLD drafted — {len(components)} components documented")
        return doc


# ================================================================== LLD ===

class LLDAgent:
    """One LLD per component. Designed to run in parallel across components
    via threads, same fan-out shape as FarmCoordinator -- one component
    failing to generate must not block the others."""

    def run(self, component: Component, kg: KnowledgeGraph, bus: EventBus) -> str:
        emit(bus, "lld", f"Drafting LLD for {component.name}")

        class_details = []
        for mod in component.modules:
            for cls_name in kg.nodes[f"module:{mod}"].attrs.get("classes", []):
                cnode = kg.nodes.get(f"class:{mod}.{cls_name}")
                if cnode:
                    class_details.append(
                        f"- `{cls_name}` ({mod}): {cnode.attrs.get('methods', [])}")

        def mock() -> Dict[str, Any]:
            return {"design_notes": (
                f"{component.name} exposes {len(component.classes)} class(es) across "
                f"{len(component.modules)} module(s). "
                + (f"It depends on {', '.join(component.depends_on)}."
                   if component.depends_on else "It has no internal dependencies.")
            )}

        out = complete_json(
            "Draft Low-Level Design notes for one component of a larger system, "
            "grounded strictly in the classes and methods given.",
            f"Component: {component.name}\nClasses:\n" + "\n".join(class_details) +
            "\n\nReturn JSON: {\"design_notes\": str}",
            mock)

        lines = [f"## {component.name}", "", out.get("design_notes", ""), "",
                "### Modules", "\n".join(f"- `{m}`" for m in component.modules), "",
                "### Classes"]
        lines += class_details or ["- (no classes — function-level module)"]
        return "\n".join(lines)


# =============================================================== diagram ==

class DiagramAgent:
    """Draw.io + mermaid UML + HTML — ALL sourced from the same KG the docs
    came from, using the already-tested drawio_builder module."""

    def build_drawio(self, repo_name: str, components: List[Component]) -> str:
        d = dio.Diagram(f"{repo_name} — Component Architecture")
        SIGNAL = "#4B34C4"
        colors = ["#4B34C4", "#1F6E56", "#95650A", "#AE3A46", "#2E5FA3", "#6B4FA0"]
        pos: Dict[str, str] = {}
        cols = max(1, min(4, len(components)))
        for i, c in enumerate(components):
            x, y = 60 + (i % cols) * 340, 60 + (i // cols) * 220
            color = colors[i % len(colors)]
            cid = d.rect(x, y, 280, 150,
                        f"{c.name}\n{len(c.modules)} modules, {len(c.classes)} classes\n"
                        f"blast radius: {c.dependents}",
                        fill="#FFFFFF", stroke=color, bold=True, fontsize=13)
            pos[c.name] = cid
        for c in components:
            for dep in c.depends_on:
                if dep in pos and c.name in pos:
                    d.edge(pos[c.name], pos[dep], color="#828EA0")
        return dio.write_mxfile([d], "/tmp/_unused.drawio") or d.xml()

    def build_mermaid(self, repo_name: str, components: List[Component]) -> str:
        lines = ["```mermaid", "classDiagram"]
        for c in components:
            lines.append(f"  class {c.name} {{")
            for cls in c.classes[:8]:
                lines.append(f"    +{cls}")
            lines.append("  }")
        for c in components:
            for dep in c.depends_on:
                lines.append(f"  {c.name} --> {dep}")
        lines.append("```")
        return f"# UML — {repo_name}\n\n" + "\n".join(lines)

    def build_html(self, repo_name: str, components: List[Component]) -> str:
        cards = "\n".join(f'''
        <div class="card">
          <span class="tag">{c.name}</span>
          <h3>{c.name}</h3>
          <p>{len(c.modules)} modules · {len(c.classes)} classes</p>
          <p class="dep">depends on: {", ".join(c.depends_on) or "—"}</p>
          <p class="blast">blast radius: {c.dependents}</p>
        </div>''' for c in components)
        return f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>{repo_name} — Architecture</title>
<style>
body{{font-family:'Instrument Sans',sans-serif;background:#EEF0F4;margin:0;padding:40px;color:#141A23;}}
h1{{font-family:'Space Grotesk',sans-serif;}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;margin-top:24px;}}
.card{{background:#fff;border:1.5px solid #D7DDE6;border-radius:12px;padding:18px;}}
.tag{{font-family:monospace;font-size:10px;color:#4B34C4;text-transform:uppercase;}}
.dep{{font-size:12px;color:#4B5768;}} .blast{{font-size:12px;color:#AE3A46;}}
</style></head><body>
<h1>{repo_name} — Component Architecture</h1>
<div class="grid">{cards}</div>
</body></html>"""

    def run(self, repo_name: str, components: List[Component],
           kg: KnowledgeGraph, bus: EventBus, out_dir: str) -> Dict[str, str]:
        emit(bus, "diagram", "Generating draw.io, UML, and HTML diagrams")
        os.makedirs(out_dir, exist_ok=True)

        d = dio.Diagram(f"{repo_name} — Component Architecture")
        colors = ["#4B34C4", "#1F6E56", "#95650A", "#AE3A46", "#2E5FA3", "#6B4FA0"]
        pos: Dict[str, str] = {}
        cols = max(1, min(4, len(components)))
        for i, c in enumerate(components):
            x, y = 60 + (i % cols) * 340, 60 + (i // cols) * 220
            color = colors[i % len(colors)]
            cid = d.rect(x, y, 280, 150,
                        f"{c.name}\n{len(c.modules)} modules, {len(c.classes)} classes\n"
                        f"blast radius: {c.dependents}",
                        fill="#FFFFFF", stroke=color, bold=True, fontsize=13)
            pos[c.name] = cid
        for c in components:
            for dep in c.depends_on:
                if dep in pos and c.name in pos:
                    d.edge(pos[c.name], pos[dep], color="#828EA0")

        drawio_path = os.path.join(out_dir, "architecture.drawio")
        dio.write_mxfile([d], drawio_path)

        mermaid_path = os.path.join(out_dir, "uml.md")
        with open(mermaid_path, "w", encoding="utf-8") as fh:
            fh.write(self.build_mermaid(repo_name, components))

        html_path = os.path.join(out_dir, "architecture.html")
        with open(html_path, "w", encoding="utf-8") as fh:
            fh.write(self.build_html(repo_name, components))

        emit(bus, "diagram", "Diagrams written: architecture.drawio, uml.md, architecture.html")
        return {"drawio": drawio_path, "uml": mermaid_path, "html": html_path}
