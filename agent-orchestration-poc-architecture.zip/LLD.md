# Low-Level Design — agent-orchestration-poc

## core

core exposes 51 class(es) across 11 module(s). It has no internal dependencies.

### Modules
- `approvals`
- `farm_core`
- `harness_context`
- `harness_core`
- `harness_loop`
- `knowledge_graph`
- `llm_client`
- `models`
- `sandbox_pool`
- `tool_registry`
- `utility_registry`

### Classes
- `RunState` (approvals): []
- `Severity` (approvals): []
- `RiskFlag` (approvals): []
- `PendingRun` (approvals): ['is_expired', 'to_dict']
- `ApprovalStore` (approvals): ['__init__', 'create', 'get', 'list_pending']
- `PolicyRule` (farm_core): ['matches']
- `AuditEntry` (farm_core): []
- `PolicyBroker` (farm_core): ['__init__', 'watch', 'decide', '_loop', '_tick', 'resolve_escalation', 'audit_summary', 'shutdown']
- `FarmAgent` (farm_core): []
- `FarmResult` (farm_core): []
- `FarmCoordinator` (farm_core): ['__init__', 'dispatch']
- `Skill` (harness_context): []
- `SkillRegistry` (harness_context): ['__init__', 'reload', 'all', 'get', 'constraints', 'catalog_for_prompt', 'constraint_block', 'select']
- `MemoryRecord` (harness_context): []
- `SessionMemory` (harness_context): ['__init__', 'add', 'working_chars', 'needs_compaction', 'compact', 'build_context', 'stats']
- `EventType` (harness_core): []
- `SessionState` (harness_core): []
- `HarnessEvent` (harness_core): ['to_sse']
- `_Subscriber` (harness_core): ['__init__', 'push', 'close']
- `EventBus` (harness_core): ['__init__', 'emit', 'replay_after', 'oldest_retained_seq', 'current_seq', 'subscribe', 'unsubscribe', 'mark_terminal', 'stream']
- `Artifact` (harness_core): []
- `Checkpoint` (harness_core): ['__post_init__', 'wait', 'resolve']
- `Session` (harness_core): ['touch', 'public']
- `SessionStore` (harness_core): ['__init__', 'create', 'get', 'bus', 'list', 'evict_idle']
- `BudgetExceeded` (harness_loop): []
- `CheckpointRejected` (harness_loop): []
- `HarnessRun` (harness_loop): ['__init__', 'emit', '_check_budget', 'request_checkpoint', 'dispatch_tool', 'spawn_subagent', 'plan', 'execute', 'synthesize', 'evaluate']
- `Node` (knowledge_graph): []
- `Edge` (knowledge_graph): []
- `KnowledgeGraph` (knowledge_graph): ['__init__', 'add_node', 'add_edge', 'record_finding', '_bm25', '_vector_score', 'hybrid_search', 'neighbors', 'blast_radius', 'tools_for', 'stats']
- `AgentSpec` (models): ['parse']
- `ToolDefinition` (models): []
- `HandoffType` (models): []
- `HandoffEnvelope` (models): ['to_dict']
- `PlanStep` (models): []
- `Plan` (models): ['required_roles']
- `Backpressure` (sandbox_pool): []
- `ReplicaState` (sandbox_pool): []
- `Replica` (sandbox_pool): ['in_use', 'free', 'matches']
- `Lease` (sandbox_pool): []
- `QueuedRequest` (sandbox_pool): []
- `ScalingBackend` (sandbox_pool): ['current_target', 'apply']
- `DirectKubernetesBackend` (sandbox_pool): ['__init__', 'apply', 'current_target']
- `SimulatedBackend` (sandbox_pool): ['__init__', 'apply', 'current_target']
- `ExternalDeviceProvider` (sandbox_pool): ['acquire', 'release']
- `SimulatedExternalDeviceCloud` (sandbox_pool): ['__init__', 'acquire', 'release']
- `SandboxPoolManager` (sandbox_pool): ['__init__', 'register', 'deregister', 'acquire', '_try_acquire_now', '_try_acquire_now_locked', 'release', '_try_drain_queue', 'lease_ctx', '_capacity_summary', '_desired_replicas', '_loop', '_tick', 'status', 'metrics_prometheus', 'shutdown']
- `_LeaseContext` (sandbox_pool): ['__init__', '__enter__', '__exit__']
- `UtilityError` (utility_registry): []
- `Utility` (utility_registry): ['to_public']
- `UtilityRegistry` (utility_registry): ['__init__', 'reload', 'upload', 'remove_uploaded', 'all', 'get', 'execute', '_run_in_process', '_resolve_entrypoint', '_run_sandboxed']

## agents

agents exposes 28 class(es) across 9 module(s). It depends on core.

### Modules
- `agent_runtime`
- `agents`
- `api`
- `chat_pipeline`
- `console_api`
- `console_core`
- `deployment`
- `orchestrator_pipeline`
- `speech`

### Classes
- `_Identity` (agent_runtime): ['__init__', 'configure', 'release']
- `ConfigureRequest` (agent_runtime): []
- `ExecuteRequest` (agent_runtime): []
- `UnderstandingAgent` (agents): ['process']
- `PlannerAgent` (agents): ['process']
- `ExecutorAgent` (agents): ['__init__', 'run_step']
- `LocalDispatcher` (agents): ['__init__', 'bind', 'dispatch']
- `HttpDispatcher` (agents): ['__init__', 'bind', 'dispatch']
- `OrchestratorAgent` (agents): ['run']
- `PlanRequest` (api): []
- `DecisionRequest` (api): []
- `Spine` (chat_pipeline): ['__init__', 'start', 'finish', 'to_list']
- `QueryAnalyzerAgent` (chat_pipeline): ['process']
- `IntentMapperAgent` (chat_pipeline): ['process']
- `ConsoleOrchestrator` (chat_pipeline): ['run', '_invoke_agent_farm', '_direct_answer', '_synthesize']
- `ChatRequest` (console_api): []
- `NewConversationRequest` (console_api): []
- `RenameRequest` (console_api): []
- `MemoryRequest` (console_api): []
- `Persona` (console_core): []
- `Message` (console_core): []
- `Conversation` (console_core): ['summary', 'to_dict']
- `ConversationStore` (console_core): ['__init__', 'create', 'get', 'list', 'delete', 'rename']
- `DeploymentBackend` (deployment): ['deploy', 'teardown']
- `SimulatedBackend` (deployment): ['deploy', 'teardown']
- `WarmPoolBackend` (deployment): ['__init__', 'pool_status', 'deploy', 'teardown']
- `KubernetesBackend` (deployment): ['__init__', '_ensure_namespace', '_to_k8s_deployment', '_to_k8s_service', '_wait_ready', 'deploy', 'teardown']
- `STTUnavailable` (speech): []

## vuln_remediation

vuln_remediation exposes 9 class(es) across 6 module(s). It depends on core.

### Modules
- `a2a_bridge`
- `farm_speckit`
- `farm_speckit_demo`
- `remediation_e2e`
- `vuln_remediation`
- `vuln_remediation_demo`

### Classes
- `A2AArtifact` (a2a_bridge): []
- `A2ATaskRef` (a2a_bridge): []
- `HandoffEdge` (farm_speckit): []
- `PipelineStep` (farm_speckit): []
- `SpecKitPipeline` (farm_speckit): ['__init__', 'run_phase', 'run_from', 'gated_edges_from']
- `TriageVerdict` (vuln_remediation): []
- `RegressionReport` (vuln_remediation): []
- `RemediationRecord` (vuln_remediation): ['to_state']
- `RemediationPipeline` (vuln_remediation): ['__init__', 'default_broker', 'log', 'stage_clone', 'stage_fetch', 'stage_triage', 'stage_baseline', 'stage_remediate', '_advance_spec_chain', '_drain_task', 'stage_validate', 'stage_validate_per_finding', 'publishable', 'save_state', 'load_state', 'stage_human_review', 'iter_dismissed', 'stage_publish', 'stage_rescan']

## architect_agent

architect_agent exposes 10 class(es) across 4 module(s). It depends on core.

### Modules
- `architect_agent`
- `architect_agent_demo`
- `architect_orchestrator`
- `drawio_builder`

### Classes
- `CodeIngestAgent` (architect_agent): ['run']
- `DocIngestAgent` (architect_agent): ['run']
- `Component` (architect_agent): []
- `ArchitectureAnalystAgent` (architect_agent): ['run']
- `HLDAgent` (architect_agent): ['run']
- `LLDAgent` (architect_agent): ['run']
- `DiagramAgent` (architect_agent): ['build_drawio', 'build_mermaid', 'build_html', 'run']
- `ArchitectResult` (architect_orchestrator): []
- `ArchitectOrchestrator` (architect_orchestrator): ['__init__', 'run_streaming', '_build']
- `Diagram` (drawio_builder): ['__init__', 'rect', 'diamond', 'circle', 'note', 'edge', 'edge_free', 'xml']

## farm_kg_demo

farm_kg_demo exposes 2 class(es) across 2 module(s). It depends on core.

### Modules
- `farm_kg_demo`
- `tool_broker`

### Classes
- `GrantDecision` (tool_broker): []
- `ToolBroker` (tool_broker): ['__init__', 'registry_catalog', '_utility_severity', 'derive_grants', 'effective_severity', 'context_for']

## harness_client

harness_client exposes 2 class(es) across 2 module(s). It has no internal dependencies.

### Modules
- `harness_client`
- `harness_example_caller`

### Classes
- `HarnessError` (harness_client): []
- `HarnessClient` (harness_client): ['__init__', '_post', '_get', 'open_session', 'session', 'seed_memory', 'approve', 'answer', 'run', '_stream', 'invoke', 'run_with_policy']

## farm_scenarios

farm_scenarios exposes 0 class(es) across 1 module(s). It depends on core.

### Modules
- `farm_scenarios`

### Classes
- (no classes — function-level module)

## harness_api

harness_api exposes 7 class(es) across 1 module(s). It depends on core.

### Modules
- `harness_api`

### Classes
- `CreateSession` (harness_api): []
- `SubmitTurn` (harness_api): []
- `ResolveCheckpoint` (harness_api): []
- `SeedMemory` (harness_api): []
- `InvokeRequest` (harness_api): []
- `UploadUtility` (harness_api): []
- `ScaffoldUtility` (harness_api): []

## sandbox_api

sandbox_api exposes 3 class(es) across 1 module(s). It depends on core.

### Modules
- `sandbox_api`

### Classes
- `RegisterReq` (sandbox_api): []
- `AcquireReq` (sandbox_api): []
- `ReleaseReq` (sandbox_api): []

