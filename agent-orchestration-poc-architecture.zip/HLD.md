# High-Level Design — agent-orchestration-poc

## Overview
agent-orchestration-poc is organised into 9 components. The highest-reach component is core, meaning changes there carry the widest blast radius across the system.

## Components

| Component | Modules | Depends on | Downstream dependents |
|---|---|---|---|
| core | 11 | — | 21 |
| agents | 9 | core | 0 |
| vuln_remediation | 6 | core | 0 |
| architect_agent | 4 | core | 0 |
| farm_kg_demo | 2 | core | 0 |
| harness_client | 2 | — | 0 |
| farm_scenarios | 1 | core | 0 |
| harness_api | 1 | core | 0 |
| sandbox_api | 1 | core | 0 |

## Change-risk ordering
Components ranked by blast radius — the same metric this repo's approval broker uses to escalate risk:

1. **core** — 21 dependent component(s)
1. **agents** — 0 dependent component(s)
1. **vuln_remediation** — 0 dependent component(s)
1. **architect_agent** — 0 dependent component(s)
1. **farm_kg_demo** — 0 dependent component(s)
1. **harness_client** — 0 dependent component(s)
1. **farm_scenarios** — 0 dependent component(s)
1. **harness_api** — 0 dependent component(s)
1. **sandbox_api** — 0 dependent component(s)