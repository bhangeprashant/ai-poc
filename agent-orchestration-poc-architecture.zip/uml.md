# UML — agent-orchestration-poc

```mermaid
classDiagram
  class core {
    +AgentSpec
    +ApprovalStore
    +Artifact
    +AuditEntry
    +Backpressure
    +BudgetExceeded
    +Checkpoint
    +CheckpointRejected
  }
  class agents {
    +ChatRequest
    +ConfigureRequest
    +ConsoleOrchestrator
    +Conversation
    +ConversationStore
    +DecisionRequest
    +DeploymentBackend
    +ExecuteRequest
  }
  class vuln_remediation {
    +A2AArtifact
    +A2ATaskRef
    +HandoffEdge
    +PipelineStep
    +RegressionReport
    +RemediationPipeline
    +RemediationRecord
    +SpecKitPipeline
  }
  class architect_agent {
    +ArchitectOrchestrator
    +ArchitectResult
    +ArchitectureAnalystAgent
    +CodeIngestAgent
    +Component
    +Diagram
    +DiagramAgent
    +DocIngestAgent
  }
  class farm_kg_demo {
    +GrantDecision
    +ToolBroker
  }
  class harness_client {
    +HarnessClient
    +HarnessError
  }
  class farm_scenarios {
  }
  class harness_api {
    +CreateSession
    +InvokeRequest
    +ResolveCheckpoint
    +ScaffoldUtility
    +SeedMemory
    +SubmitTurn
    +UploadUtility
  }
  class sandbox_api {
    +AcquireReq
    +RegisterReq
    +ReleaseReq
  }
  agents --> core
  vuln_remediation --> core
  architect_agent --> core
  farm_kg_demo --> core
  farm_scenarios --> core
  harness_api --> core
  sandbox_api --> core
```